<?php

defined('BASEPATH') or exit('No direct script access allowed');
class Auth extends CI_Controller
{
    public function index()
    {
        redirect(base_url() . 'auth/login');
    }

    public function login()
    {
        $data['title'] = 'Login - ' . $this->template->title();
        $query = $this->mymodel->selectWithQuery("SELECT * FROM banner WHERE status = 'ENABLE' ORDER BY title ASC");
        $data['data'] = $query;
        $data['content'] = $this->load->view('Login', $data, true);
        $this->load->view('Template', $data);
    }

    public function update_process()
    {
        $user = $_SESSION['user'];

        $id = $user['id'];
        $dt = $_POST['dt'];
        $dt['updated_at'] = DATE("Y-m-d H:i:s");
        $dt['updated_by'] = $user['id'];

        if ($dt['password']) {
            $dt['password'] = MD5($dt['password']);
        } else {
            unset($dt['password']);
        }

        $email = $dt['email'];
        $username = $dt['username'];

        $other_user = $this->mymodel->selectWithQuery("SELECT id FROM user
        WHERE username = '$username' AND id != '$id' ");

        if ($other_user) {
            $msg = 'Username sudah digunakan user lain!';
            echo $this->template->alert_danger($msg);
            die;
        }

        $other_user = $this->mymodel->selectWithQuery("SELECT id FROM user
        WHERE email = '$email' AND id != '$id' ");

        if ($other_user) {
            $msg = 'Email sudah digunakan user lain!';
            echo $this->template->alert_danger($msg);
            die;
        }

        unset($dt['role']);

        if (!empty($_FILES['file']['name'])) {
            $dir  = "./assets/img/user/";
            $config['upload_path']   = $dir;
            $config['allowed_types'] = 'jpg|jpeg|png';
            $config['overwrite']     = TRUE;
            $config['file_name']     = $_SESSION['user']['id'];
            $config['max_size']      = 2048;
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('file')) {
                $error = $this->upload->display_errors();
                echo $this->template->alert_danger($error);
                die;
            } else {
                $file = $this->upload->data();
                $dt['img'] = $file['file_name'];
            }
        }

        if ($this->db->update('user', $dt, array('id' => $id))) {


            $model = $this->mymodel->selectDataOne('user', array('id' => $id));

            $_SESSION['is_login'] = true;
            $_SESSION['user'] = $model;

            $msg = 'Update data was successful!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Update data failed!';
            echo $this->template->alert_danger($msg);
        }
    }


    function login_process()
    {

        if (empty($_GET)) {
            $dt = array();
            for ($i = 0; $i <= 4; $i++) {
                $dt[$i] = 'true';
            }
            $_SESSION['checkbox_dashboard'] =  $dt;
            $dt = array();
            for ($i = 0; $i <= 6; $i++) {
                $dt[$i] = 'false';
            }
            $dt[1] = 'true';
            $_SESSION['checkbox_dashboard_campaign'] =  $dt;
        }

        $email = $_POST['email'];
        $password = $_POST['password'];
        $password = md5($password);

        $model = $this->mymodel->selectDataOne('user', array('username' => $email, 'password' => $password));

        if ($model) {
            if ($model['status'] == "Aktif") {
                $_SESSION['is_login'] = true;
                $_SESSION['user'] = $model;
                $msg = 'Selamat datang di ' . $this->template->title();
                echo $this->template->alert_success($msg);
            } else {
                $msg = 'Proses login ditolak! Pastikan akun kamu aktif!';
                echo $this->template->alert_danger($msg);
            }
        } else {
            $msg = 'Pastikan username dan password kamu sudah benar!';
            echo $this->template->alert_danger($msg);
        }
    }

    public function profile()
    {
        $data['title'] = 'Profile - ' . $this->template->title();
        $user = $_SESSION['user'];
        $data['data'] = $user;
        $data['content'] = $this->load->view("Profile", $data, true);
        $this->load->view("TemplateDashboard", $data);
    }

    function logout_process()
    {
        $_SESSION['is_login'] = false;
        $_SESSION['user'] = array();
        return redirect(base_url() . 'auth/login');
    }
}
