<?php

defined('BASEPATH') or exit('No direct script access allowed');
class Ajax extends CI_Controller
{

	function refresh_token()
	{
		session_start();
	}
	public function curl()
	{
		die;
		$data_now = $this->mymodel->selectWithQuery("SELECT * FROM endorse_logs WHERE DATE(date) = '2024-06-10'");
		foreach ($data_now as $k => $v) {
			$id_endorse = $v['id_endorse'];
			$data_before = $this->mymodel->selectWithQuery("SELECT * FROM endorse_logs WHERE DATE(date) = '2024-06-09' AND id_endorse = '$id_endorse' ");
			$data_before = $data_before[0];
			print_r($data_before);
			die;

			$query = $v;
			$data_yesterday = $data_before;


			$dt['likes'] = intval($query_yesterday['likes_after'] - $query_yesterday['likes_after']);
			$dt['comment'] = intval($query_yesterday['comment_after']);
			$dt['share_save'] = intval($query_yesterday['share_save_after']);
			$dt['views'] = intval($query_yesterday['views_after']);

			$dt['likes_before'] = intval($query_yesterday['likes_after']);
			$dt['comment_before'] = intval($query_yesterday['comment_after']);
			$dt['share_save_before'] = intval($query_yesterday['share_save_after']);
			$dt['views_before'] = intval($query_yesterday['views_after']);

			$dt_tmp = array();
			foreach ($dt as $kt => $vt) {
				$dt_tmp[$kt] = strval($vt);
			}
			$dt = $dt_tmp;

			$this->db->update('endorse_logs', $dt, array('id' => $query['id']));

			print_r($query);
			print_r($data_yesterday);
			die;
			$dt = array();
			$dt = $v;
			print_r($dt);
			die;
		}
	}

	public function sync()
	{
		$data['table'] = $_GET['table'];
		return view("Sync", $data);
	}

	function checkbox()
	{
		$type = $_GET['type'];
		if ($type == "dashboard") {
			$dt = $_GET;
			unset($dt['type']);
			$key = $dt;
			$_SESSION['checkbox_dashboard'] = $key;
		} else if ($type == "dashboard_campaign") {
			$dt = $_GET;
			unset($dt['type']);
			$key = $dt;
			$_SESSION['checkbox_dashboard_campaign'] = $key;
		} else {
			$key = $_GET;
			$_SESSION['checkbox'] = $key;
		}

		header('Content-Type: application/json; charset=utf-8');
		$html['status'] = true;
		echo json_encode($html, true);
	}

	function change_fyp()
	{
		$id = $_GET['id'];

		$data = $this->mymodel->selectWithQuery("SELECT id,is_fyp FROM endorse WHERE id = '$id' ");
		$data = $data[0];

		// print_r($data);die;


		if ($data['is_fyp'] == 1) {
			$html['html'] = '<i class="bi bi-star" style="font-size:40px;color:#000"></i>';
			$is_fyp = 0;
		} else {
			$is_fyp = 1;
			$html['html'] = '<i class="bi bi-star-fill" style="font-size:40px;color:#ffd250"></i>';
		}
		if ($data) {
			$dt = array();
			$dt['is_fyp'] = $is_fyp;
			$this->db->update('endorse', $dt, array('id' => $data['id']));
		}


		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($html, true);
		die;
	}
	function get_chart_campaign()
	{

		$is_dashboard = $_GET['is_dashboard'];

		if ($is_dashboard != 'true') {
			$checkbox = $_SESSION['checkbox'];
			$skip = 0;
			for ($i = 1; $i <= 6; $i++) {
				if ($checkbox[$i] == 'false') {
					$skip++;
				}
			}
			if ($skip >= 6) {
				$html['html'] = '<i>Pastikan memilih minimal 1 filter!</i>';
				$html['table'] = '';
				header('Content-Type: application/json; charset=utf-8');
				echo json_encode($html, true);
				die;
			}
		} else {
			$checkbox = $_SESSION['checkbox_dashboard_campaign'];
			$skip = 0;
			for ($i = 1; $i <= 6; $i++) {
				if ($checkbox[$i] == 'false') {
					$skip++;
				}
			}
			if ($skip >= 6) {
				$html['html'] = '<i>Pastikan memilih minimal 1 filter!</i>';
				$html['table'] = '';
				header('Content-Type: application/json; charset=utf-8');
				echo json_encode($html, true);
				die;
			}
		}

		$id = $_GET['id'];
		$id_campaign = $_GET['id_campaign'];
		$type = $_GET['type'];
		$start_date = $_GET['start_date'];
		$until_date = $_GET['until_date'];
		$start_year = $_GET['start_year'];
		$until_year = $_GET['until_year'];
		$start_month = $_GET['start_month'];
		$until_month = $_GET['until_month'];
		$start_week = $_GET['start_week'];
		$until_week = $_GET['until_week'];
		$brand = $_GET['brand'];

		$type = $_GET['type'];
		$start_date = $_GET['start_date'];
		$until_date = $_GET['until_date'];
		$start_year = $_GET['start_year'];
		$until_year = $_GET['until_year'];
		$start_month = $_GET['start_month'];
		$until_month = $_GET['until_month'];
		$start_week = $_GET['start_week'];
		$until_week = $_GET['until_week'];
		$site = $_GET['site'];
		$customer = $_GET['customer'];
		$mpu = $_GET['mpu'];

		if ($type == "Yearly") {
			$qry_opt = " YEAR(date) ";
			$start_date = $start_year . '-01-01';
			$until_date = $until_year . '-12-31';
			$group = "  GROUP BY YEAR(date) ";
		} else if ($type == "Monthly") {
			$qry_opt = " MONTH(date) ";
			$start_month = str_pad($start_month, 2, "0", STR_PAD_LEFT);
			$until_month = str_pad($until_month, 2, "0", STR_PAD_LEFT);
			$start_date = $start_year . '-' . $start_month . '-01';
			$until_date = $start_year . '-' . $until_month . '-31';
			$group = "  GROUP BY MONTH(date) ";
		} else if ($type == "Weekly") {
			$qry_opt = " WEEK(date) ";
			$start_week = str_pad($start_week, 2, "0", STR_PAD_LEFT);
			$until_week = str_pad($until_week, 2, "0", STR_PAD_LEFT);

			$year = $start_year;
			$week = $start_week;
			$start_date = date("Y-m-d", strtotime($year . "W" . $week . "1"));

			$year = $start_year;
			$week = $until_week;
			$until_date = date("Y-m-d", strtotime($year . "W" . $week . "7"));
			$group = "  GROUP BY WEEK(date) ";
		} else {
			$qry_opt = " DATE(date) ";
			$group = "  GROUP BY DATE(date) ";
		}


		$detail = $this->mymodel->selectWithQuery("SELECT * FROM endorse_campaign
		WHERE id = '$id_campaign'");
		$detail = $detail[0];

		if ($type == "Yearly") {
			$start_date = $start_year . '-01-01';
			$until_date = $until_year . '-12-31';
		} else if ($type == "Monthly") {
			$start_month = str_pad($start_month, 2, "0", STR_PAD_LEFT);
			$until_month = str_pad($until_month, 2, "0", STR_PAD_LEFT);
			$start_date = $start_year . '-' . $start_month . '-01';
			$until_date = $start_year . '-' . $until_month . '-31';
		} else if ($type == "Weekly") {
			$start_week = str_pad($start_week, 2, "0", STR_PAD_LEFT);
			$until_week = str_pad($until_week, 2, "0", STR_PAD_LEFT);

			$year = $start_year;
			$week = $start_week;
			$start_date = date("Y-m-d", strtotime($year . "W" . $week . "1"));

			$year = $start_year;
			$week = $until_week;
			$until_date = date("Y-m-d", strtotime($year . "W" . $week . "7"));
		}

		$qry = "";
		if ($brand) {
			$qry .= " AND brand = '$brand' ";
		}

		if ($_GET['keyword_category']) {
			$keyword_category = $_GET['keyword_category'];
		} else {
			$keyword_category = "Nama Creator";
		}
		$data['keyword_category'] = $keyword_category;
		$keyword = $_GET['keyword'];

		if ($_GET['start_date']) {
			$start_date = $_GET['start_date'];
		} else {
			$start_date = DATE("Y-m-d");
			$start_date = DATE('Y-m-d', strtotime($today . " -31 days"));
		}
		if ($_GET['until_date']) {
			$until_date = $_GET['until_date'];
		} else {
			$until_date = DATE('Y-m-d');
		}
		$data['start_date'] = $start_date;
		$data['until_date'] = $until_date;
		$qry = "";

		if ($brand) {
			$qry .= " AND brand = '$brand' ";
		}

		$cat = $_GET['cat'];
		if ($cat == "Tanggal Dibuat") {
			$qry .= " AND DATE(created_at) >= '$start_date' AND DATE(created_at) <= '$until_date' ";
		} else if ($cat == "Rencana Upload") {
			$qry .= " AND DATE(rencana_at) >= '$start_date' AND DATE(rencana_at) <= '$until_date' ";
		} else if ($cat == "Tanggal Posting") {
			$qry .= " AND DATE(posting_at) >= '$start_date' AND DATE(posting_at) <= '$until_date' ";
		} else {
			// $qry .= " AND DATE(created_at) >= '$start_date' AND DATE(created_at) <= '$until_date' ";
		}

		$status = $_GET['status'];
		if ($status) {
			if ($status == 'Ada Link Upload') {
				$qry .= " AND link_upload != '' ";
			} else if ($status == 'Tidak Ada Link Upload') {
				$qry .= " AND link_upload = '' ";
			} else if ($status == 'FYP') {
				$qry .= " AND is_fyp = 1 ";
			}
		}

		$status = $_GET['endorse_status'];
		$statusArray = $status ? explode(',', $status) : [];
		$text = '';
		foreach ($statusArray as $k => $v) {
			$text .= "'" . $v . "',";
		}
		$text = substr($text, 0, -1);

		if ($text) {
			$qry .= " AND status_endorse IN ($text) ";
		}

		$platform = $_GET['platform'];
		if ($platform) {
			$qry .= " AND platform = '$platform' ";
		}

		if ($keyword) {
			if ($keyword_category == "Nama Creator") {
				$qry .= " AND nama_creator LIKE '%$keyword%' ";
			} else if ($keyword_category == "Link Upload") {
				$qry .= " AND link_upload LIKE '%$keyword%' ";
			} else if ($keyword_category == "PIC") {
				$qry .= " AND pic LIKE '%$keyword%' ";
			} else if ($keyword_category == "Platform") {
				$qry .= " AND platform LIKE '%$keyword%' ";
			} else if ($keyword_category == "Task") {
				$qry .= " AND task LIKE '%$keyword%' ";
			} else if ($keyword_category == "Keterangan") {
				$qry .= " AND endorse.desc LIKE '%$keyword%' ";
			}
		}

		// echo $qry;die;
		if ($is_dashboard != 'true') {
			$query = $this->mymodel->selectWithQuery("SELECT id
			FROM endorse
			WHERE id_campaign = '$id_campaign' $qry 
			");
		} else {
			$query = $this->mymodel->selectWithQuery("SELECT id
			FROM endorse
			WHERE 1=1 $qry 
			");
		}
		$list = '';
		foreach ($query as $k => $v) {
			$list .= "'" . $v['id'] . "',";
		}
		$list = substr($list, 0, -1);
		if ($list) {
			$ids = $_GET['ids'];
			if ($ids) {
				$qry_list .= " AND id_endorse  IN ($ids) ";
			} else {
				$qry_list .= " AND id_endorse IN ($list) ";
			}
			$qry_2 = " AND DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' ";

			if ($is_dashboard != 'true') {
				if ($checkbox[0] != 'true') {
					$list = $this->mymodel->selectWithQuery("SELECT SUM(likes_after) as likes, SUM(comment_after) as comment,SUM(share_save_after) as share_save, SUM(views_after) as views,
					SUM(total_cost) as cpm,
					COUNT(id) as endorse, $qry_opt as opt 
					FROM endorse_logs
					WHERE id_campaign = '$id_campaign' $qry_list $qry_2 $group
					");
				} else {
					$list = $this->mymodel->selectWithQuery("SELECT SUM(likes) as likes, SUM(comment) as comment,SUM(share_save) as share_save, SUM(views) as views,
					SUM(total_cost) as cpm,
					COUNT(id) as endorse, $qry_opt as opt 
					FROM endorse_logs
					WHERE id_campaign = '$id_campaign' $qry_list $qry_2 $group
					");
				}
			} else {
				if ($checkbox[0] != 'true') {
					$list = $this->mymodel->selectWithQuery("SELECT SUM(likes_after) as likes, SUM(comment_after) as comment,SUM(share_save_after) as share_save, SUM(views_after) as views,
					SUM(total_cost) as cpm,
					COUNT(id) as endorse, $qry_opt as opt 
					FROM endorse_logs
					WHERE 1=1 $qry_list $qry_2 $group
					");
				} else {
					$list = $this->mymodel->selectWithQuery("SELECT SUM(likes) as likes, SUM(comment) as comment,SUM(share_save) as share_save, SUM(views) as views,
					SUM(total_cost) as cpm,
					COUNT(id) as endorse, $qry_opt as opt 
					FROM endorse_logs
					WHERE 1=1 $qry_list $qry_2 $group
					");
				}
			}
		}

		$arr = array();


		if ($type == "Yearly") {
			$range = array();
			for ($i = $start_year; $i <= $until_year; $i++) {
				$range[] = intval($i);
			}
			foreach ($range as $k2 => $v2) {
				$val_1 = 0;
				$val_2 = 0;
				$val_3 = 0;
				$val_4 = 0;
				$val_5 = 0;
				$val_6 = 0;


				foreach ($list as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_1 += $v['likes'];
						$val_2 += $v['comment'];
						$val_3 += $v['share_save'];
						$val_4 += $v['views'];
						$val_5 += $v['cpm'];
						$val_6 += $v['endorse'];
					}
				}

				$i = $k2;
				$v['opt'] = substr($v2, -2);
				$arr[$i]['opt'] = $v['opt'];
				$arr[$i]['val_1'] = $val_1;
				$arr[$i]['val_1'] = round($arr[$i]['val_1'], 2);
				$arr[$i]['val_2'] = $val_2;
				$arr[$i]['val_2'] = round($arr[$i]['val_2'], 2);
				$arr[$i]['val_3'] = $val_3;
				$arr[$i]['val_3'] = round($arr[$i]['val_3'], 2);
				$arr[$i]['val_4'] = $val_4;
				$arr[$i]['val_4'] = round($arr[$i]['val_4'], 2);
				$arr[$i]['val_5'] = $val_5;
				$arr[$i]['val_5'] = round($arr[$i]['val_5'], 2);
				$arr[$i]['val_6'] = $val_6;
				$arr[$i]['val_6'] = round($arr[$i]['val_6'], 2);
			}
		} else if ($type == "Monthly") {
			$range = array();
			for ($i = $start_month; $i <= $until_month; $i++) {
				$range[] = intval($i);
			}
			foreach ($range as $k2 => $v2) {
				$val_1 = 0;
				$val_2 = 0;
				$val_3 = 0;
				$val_4 = 0;
				$val_5 = 0;
				$val_6 = 0;


				foreach ($list as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_1 += $v['likes'];
						$val_2 += $v['comment'];
						$val_3 += $v['share_save'];
						$val_4 += $v['views'];
						$val_5 += $v['cpm'];
						$val_6 += $v['endorse'];
					}
				}

				$i = $k2;
				$v['opt'] = substr($v2, -2);
				$arr[$i]['opt'] = $v['opt'];
				$arr[$i]['val_1'] = $val_1;
				$arr[$i]['val_1'] = round($arr[$i]['val_1'], 2);
				$arr[$i]['val_2'] = $val_2;
				$arr[$i]['val_2'] = round($arr[$i]['val_2'], 2);
				$arr[$i]['val_3'] = $val_3;
				$arr[$i]['val_3'] = round($arr[$i]['val_3'], 2);
				$arr[$i]['val_4'] = $val_4;
				$arr[$i]['val_4'] = round($arr[$i]['val_4'], 2);
				$arr[$i]['val_5'] = $val_5;
				$arr[$i]['val_5'] = round($arr[$i]['val_5'], 2);
				$arr[$i]['val_6'] = $val_6;
				$arr[$i]['val_6'] = round($arr[$i]['val_6'], 2);
			}
		} else if ($type == "Weekly") {
			$range = array();
			for ($i = $start_week; $i <= $until_week; $i++) {
				$range[] = intval($i);
			}

			foreach ($range as $k2 => $v2) {
				$val_1 = 0;
				$val_2 = 0;
				$val_3 = 0;
				$val_4 = 0;
				$val_5 = 0;
				$val_6 = 0;


				foreach ($list as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_1 += $v['likes'];
						$val_2 += $v['comment'];
						$val_3 += $v['share_save'];
						$val_4 += $v['views'];
						$val_5 += $v['cpm'];
						$val_6 += $v['endorse'];
					}
				}

				$i = $k2;
				$v['opt'] = substr($v2, -2);
				$arr[$i]['opt'] = $v['opt'];
				$arr[$i]['val_1'] = $val_1;
				$arr[$i]['val_1'] = round($arr[$i]['val_1'], 2);
				$arr[$i]['val_2'] = $val_2;
				$arr[$i]['val_2'] = round($arr[$i]['val_2'], 2);
				$arr[$i]['val_3'] = $val_3;
				$arr[$i]['val_3'] = round($arr[$i]['val_3'], 2);
				$arr[$i]['val_4'] = $val_4;
				$arr[$i]['val_4'] = round($arr[$i]['val_4'], 2);
				$arr[$i]['val_5'] = $val_5;
				$arr[$i]['val_5'] = round($arr[$i]['val_5'], 2);
				$arr[$i]['val_6'] = $val_6;
				$arr[$i]['val_6'] = round($arr[$i]['val_6'], 2);
			}
		} else {
			$range = ($this->createRange($start_date, $until_date));
			foreach ($range as $k2 => $v2) {

				$val_1 = 0;
				$val_2 = 0;
				$val_3 = 0;
				$val_4 = 0;
				$val_5 = 0;
				$val_6 = 0;


				foreach ($list as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_1 += $v['likes'];
						$val_2 += $v['comment'];
						$val_3 += $v['share_save'];
						$val_4 += $v['views'];
						$val_5 += $v['cpm'];
						$val_6 += $v['endorse'];
					}
				}

				$i = $k2;
				// $v['opt'] = substr($v2, -2);
				$v['opt'] = $v2;
				$arr[$i]['opt'] = $v['opt'];
				$arr[$i]['val_1'] = $val_1;
				$arr[$i]['val_1'] = round($arr[$i]['val_1'], 2);
				$arr[$i]['val_2'] = $val_2;
				$arr[$i]['val_2'] = round($arr[$i]['val_2'], 2);
				$arr[$i]['val_3'] = $val_3;
				$arr[$i]['val_3'] = round($arr[$i]['val_3'], 2);
				$arr[$i]['val_4'] = $val_4;
				$arr[$i]['val_4'] = round($arr[$i]['val_4'], 2);
				$arr[$i]['val_5'] = $val_5;
				$arr[$i]['val_5'] = round($arr[$i]['val_5'], 2);
				$arr[$i]['val_6'] = $val_6;
				$arr[$i]['val_6'] = round($arr[$i]['val_6'], 2);
			}
		}

		$arr_new = array();

		$count = count($arr);

		if ($type == "Yearly") {
			for ($i = 0; $i < $count; $i++) {
				$arr_new[$i] = $arr[$i];
			};
		} else if ($type == "Monthly") {
			for ($i = 0; $i < $count; $i++) {
				$arr_new[$i] = $arr[$i];
			};
		} else if ($type == "Weekly") {
			for ($i = 0; $i < $count; $i++) {
				$arr_new[$i] = $arr[$i];
			};
		} else {
			for ($i = 0; $i < $count; $i++) {
				$arr_new[$i] = $arr[$i];
			};
		}

		$th_table = "";
		$td_1 = "";
		$td_2 = "";
		$td_3 = "";
		$td_4 = "";
		$td_5 = "";
		$td_6 = "";

		$opt = "";
		$val = "";
		$a = "";
		$b = "";
		$c = "";
		$d = "";
		$e = "";
		$f = "";
		$color = "";
		$val_arr_1 = array(0, 0);
		$val_arr_2 = array(0, 0);
		$val_arr_3 = array(0, 0);
		$val_arr_4 = array(0, 0);
		$val_arr_5 = array(0, 0);
		$val_arr_6 = array(0, 0);

		$data['checkbox'] = $_SESSION['checkbox'];

		foreach ($arr_new as $k => $v) {
			if ($v['val_5'] > 0 &&  $v['val_4'] > 0) {
				$v['val_5'] = $v['val_5'] / $v['val_4'] * 1000;
			} else {
				$v['val_5'] = 0;
			}

			// $v['opt'] = substr($v['opt'], -2);
			$v['opt'] = DATE("d M Y", strtotime($v['opt']));
			$opt .= "'" . $v['opt'] . "',";
			if ($v) {
				$a .= "'" . $this->template->separator_number_only($v['val_1']) . "',";
				$b .= "'" . $this->template->separator_number_only($v['val_2']) . "',";
				$c .= "'" . $this->template->separator_number_only($v['val_3']) . "',";
				$d .= "'" . $this->template->separator_number_only($v['val_4']) . "',";
				$e .= "'" . $this->template->separator_number_only($v['val_5']) . "',";
				$f .= "'" . $this->template->separator_number_only($v['val_6']) . "',";

				$val_arr_3[] = round($v['val_1']);
				$val_arr_4[] = round($v['val_2']);
				$val_arr_5[] = round($v['val_3']);
				$val_arr_1[] = round($v['val_4']);
				$val_arr_2[] = round($v['val_5']);
				$val_arr_6[] = round($v['val_6']);

				$likes += $v['val_1'];
				$comment += $v['val_2'];
				$view += $v['val_4'];
				$cpm += $v['val_5'];
				$share += $v['val_3'];
			}
			if ($v['opt']) {
				$th_table .= "<th  style='font-size:12px!important'>" . $v['opt'] . "</th>";
				$td_1 .= "<td>" . $this->template->separator_only((($v['val_1']))) . "</td>";
				$td_2 .= "<td>" . $this->template->separator_only((($v['val_2']))) . "</td>";
				$td_3 .= "<td>" . $this->template->separator_only((($v['val_3']))) . "</td>";
				$td_4 .= "<td>" . $this->template->separator_only((($v['val_4']))) . "</td>";
				$td_5 .= "<td>" . $this->template->separator_only((($v['val_5']))) . "</td>";
				$td_6 .= "<td>" . $this->template->separator_only((($v['val_6']))) . "</td>";
			}

			$color .= "'" . $v['color'] . "',";
		}

		if ($checkbox[0] == 'false') {
			$likes = 0;
			$comment = 0;
			$view = 0;
			$cpm = 0;
			$share = 0;
			foreach ($val_arr_3 as $k => $v) {
				if ($v > 0) {
					$likes = $v;
				}
			}
			foreach ($val_arr_4 as $k => $v) {
				if ($v > 0) {
					$comment = $v;
				}
			}
			foreach ($val_arr_1 as $k => $v) {
				if ($v > 0) {
					$view = $v;
				}
			}
			foreach ($val_arr_2 as $k => $v) {
				if ($v > 0) {
					$cpm = $v;
				}
			}
			foreach ($val_arr_5 as $k => $v) {
				if ($v > 0) {
					$share = $v;
				}
			}
		}

		$html['summary']['likes'] = $this->template->separator_only($likes);
		$html['summary']['comment'] = $this->template->separator_only($comment);
		$html['summary']['view'] = $this->template->separator_only($view);
		$html['summary']['cpm'] = $this->template->separator_only($cpm);
		$html['summary']['share'] = $this->template->separator_only($share);


		$min_1 = min($val_arr_1);
		$max_1 = max($val_arr_1);
		$min_2 = min($val_arr_2);
		$max_2 = max($val_arr_2);
		$min_3 = min($val_arr_3);
		$max_3 = max($val_arr_3);
		$min_4 = min($val_arr_4);
		$max_4 = max($val_arr_4);
		$min_5 = min($val_arr_5);
		$max_5 = max($val_arr_5);
		$min_6 = min($val_arr_6);
		$max_6 = max($val_arr_6);

		$min_1 = 0;
		$min_2 = 0;
		if ($checkbox[1] == 'true') {
			$max_1 = $max_1;
		} else {
			$max_1 = 0;
		}
		if ($checkbox[2] == 'true') {
			if ($max_2 > $max_1) {
				$max_1 = $max_2;
			}
		}
		if ($checkbox[3] == 'true') {
			if ($max_3 > $max_1) {
				$max_1 = $max_3;
			}
		}
		if ($checkbox[4] == 'true') {
			if ($max_4 > $max_1) {
				$max_1 = $max_4;
			}
		}
		if ($checkbox[5] == 'true') {
			if ($max_5 > $max_1) {
				$max_1 = $max_5;
			}
		}

		if ($checkbox[6] == 'true') {
			if ($max_6 > $max_1) {
				$max_1 = $max_6;
			}
		}

		$max_1 = intval($max_1);

		// echo $max_1;die;

		if ($max_1 > 10000000) {
			$max_1 =  ($max_1 - ($max_1 % 10000000)) * 2.2;
		} else if ($max_1 > 1000000) {
			$max_1 =  ($max_1 - ($max_1 % 1000000)) * 2.2;
		} else if ($max_1 > 100000) {
			$max_1 =  ($max_1 - ($max_1 % 100000)) * 2.2;
		} else if ($max_1 > 10000) {
			$max_1 =  ($max_1 - ($max_1 % 10000)) * 2.2;
		} else if ($max_1 > 1000) {
			$max_1 =  ($max_1 - ($max_1 % 1000)) * 2.2;
		} else if ($max_1 > 100) {
			$max_1 =  ($max_1 - ($max_1 % 100)) * 2.2;
		} else if ($max_1 > 10) {
			$max_1 =  ($max_1 - ($max_1 % 10)) * 2.2;
		} else if ($max_1 > 0) {
			$max_1 =  ($max_1 - ($max_1 % 1)) * 2.2;
		}

		// $max_1 = intval($max_1 * 2);
		// echo $max_1;die;

		$item_1 = '';
		$item_2 = '';
		$item_3 = '';

		if ($checkbox[1] == 'true') {
			$item_1 .= '
			{
				type: "line",
				label: " Views ",
				fill: "start",
    			backgroundColor: gradient_4,
				borderColor: ["' . $this->template->hex(3) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $d . '],
				yAxisID: "l4",
			},	
			';
			$item_3 .= '
			<tr>
													<td class="text-start"> 
														<div class="d-flex justify-content-start">
															<div style="background-color: ' . $this->template->hex(3) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
															</div>Views
														</div>
													</td>
													' . $td_4 . '
													</tr>
			';
		}
		if ($checkbox[2] == 'true') {
			$item_1 .= '
			{
				type: "line",
				label: " CPM ",
				fill: "start",
    			backgroundColor: gradient_5,
				borderColor: ["' . $this->template->hex(4) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $e . '],
				yAxisID: "l5",
			},
			';
			$item_3 .= '
			
			<tr>
			<td class="text-start"> 
				<div class="d-flex justify-content-start">
					<div style="background-color: ' . $this->template->hex(4) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
					</div>CPM
				</div>
			</td>
			' . $td_5 . '
			</tr>
			';
		}

		if ($checkbox[3] == 'true') {
			$item_1 .= '
			{
				type: "line",
				label: " Likes ",
				fill: "start",
    			backgroundColor: gradient_1,
				borderColor: ["' . $this->template->hex(0) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $a . '],
				yAxisID: "l1",
			},
			';
			$item_3 .= '
			<tr>
													<td class="text-start"> 
														<div class="d-flex justify-content-start">
															<div style="background-color: ' . $this->template->hex(0) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
															</div>Likes
														</div>
													</td>
													' . $td_1 . '
													</tr>
													';
		}
		if ($checkbox[4] == 'true') {
			$item_1 .= '
			{
				type: "line",
				label: " Comments ",
				fill: "start",
    			backgroundColor: gradient_2,
				borderColor: ["' . $this->template->hex(1) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $b . '],
				yAxisID: "l2",
			},
			';
			$item_3 .= '
			<tr>
													<td class="text-start"> 
														<div class="d-flex justify-content-start">
															<div style="background-color: ' . $this->template->hex(1) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
															</div>Comments
														</div>
													</td>
													' . $td_2 . '
													</tr>
			';
		}
		if ($checkbox[5] == 'true') {
			$item_1 .= '
			{
				type: "line",
				label: " Share & Save ",
				fill: "start",
    			backgroundColor: gradient_3,
				borderColor: ["' . $this->template->hex(2) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $c . '],
				yAxisID: "l3",
			},	
			';
			$item_3 .= '
			<tr>
													<td class="text-start"> 
														<div class="d-flex justify-content-start">
															<div style="background-color: ' . $this->template->hex(2) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
															</div>Share & Save
														</div>
													</td>
													' . $td_3 . '
													</tr>
			';
		}

		if ($checkbox[6] == 'true') {
			$item_1 .= '
			{
				type: "line",
				label: " Konten ",
				fill: "start",
    			backgroundColor: gradient_6,
				borderColor: ["' . $this->template->hex(5) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $f . '],
				yAxisID: "l6",
			},
			';
			$item_3 .= '
			
			<tr>
			<td class="text-start"> 
				<div class="d-flex justify-content-start">
					<div style="background-color: ' . $this->template->hex(5) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
					</div>Konten
				</div>
			</td>
			' . $td_6 . '
			</tr>
			';
		}


		$key = 'get_chart_campaign_' . DATE("Ymdhis") . rand(1000000000, 9999999999);

		$html['html'] = '
                                                    <canvas class="chart" id="' . $key . '"></canvas>
                                                    <script>
													const ' . $key . ' = document.getElementById(
                                                        "' . $key . '").getContext("2d");


var gradient_1 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_1.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(0)) . '")
gradient_1.addColorStop(0.75, "rgba(225, 225, 225, 0)")

var gradient_2 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_2.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(1)) . '")
gradient_2.addColorStop(0.75, "rgba(225, 225, 225, 0)")

var gradient_3 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_3.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(2)) . '")
gradient_3.addColorStop(0.75, "rgba(225, 225, 225, 0)")

var gradient_4 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_4.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(3)) . '")
gradient_4.addColorStop(0.75, "rgba(225, 225, 225, 0)")

var gradient_5 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_5.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(4)) . '")
gradient_5.addColorStop(0.75, "rgba(225, 225, 225, 0)")

var gradient_6 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_6.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(5)) . '")
gradient_6.addColorStop(0.75, "rgba(225, 225, 225, 0)")

                                                    new Chart(' . $key . ', {
                                                        type: "line",
                                                        data: {
                                                            datasets: [
                                                                ' . $item_1 . '									
                                                            ],
                                                            labels: [' . $opt . ']
                                                        },
                                                        options: {
															responsive: true,
															maintainAspectRatio: false, 
															aspectRatio: 3.1, 
															interaction: {
															mode: "index",
															intersect: false,
														},
														plugins:{
															legend: { 
																display:false,
																labels: {
																  font: {
																	size: 8
																  }
																}
															},
														},
														stacked: false,
														
														scales: {
														x:{
															ticks: {												
																autoSkip: true,	
																maxTicksLimit: 10,											
																font: {													
																	size: 11,												
																}											
															},
															grid: {
																display: false,
															}
														},
														l1: {
															type: "linear",
															display: true,
															position: "left",
															min:0,
															max:' . $max_1 . ',
															ticks: {												
																autoSkip: false,												
																font: {													
																	size: 8,												
																}											
															}
														},
														l2: {
															type: "linear",
															display: false,
															position: "left",
															min:0,
															max:' . $max_1 . ',
														},
														l3: {
															type: "linear",
															display: false,
															position: "left",
															min:0,
															max:' . $max_1 . ',
														},
														l4: {
															type: "linear",
															display: false,
															position: "left",
															min:0,
															max:' . $max_1 . ',
														},
														l5: {
															type: "linear",
															display: false,
															position: "left",
															min:0,
															max:' . $max_1 . ',
														},
														l6: {
															type: "linear",
															display: false,
															position: "left",
															min:0,
															max:' . $max_1 . ',
														},
														},
														},

                                                    });
                                                    </script>';

		$html['table'] = '
													<div class="table-responsive">
													<table class="table able-bordered table-stats" style="margin-bottom:0px!important">
													<tr>
													<th class="text-start"  style="font-size:12px!important">#</th>
													' . $th_table . '
													</tr>
													' . $item_3 . '
													</table>
													</div>
													';
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($html, true);
	}

	function get_chart_endorse()
	{

		$checkbox = $_SESSION['checkbox'];

		$skip = 0;
		for ($i = 1; $i <= 5; $i++) {
			if ($checkbox[$i] == 'false') {
				$skip++;
			}
		}
		if ($skip >= 6) {
			$html['html'] = '<i>Pastikan memilih minimal 1 filter!</i>';
			$html['table'] = '';
			header('Content-Type: application/json; charset=utf-8');
			echo json_encode($html, true);
			die;
		}


		$id = $_GET['id'];
		$type = $_GET['type'];
		$start_date = $_GET['start_date'];
		$until_date = $_GET['until_date'];
		$start_year = $_GET['start_year'];
		$until_year = $_GET['until_year'];
		$start_month = $_GET['start_month'];
		$until_month = $_GET['until_month'];
		$start_week = $_GET['start_week'];
		$until_week = $_GET['until_week'];
		$site = $_GET['site'];
		$customer = $_GET['customer'];
		$mpu = $_GET['mpu'];
		$platform = $_GET['platform'];

		if ($type == "Yearly") {
			$qry_opt = " YEAR(date) ";
			$start_date = $start_year . '-01-01';
			$until_date = $until_year . '-12-31';
			$group = "  GROUP BY YEAR(date) ";
		} else if ($type == "Monthly") {
			$qry_opt = " MONTH(date) ";
			$start_month = str_pad($start_month, 2, "0", STR_PAD_LEFT);
			$until_month = str_pad($until_month, 2, "0", STR_PAD_LEFT);
			$start_date = $start_year . '-' . $start_month . '-01';
			$until_date = $start_year . '-' . $until_month . '-31';
			$group = "  GROUP BY MONTH(date) ";
		} else if ($type == "Weekly") {
			$qry_opt = " WEEK(date) ";
			$start_week = str_pad($start_week, 2, "0", STR_PAD_LEFT);
			$until_week = str_pad($until_week, 2, "0", STR_PAD_LEFT);

			$year = $start_year;
			$week = $start_week;
			$start_date = date("Y-m-d", strtotime($year . "W" . $week . "1"));

			$year = $start_year;
			$week = $until_week;
			$until_date = date("Y-m-d", strtotime($year . "W" . $week . "7"));
			$group = "  GROUP BY WEEK(date) ";
		} else {
			$qry_opt = " DATE(date) ";
			$group = "  GROUP BY DATE(date) ";
		}


		if ($checkbox[0] != 'true') {
			$list = $this->mymodel->selectWithQuery("SELECT likes_after as likes, comment_after as comment,share_save_after as share_save, views_after as views,
			SUM(total_cost) as cpm,
			$qry_opt as opt 
			FROM endorse_logs
			WHERE id_endorse = '$id' $qry $group
			");
		} else {
			$list = $this->mymodel->selectWithQuery("SELECT likes, comment,share_save, views,
			SUM(total_cost) as cpm,
			$qry_opt as opt 
			FROM endorse_logs
			WHERE id_endorse = '$id' $qry $group
			");
		}



		$arr = array();


		if ($type == "Yearly") {
			$range = array();
			for ($i = $start_year; $i <= $until_year; $i++) {
				$range[] = intval($i);
			}
			foreach ($range as $k2 => $v2) {


				$val_1 = 0;
				$val_2 = 0;
				$val_3 = 0;
				$val_4 = 0;
				$val_5 = 0;

				foreach ($list as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_1 += $v['likes'];
						$val_2 += $v['comment'];
						$val_3 += $v['share_save'];
						$val_4 += $v['views'];
						$val_5 += $v['cpm'];
					}
				}

				$i = $k2;
				$v['opt'] = substr($v2, -2);
				$arr[$i]['opt'] = $v['opt'];
				$arr[$i]['val_1'] = $val_1;
				$arr[$i]['val_1'] = round($arr[$i]['val_1'], 2);
				$arr[$i]['val_2'] = $val_2;
				$arr[$i]['val_2'] = round($arr[$i]['val_2'], 2);
				$arr[$i]['val_3'] = $val_3;
				$arr[$i]['val_3'] = round($arr[$i]['val_3'], 2);
				$arr[$i]['val_4'] = $val_4;
				$arr[$i]['val_4'] = round($arr[$i]['val_4'], 2);
				$arr[$i]['val_5'] = $val_5;
				$arr[$i]['val_5'] = round($arr[$i]['val_5'], 2);
			}
		} else if ($type == "Monthly") {
			$range = array();
			for ($i = $start_month; $i <= $until_month; $i++) {
				$range[] = intval($i);
			}
			foreach ($range as $k2 => $v2) {


				$val_1 = 0;
				$val_2 = 0;
				$val_3 = 0;
				$val_4 = 0;
				$val_5 = 0;

				foreach ($list as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_1 += $v['likes'];
						$val_2 += $v['comment'];
						$val_3 += $v['share_save'];
						$val_4 += $v['views'];
						$val_5 += $v['cpm'];
					}
				}

				$i = $k2;
				$v['opt'] = substr($v2, -2);
				$arr[$i]['opt'] = $v['opt'];
				$arr[$i]['val_1'] = $val_1;
				$arr[$i]['val_1'] = round($arr[$i]['val_1'], 2);
				$arr[$i]['val_2'] = $val_2;
				$arr[$i]['val_2'] = round($arr[$i]['val_2'], 2);
				$arr[$i]['val_3'] = $val_3;
				$arr[$i]['val_3'] = round($arr[$i]['val_3'], 2);
				$arr[$i]['val_4'] = $val_4;
				$arr[$i]['val_4'] = round($arr[$i]['val_4'], 2);
				$arr[$i]['val_5'] = $val_5;
				$arr[$i]['val_5'] = round($arr[$i]['val_5'], 2);
			}
		} else if ($type == "Weekly") {
			$range = array();
			for ($i = $start_week; $i <= $until_week; $i++) {
				$range[] = intval($i);
			}

			foreach ($range as $k2 => $v2) {


				$val_1 = 0;
				$val_2 = 0;
				$val_3 = 0;
				$val_4 = 0;
				$val_5 = 0;

				foreach ($list as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_1 += $v['likes'];
						$val_2 += $v['comment'];
						$val_3 += $v['share_save'];
						$val_4 += $v['views'];
						$val_5 += $v['cpm'];
					}
				}

				$i = $k2;
				$v['opt'] = substr($v2, -2);
				$arr[$i]['opt'] = $v['opt'];
				$arr[$i]['val_1'] = $val_1;
				$arr[$i]['val_1'] = round($arr[$i]['val_1'], 2);
				$arr[$i]['val_2'] = $val_2;
				$arr[$i]['val_2'] = round($arr[$i]['val_2'], 2);
				$arr[$i]['val_3'] = $val_3;
				$arr[$i]['val_3'] = round($arr[$i]['val_3'], 2);
				$arr[$i]['val_4'] = $val_4;
				$arr[$i]['val_4'] = round($arr[$i]['val_4'], 2);
				$arr[$i]['val_5'] = $val_5;
				$arr[$i]['val_5'] = round($arr[$i]['val_5'], 2);
			}
		} else {
			$range = ($this->createRange($start_date, $until_date));
			foreach ($range as $k2 => $v2) {

				$val_1 = 0;
				$val_2 = 0;
				$val_3 = 0;
				$val_4 = 0;
				$val_5 = 0;

				foreach ($list as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_1 += $v['likes'];
						$val_2 += $v['comment'];
						$val_3 += $v['share_save'];
						$val_4 += $v['views'];
						$val_5 += $v['cpm'];
					}
				}

				$i = $k2;
				// $v['opt'] = substr($v2, -2);
				$v['opt'] = $v2;
				$arr[$i]['opt'] = $v['opt'];
				$arr[$i]['val_1'] = $val_1;
				$arr[$i]['val_1'] = round($arr[$i]['val_1'], 2);
				$arr[$i]['val_2'] = $val_2;
				$arr[$i]['val_2'] = round($arr[$i]['val_2'], 2);
				$arr[$i]['val_3'] = $val_3;
				$arr[$i]['val_3'] = round($arr[$i]['val_3'], 2);
				$arr[$i]['val_4'] = $val_4;
				$arr[$i]['val_4'] = round($arr[$i]['val_4'], 2);
				$arr[$i]['val_5'] = $val_5;
				$arr[$i]['val_5'] = round($arr[$i]['val_5'], 2);
			}
		}


		$arr_new = array();

		$count = count($arr);

		if ($type == "Yearly") {
			for ($i = 0; $i < $count; $i++) {
				$arr_new[$i] = $arr[$i];
			};
		} else if ($type == "Monthly") {
			for ($i = 0; $i < $count; $i++) {
				$arr_new[$i] = $arr[$i];
			};
		} else if ($type == "Weekly") {
			for ($i = 0; $i < $count; $i++) {
				$arr_new[$i] = $arr[$i];
			};
		} else {
			for ($i = 0; $i < $count; $i++) {
				$arr_new[$i] = $arr[$i];
			};
		}

		$th_table = "";
		$td_1 = "";
		$td_2 = "";
		$td_3 = "";
		$td_4 = "";
		$td_5 = "";

		$opt = "";
		$val = "";
		$a = "";
		$b = "";
		$c = "";
		$d = "";
		$e = "";
		$color = "";
		$val_arr_1 = array(0, 0);
		$val_arr_2 = array(0, 0);
		$val_arr_3 = array(0, 0);
		$val_arr_4 = array(0, 0);
		$val_arr_5 = array(0, 0);
		foreach ($arr_new as $k => $v) {

			if ($v['val_5'] > 0 &&  $v['val_4'] > 0) {
				$v['val_5'] = $v['val_5'] / $v['val_4'] * 1000;
			} else {
				$v['val_5'] = 0;
			}


			// $v['opt'] = substr($v['opt'], -2);
			$v['opt'] = DATE("d M Y", strtotime($v['opt']));
			$opt .= "'" . $v['opt'] . "',";
			if ($v) {
				$a .= "'" . $this->template->separator_number_only($v['val_1']) . "',";
				$b .= "'" . $this->template->separator_number_only($v['val_2']) . "',";
				$c .= "'" . $this->template->separator_number_only($v['val_3']) . "',";
				$d .= "'" . $this->template->separator_number_only($v['val_4']) . "',";
				$e .= "'" . $this->template->separator_number_only($v['val_5']) . "',";

				$val_arr_1[] = round($v['val_4']);
				$val_arr_2[] = round($v['val_5']);
				$val_arr_3[] = round($v['val_1']);
				$val_arr_4[] = round($v['val_2']);
				$val_arr_5[] = round($v['val_3']);
			}
			if ($v['opt']) {
				$th_table .= "<th  style='font-size:12px!important'>" . $v['opt'] . "</th>";
				$td_1 .= "<td>" . $this->template->separator_only((($v['val_1']))) . "</td>";
				$td_2 .= "<td>" . $this->template->separator_only((($v['val_2']))) . "</td>";
				$td_3 .= "<td>" . $this->template->separator_only((($v['val_3']))) . "</td>";
				$td_4 .= "<td>" . $this->template->separator_only((($v['val_4']))) . "</td>";
				$td_5 .= "<td>" . $this->template->separator_only((($v['val_5']))) . "</td>";
			}

			$color .= "'" . $v['color'] . "',";
		}


		$min_1 = min($val_arr_1);
		$max_1 = max($val_arr_1);
		$min_2 = min($val_arr_2);
		$max_2 = max($val_arr_2);
		$min_3 = min($val_arr_3);
		$max_3 = max($val_arr_3);
		$min_4 = min($val_arr_4);
		$max_4 = max($val_arr_4);
		$min_5 = min($val_arr_5);
		$max_5 = max($val_arr_5);

		$min_1 = 0;
		$min_2 = 0;
		if ($checkbox[1] == 'true') {
			$max_1 = $max_1;
		} else {
			$max_1 = 0;
		}
		if ($checkbox[2] == 'true') {
			if ($max_2 > $max_1) {
				$max_1 = $max_2;
			}
		}
		if ($checkbox[3] == 'true') {
			if ($max_3 > $max_1) {
				$max_1 = $max_3;
			}
		}
		if ($checkbox[4] == 'true') {
			if ($max_4 > $max_1) {
				$max_1 = $max_4;
			}
		}
		if ($checkbox[5] == 'true') {
			if ($max_5 > $max_1) {
				$max_1 = $max_5;
			}
		}

		$max_1 = intval($max_1);

		if ($max_1 > 10000000) {
			$max_1 =  ($max_1 - ($max_1 % 10000000)) * 2.2;
		} else if ($max_1 > 1000000) {
			$max_1 =  ($max_1 - ($max_1 % 1000000)) * 2.2;
		} else if ($max_1 > 100000) {
			$max_1 =  ($max_1 - ($max_1 % 100000)) * 2.2;
		} else if ($max_1 > 10000) {
			$max_1 =  ($max_1 - ($max_1 % 10000)) * 2.2;
		} else if ($max_1 > 1000) {
			$max_1 =  ($max_1 - ($max_1 % 1000)) * 2.2;
		} else if ($max_1 > 100) {
			$max_1 =  ($max_1 - ($max_1 % 100)) * 2.2;
		} else if ($max_1 > 10) {
			$max_1 =  ($max_1 - ($max_1 % 10)) * 2.2;
		} else if ($max_1 > 0) {
			$max_1 =  ($max_1 - ($max_1 % 1)) * 2.2;
		}
		// echo $max_1;die;

		$item_1 = '';
		$item_2 = '';
		$item_3 = '';

		if ($checkbox[1] == 'true') {
			$item_1 .= '
			{
				type: "line",
				label: " Views ",
				fill: "start",
    			backgroundColor: gradient_4,
				borderColor: ["' . $this->template->hex(3) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $d . '],
				yAxisID: "l4",
			},	
			';
			$item_3 .= '
			<tr>
													<td class="text-start"> 
														<div class="d-flex justify-content-start">
															<div style="background-color: ' . $this->template->hex(3) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
															</div>Views
														</div>
													</td>
													' . $td_4 . '
													</tr>
			';
		}
		if ($checkbox[2] == 'true') {
			$item_1 .= '
			{
				type: "line",
				label: " CPM ",
				fill: "start",
    			backgroundColor: gradient_5,
				borderColor: ["' . $this->template->hex(4) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $e . '],
				yAxisID: "l5",
			},
			';
			$item_3 .= '
			
			<tr>
			<td class="text-start"> 
				<div class="d-flex justify-content-start">
					<div style="background-color: ' . $this->template->hex(4) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
					</div>CPM
				</div>
			</td>
			' . $td_5 . '
			</tr>
			';
		}

		if ($checkbox[3] == 'true') {
			$item_1 .= '
			{
				type: "line",
				label: " Likes ",
				fill: "start",
    			backgroundColor: gradient_1,
				borderColor: ["' . $this->template->hex(0) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $a . '],
				yAxisID: "l1",
			},
			';
			$item_3 .= '
			<tr>
													<td class="text-start"> 
														<div class="d-flex justify-content-start">
															<div style="background-color: ' . $this->template->hex(0) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
															</div>Likes
														</div>
													</td>
													' . $td_1 . '
													</tr>
													';
		}
		if ($checkbox[4] == 'true') {
			$item_1 .= '
			{
				type: "line",
				label: " Comments ",
				fill: "start",
    			backgroundColor: gradient_2,
				borderColor: ["' . $this->template->hex(1) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $b . '],
				yAxisID: "l2",
			},
			';
			$item_3 .= '
			<tr>
													<td class="text-start"> 
														<div class="d-flex justify-content-start">
															<div style="background-color: ' . $this->template->hex(1) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
															</div>Comments
														</div>
													</td>
													' . $td_2 . '
													</tr>
			';
		}
		if ($checkbox[5] == 'true') {
			$item_1 .= '
			{
				type: "line",
				label: " Share & Save ",
				fill: "start",
    			backgroundColor: gradient_3,
				borderColor: ["' . $this->template->hex(2) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $c . '],
				yAxisID: "l3",
			},	
			';
			$item_3 .= '
			<tr>
													<td class="text-start"> 
														<div class="d-flex justify-content-start">
															<div style="background-color: ' . $this->template->hex(2) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
															</div>Share & Save
														</div>
													</td>
													' . $td_3 . '
													</tr>
			';
		}


		$key = 'get_chart_campaign_' . DATE("Ymdhis") . rand(1000000000, 9999999999);

		$html['html'] = '
                                                    <canvas class="chart" id="' . $key . '"></canvas>
                                                    <script>
													const ' . $key . ' = document.getElementById(
                                                        "' . $key . '").getContext("2d");


var gradient_1 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_1.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(0)) . '")
gradient_1.addColorStop(0.75, "rgba(225, 225, 225, 0)")

var gradient_2 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_2.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(1)) . '")
gradient_2.addColorStop(0.75, "rgba(225, 225, 225, 0)")

var gradient_3 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_3.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(2)) . '")
gradient_3.addColorStop(0.75, "rgba(225, 225, 225, 0)")

var gradient_4 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_4.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(3)) . '")
gradient_4.addColorStop(0.75, "rgba(225, 225, 225, 0)")

var gradient_5 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_5.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(4)) . '")
gradient_5.addColorStop(0.75, "rgba(225, 225, 225, 0)")

var gradient_6 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_6.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(5)) . '")
gradient_6.addColorStop(0.75, "rgba(225, 225, 225, 0)")

                                                    new Chart(' . $key . ', {
                                                        type: "line",
                                                        data: {
                                                            datasets: [
                                                                ' . $item_1 . '									
                                                            ],
                                                            labels: [' . $opt . ']
                                                        },
                                                        options: {
															responsive: true,
															maintainAspectRatio: false, 
															aspectRatio: 3.1, 
															interaction: {
															mode: "index",
															intersect: false,
														},
														plugins:{
															legend: { 
																display:false,
																labels: {
																  font: {
																	size: 8
																  }
																}
															},
														},
														stacked: false,
														
														scales: {
														x:{
															ticks: {												
																autoSkip: true,	
																maxTicksLimit: 10,											
																font: {													
																	size: 11,												
																}											
															},
															grid: {
																display: false,
															}
														},
														l1: {
															type: "linear",
															display: true,
															position: "left",
															min:0,
															max:' . $max_1 . ',
															ticks: {												
																autoSkip: false,												
																font: {													
																	size: 8,												
																}											
															}
														},
														l2: {
															type: "linear",
															display: false,
															position: "left",
															min:0,
															max:' . $max_1 . ',
														},
														l3: {
															type: "linear",
															display: false,
															position: "left",
															min:0,
															max:' . $max_1 . ',
														},
														l4: {
															type: "linear",
															display: false,
															position: "left",
															min:0,
															max:' . $max_1 . ',
														},
														l5: {
															type: "linear",
															display: false,
															position: "left",
															min:0,
															max:' . $max_1 . ',
														},
														},
														},

                                                    });
                                                    </script>';

		$html['table'] = '
													<div class="table-responsive">
													<table class="table able-bordered table-stats" style="margin-bottom:0px!important">
													<tr>
													<th class="text-start" style="font-size:12px!important">#</th>
													' . $th_table . '
													</tr>
													' . $item_3 . '
													</table>
													</div>
													';
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($html, true);
	}


	function get_report()
	{
		$code = $_GET['code'];
		$type = $_GET['type'];
		$start_date = $_GET['start_date'];
		$until_date = $_GET['until_date'];
		$start_year = $_GET['start_year'];
		$until_year = $_GET['until_year'];
		$start_month = $_GET['start_month'];
		$until_month = $_GET['until_month'];
		$start_week = $_GET['start_week'];
		$until_week = $_GET['until_week'];
		$brand = $_GET['brand'];

		if ($type == "Yearly") {
			$start_date = $start_year . '-01-01';
			$until_date = $until_year . '-12-31';
		} else if ($type == "Monthly") {
			$start_month = str_pad($start_month, 2, "0", STR_PAD_LEFT);
			$until_month = str_pad($until_month, 2, "0", STR_PAD_LEFT);
			$start_date = $start_year . '-' . $start_month . '-01';
			$until_date = $start_year . '-' . $until_month . '-31';
		} else if ($type == "Weekly") {
			$start_week = str_pad($start_week, 2, "0", STR_PAD_LEFT);
			$until_week = str_pad($until_week, 2, "0", STR_PAD_LEFT);

			$year = $start_year;
			$week = $start_week;
			$start_date = date("Y-m-d", strtotime($year . "W" . $week . "1"));

			$year = $start_year;
			$week = $until_week;
			$until_date = date("Y-m-d", strtotime($year . "W" . $week . "7"));
		}

		$qry = "";

		$qry .= " WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' ";

		if ($brand) {
			$qry .= " AND brand = '$brand' ";
		}
		$channel = $_GET['channel'];
		if ($channel) {
			$qry .= " AND marketplace = '$channel' ";
		}

		if ($code == "1") {
			$query = $this->mymodel->selectWithQuery("SELECT COUNT(id) as count,shipping, shipping as name FROM transaction $qry AND type_sub = 'POS' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID')
			GROUP BY shipping
			ORDER BY count DESC
			");

			$query_3 = $this->mymodel->selectWithQuery("SELECT COUNT(id) as count,shipping FROM transaction $qry AND type_sub = 'POS' AND order_status IN ('READY_TO_SHIP','PENDING')
			GROUP BY shipping");
			$arr_3 = array();
			foreach ($query_3 as $k => $v) {
				$arr_3[$v['shipping']] = $v;
			}

			$query_2 = $this->mymodel->selectWithQuery("SELECT COUNT(id) as count,shipping FROM transaction $qry AND type_sub = 'POS' AND order_status IN ('PROCESSED')
			GROUP BY shipping");
			$arr_2 = array();
			foreach ($query_2 as $k => $v) {
				$arr_2[$v['shipping']] = $v;
			}
			$total_1 = 0;
			$total_2 = 0;
			$total_3 = 0;
			foreach ($query as $k => $v) {
				$text .= '
				<tr>
					<td class="text-center">' . ($k + 1) . '</td>
					<td class="text-start td-breakline">' . $v['shipping'] . '</td>
					<td class="text-end">' . $this->template->separator_only($v['count']) . '</td>
					<td class="text-end">' . $this->template->separator_only($arr_3[$v['name']]['count']) . '</td>
					<td class="text-end">' . $this->template->separator_only($arr_2[$v['name']]['count']) . '</td>
				</tr>
				';
				$total_1 += $v['count'];
				$total_2 += $arr_3[$v['name']]['count'];
				$total_3 += $arr_2[$v['name']]['count'];
			}
			$text = '<div class="table-responsive">
				<table class="table table-hover table-striped table-bordered">
					<tr class="bg-primary">
						<th class="text-center" style="width:20px!important">#</th>
						<th class="text-start">Ekspedisi</th>
						<th class="text-end" style="min-width:20px!important">Jumlah Order</th>
						<th class="text-end" style="min-width:20px!important">Menunggu Diproses</th>
						<th class="text-end" style="min-width:20px!important">Menunggu Dipickup</th>
					</tr>
					<tr>
						<th class="text-center">#</th>
						<th class="text-start td-breakline">Total</th>
						<th class="text-end">' . $this->template->separator_only($total_1) . '</th>
						<th class="text-end">' . $this->template->separator_only($total_2) . '</th>
						<th class="text-end">' . $this->template->separator_only($total_3) . '</th>
					</tr>
					
					' . $text . '
				</table></div>';
		} else if ($code == "1a") {
			$query = $this->mymodel->selectWithQuery("SELECT *, SUM(qty_out) as count FROM `stock_product_3rd`
			$qry
			GROUP BY varian_id, marketplace
			HAVING SUM(qty_out) > 0
			ORDER BY SUM(qty_out) DESC
			-- LIMIT 18
			");
			foreach ($query as $k => $v) {

				if ($v['marketplace'] == "SHOPEE") {
					$v['img'] = base_url() . '/assets/img/icon/icon-shopee.png';
				} else if ($v['marketplace'] == "LAZADA") {
					$v['img'] = base_url() . '/assets/img/icon/icon-lazada.png';
				} else if ($v['marketplace'] == "TIKTOK") {
					$v['img'] = base_url() . '/assets/img/icon/icon-tiktok.png';
				} else {
					$v['img'] = base_url() . '/assets/img/icon/icon-no.png';
				}

				$id_product = $v['product_id'];
				$marketplace = $v['marketplace'];
				$product = $this->mymodel->selectWithQuery("SELECT img
				FROM product_3rd
				WHERE id_product = '$id_product' AND marketplace = '$marketplace'");
				$product = $product[0];
				if ($product['img']) {
					$product['img'] = $product['img'];
				} else {
					$product['img'] = base_url() . '/assets/img/icon/icon-no.png';
				}

				if ($v['varian_text'] != $v['product_text']) {
					$v['varian_text'] = $v['product_text'] . '<hr class="mt-1 mb-1">' . $v['varian_text'];
				}
				$text .= '
				<tr>
					<td class="text-center">' . ($k + 1) . '</td>
					<td class="text-start td-breakline">' . $v['varian_sku'] . '</td>
					<td class="text-start td-breakline">
					<div class="row">
                        <div class="col-12" style="position:relative">
                        <div class="row">
                        <div class="firstDivImg">
                            <a href="' . $product['img'] . '" target="_blank"><img class="divIcon" src="' . $product['img'] . '" alt=""></a>
                        </div>
                        <div class="secondDivImg">
                            ' . $v['varian_text'] . '
                        </div>
                        </div>
                        </div>
                    </div>  
					</td>
					<td class="text-center"><img style="width:35px;border-radius:10px;" src="' . $v['img'] . '"></td>
					<td class="text-end">' . $this->template->separator_only($v['count']) . '</td>
				</tr>
				';
			}
			$text = '<div class="table-responsive">
				<table class="table table-hover table-striped table-bordered">
					<tr class="bg-primary">
						<th class="text-center" style="width:20px!important">#</th>
						<th class="text-start">SKU</th>
						<th class="text-start">Nama Produk</th>
						<th class="text-center">MP</th>
						<th class="text-end" style="min-width:20px!important">Qty</th>
					</tr>
					' . $text . '
				</table></div>';
		} else if ($code == "11") {

			$query = $this->mymodel->selectWithQuery("SELECT * FROM
			(SELECT * FROM product) a 
			LEFT JOIN
			(SELECT product,SUM(qty_in) as qty_in,SUM(qty_in_pos) as qty_in_pos,SUM(qty_out) as qty_out,SUM(qty_out_pos) as qty_out_pos, SUM(qty) as qty 
			FROM stock a
			$qry
			GROUP BY a.product) b
			ON a.id = b.product
			ORDER BY b.qty_out_pos DESC");

			$qry_2 .= " WHERE DATE(date) < '$start_date' ";

			$query_before = $this->mymodel->selectWithQuery("SELECT * FROM
			(SELECT * FROM product) a 
			LEFT JOIN
			(SELECT product,SUM(qty_in) as qty_in,SUM(qty_in_pos) as qty_in_pos,SUM(qty_out) as qty_out,SUM(qty_out_pos) as qty_out_pos, SUM(qty) as qty 
			FROM stock a
			$qry_2
			GROUP BY a.product) b
			ON a.id = b.product
			ORDER BY b.qty_out_pos DESC");
			$arr = array();
			foreach ($query_before as $k => $v) {
				$arr[$v['id']] = $v;
			}

			foreach ($query as $k => $v) {
				$before = $arr[$v['id']];
				$v['qty_sebelumnya'] = $before['qty_in'] + $before['qty_in_pos'] - $before['qty_out'] - $before['qty_out_pos'];
				$v['qty_akhir'] = $v['qty_sebelumnya'] + $v['qty'];
				$text .= '
				<tr>
					<td class="text-center">' . ($k + 1) . '</td>
					<td class="text-start td-breakline">' . $v['name'] . '</td>
					<td class="text-end">' . $this->template->separator_only($v['qty_in']) . '</td>
					<td class="text-end">' . $this->template->separator_only($v['qty_in_pos']) . '</td>
					<td class="text-end">' . $this->template->separator_only($v['qty_out']) . '</td>
					<td class="text-end">' . $this->template->separator_only($v['qty_out_pos']) . '</td>
					<td class="text-end">' . $this->template->separator_only($v['qty']) . '</td>
					<td class="text-end">' . $this->template->separator_only($v['qty_sebelumnya']) . '</td>
					<td class="text-end">' . $this->template->separator_only($v['qty_akhir']) . '</td>
				</tr>
				';
			}
			$text = '<div class="table-responsive">
				<table class="table table-hover table-striped table-bordered">
					<tr class="bg-primary">
						<th class="text-center" style="width:20px!important">#</th>
						<th class="text-start">Nama<br>Produk</th>
						<th class="text-end" style="min-width:20px!important">Stok<br>Masuk</th>
						<th class="text-end" style="min-width:20px!important">Stok<br>Kembali</th>
						<th class="text-end" style="min-width:20px!important">Stok<br>Keluar</th>
						<th class="text-end" style="min-width:20px!important">Stok<br>Terjual</th>
						<th class="text-end" style="min-width:20px!important">Stok</th>
						<th class="text-end" style="min-width:20px!important">Stok<br>Sebelumnya</th>
						<th class="text-end" style="min-width:20px!important">Stok<br>Akhir</th>
					</tr>
					' . $text . '
				</table></div>';
		} else if ($code == "2") {
			$query = $this->mymodel->selectWithQuery("SELECT *
			FROM 
			(SELECT id,full_name FROM customer) a
			JOIN
			(SELECT customer, COUNT(id) as count_order, SUM(price_total) as nominal_order FROM transaction
			$qry AND type_sub = 'POS'
			GROUP BY customer) b 
			ON a.id = b.customer
			ORDER BY count_order DESC, full_name ASC
			LIMIT 10");
			foreach ($query as $k => $v) {
				$text .= '
				<tr>
					<td class="text-center">' . ($k + 1) . '</td>
					<td class="text-start"><a style="text-decoration:none!important" href="' . base_url() . '/crm/detail?id=' . $v['id'] . '&start_date=' . $start_date . '&until_date=' . $until_date . '" target="_blank">' . $v['full_name'] . '</a></td>
					<td class="text-end">' . $this->template->separator_only($v['count_order']) . '</td>
					<td class="text-end">' . $this->template->separator_only($v['nominal_order']) . '</td>
				</tr>
				';
			}
			$text = '
			<div class="table-responsive">
				<table class="table table-hover table-striped table-bordered">
				<tr class="bg-primary">
						<th class="text-center" style="width:20px!important">#</th>
						<th class="text-start">Nama Pelanggan</th>
						<th class="text-end" style="min-width:20px!important">Jumlah Order</th>
<th class="text-end" style="min-width:20px!important">Nominal Order</th>
					</tr>
					' . $text . '
				</table></div>';
		} else if ($code == "3") {
			$query = $this->mymodel->selectWithQuery("SELECT *
			FROM
			(SELECT * FROM marketplace) a
			LEFT JOIN
			(SELECT marketplace, COUNT(id) as count_order, SUM(price_total) as nominal_order
			FROM transaction
			$qry AND type_sub = 'POS'
			GROUP BY marketplace) b
			ON a.name = b.marketplace
			ORDER BY count_order DESC, name ASC
			LIMIT 10");
			foreach ($query as $k => $v) {
				$text .= '
				<tr>
					<td class="text-center">' . ($k + 1) . '</td>
					<td class="text-start">' . $v['name'] . '</td>
					<td class="text-end">' . $this->template->separator_only($v['count_order']) . '</td>
<td class="text-end">' . $this->template->separator_only($v['nominal_order']) . '</td>
				</tr>
				';
			}
			$text = '<div class="table-responsive">
				<table class="table table-hover table-striped table-bordered">
				<tr class="bg-primary">
						<th class="text-center" style="width:20px!important">#</th>
						<th class="text-start">Nama Channel</th>
						<th class="text-end" style="min-width:20px!important">Jumlah Order</th>
<th class="text-end" style="min-width:20px!important">Nominal Order</th>
					</tr>
					' . $text . '
				</table></div>';
		} else if ($code == "4") {
			$query = $this->mymodel->selectWithQuery("SELECT city_text, COUNT(id) as count_order, SUM(price_total) as nominal_order
			FROM transaction
			$qry AND type_sub = 'POS'			
			GROUP BY city_text
			ORDER BY count_order DESC, city_text ASC
			LIMIT 12");
			foreach ($query as $k => $v) {
				$text .= '
				<tr>
					<td class="text-center">' . ($k + 1) . '</td>
					<td class="text-start">' . $v['city_text'] . '</td>
					<td class="text-end">' . $this->template->separator_only($v['count_order']) . '</td>
<td class="text-end">' . $this->template->separator_only($v['nominal_order']) . '</td>
				</tr>
				';
			}
			$text = '<div class="table-responsive">
				<table class="table table-hover table-striped table-bordered">
				<tr class="bg-primary">
						<th class="text-center" style="width:20px!important">#</th>
						<th class="text-start">Nama Kota</th>
						<th class="text-end" style="min-width:20px!important">Jumlah Order</th>
<th class="text-end" style="min-width:20px!important">Nominal Order</th>
					</tr>
					' . $text . '
				</table></div>';
		} else if ($code == "5") {
			$year = DATE("Y", strtotime($start_date));
			$qry = '';
			$qry .= " AND YEAR(date) = '$year' ";
			if ($brand) {
				$qry .= " AND brand = '$brand' ";
			}
			$query = $this->mymodel->selectWithQuery("SELECT COUNT(id) as count, SUM(ABS(price_total)) as price_total, MONTH(date) as month
			FROM transaction
			WHERE category = 'Gift' $qry
			GROUP BY MONTH(date)");
			$arr_query = array();
			foreach ($query as $k => $v) {
				$arr_query[$v['month'] - 1]['price_total'] = $v['price_total'];
				$arr_query[$v['month'] - 1]['count'] = $v['count'];
			}
			$month = array(
				'Januari',
				'Februari',
				'Maret',
				'April',
				'Mei',
				'Juni',
				'Juli',
				'Agustus',
				'September',
				'Oktober',
				'November',
				'Desember'
			);
			$arr = array();
			foreach ($month as $k => $v) {
				$arr[$k]['month'] = $v;
				$arr[$k]['count'] = $arr_query[$k]['count'];
				$arr[$k]['price_total'] = $arr_query[$k]['price_total'];
			}
			foreach ($arr as $k => $v) {
				$text .= '
				<tr>
					<td class="text-center">' . ($k + 1) . '</td>
					<td class="text-start">' . $v['month'] . '</td>
					<td class="text-end">' . $this->template->separator_only($v['count']) . '</td>
					<td class="text-end">' . $this->template->separator_only($v['price_total']) . '</td>
				</tr>
				';
			}
			$text = '<div class="table-responsive">
				<table class="table table-hover table-striped table-bordered">
				<tr class="bg-primary">
						<th class="text-center" style="width:20px!important">#</th>
						<th class="text-start">Bulan</th>
						<th class="text-end" style="min-width:20px!important">Jumlah Gift</th>
						<th class="text-end" style="min-width:20px!important">Nominal Gift</th>
					</tr>
					' . $text . '
				</table></div>';
		} else if ($code == "6") {
			$year = DATE("Y", strtotime($start_date));
			$qry = '';
			$qry .= " AND YEAR(date) = '$year' ";
			if ($brand) {
				$qry .= " AND brand = '$brand' ";
			}
			$query = $this->mymodel->selectWithQuery("SELECT * FROM `endorse` 
			WHERE link_upload != '' $qry
			ORDER BY CAST(`views` AS UNSIGNED) DESC");
			foreach ($query as $k => $v) {
				$text .= '
				<tr>
					<td class="text-center">' . ($k + 1) . '</td>
					<td class="text-start"><a target="_blank" href="' . $v['link_upload'] . '">' . $v['nama_creator'] . '</a></td>
					<td class="text-start">' . $v['platform'] . '</td>
					<td class="text-end">' . $this->template->separator_only(doubleval($v['total_cost'])) . '</td>
					<td class="text-end">' . $this->template->separator_only(doubleval($v['views'])) . '</td>
					<td class="text-end">' . $this->template->separator_only(doubleval($v['likes'])) . '</td>
					<td class="text-end">' . $this->template->separator_only(doubleval($v['comment'])) . '</td>
					<td class="text-end">' . $this->template->separator_only(doubleval($v['share_save'])) . '</td>
					<td class="text-end">' . $this->template->separator_only(doubleval($v['cost_per_1000_impression'])) . '</td>
				</tr>
				';
			}
			$text = '<div class="table-responsive">
				<table class="table table-hover table-striped table-bordered">
				<tr class="bg-primary">
						<th class="text-center" style="width:20px!important">#</th>
						<th class="text-start">Nama Creator</th>
						<th class="text-start">Platform</th>
						<th class="text-end" style="min-width:20px!important">Cost</th>
						<th class="text-end" style="min-width:20px!important">Views</th>
						<th class="text-end" style="min-width:20px!important">Likes</th>
						<th class="text-end" style="min-width:20px!important">Comments</th>
						<th class="text-end" style="min-width:20px!important">Share & Save</th>
						<th class="text-end" style="min-width:20px!important">CPM</th>
					</tr>
					' . $text . '
				</table></div>';
		} else if ($code == "7") {
			$year = DATE("Y", strtotime($start_date));
			$qry = '';
			$qry .= " AND YEAR(date) = '$year' ";
			if ($brand) {
				$qry .= " AND brand = '$brand' ";
			}
			$query = $this->mymodel->selectWithQuery("SELECT * FROM
			(SELECT id, url
			FROM influencer) a
			JOIN
			(SELECT 
				 influencer,
				nama_creator,
				COUNT(id) as count,
				SUM(total_cost) as total_cost,
				SUM(views) as views,
				SUM(likes) as likes,
				SUM(comment) as comment,
				SUM(share_save) as share_save,
				AVG(cost_per_1000_impression) as cost_per_1000_impression 
			FROM `endorse` 
			WHERE link_upload != ''
			GROUP BY influencer
			) b
			ON a.id = b.influencer
			ORDER BY views DESC");
			foreach ($query as $k => $v) {
				$text .= '
				<tr>
					<td class="text-center">' . ($k + 1) . '</td>
					<td class="text-start"><a target="_blank" href="' . $v['url'] . '">' . $v['nama_creator'] . '</a></td>
					<td class="text-end">' . $this->template->separator_only(doubleval($v['count'])) . '</td>
					<td class="text-end">' . $this->template->separator_only(doubleval($v['total_cost'])) . '</td>
					<td class="text-end">' . $this->template->separator_only(doubleval($v['views'])) . '</td>
					<td class="text-end">' . $this->template->separator_only(doubleval($v['likes'])) . '</td>
					<td class="text-end">' . $this->template->separator_only(doubleval($v['comment'])) . '</td>
					<td class="text-end">' . $this->template->separator_only(doubleval($v['share_save'])) . '</td>
					<td class="text-end">' . $this->template->separator_only(doubleval($v['cost_per_1000_impression'])) . '</td>
				</tr>
				';
			}
			$text = '<div class="table-responsive">
				<table class="table table-hover table-striped table-bordered">
				<tr class="bg-primary">
						<th class="text-center" style="width:20px!important">#</th>
						<th class="text-start">Nama Creator</th>
						<th class="text-end" style="min-width:20px!important">Konten</th>
						<th class="text-end" style="min-width:20px!important">Cost</th>
						<th class="text-end" style="min-width:20px!important">Views</th>
						<th class="text-end" style="min-width:20px!important">Likes</th>
						<th class="text-end" style="min-width:20px!important">Comments</th>
						<th class="text-end" style="min-width:20px!important">Share & Save</th>
						<th class="text-end" style="min-width:20px!important">CPM</th>
					</tr>
					' . $text . '
				</table></div>';
		}
		$html['html'] = $text;
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($html, true);
	}

	function get_report_influencer()
	{
		$code = $_GET['code'];
		$type = $_GET['type'];
		$start_date = $_GET['start_date'];
		$until_date = $_GET['until_date'];
		$start_year = $_GET['start_year'];
		$until_year = $_GET['until_year'];
		$start_month = $_GET['start_month'];
		$until_month = $_GET['until_month'];
		$start_week = $_GET['start_week'];
		$until_week = $_GET['until_week'];
		$brand = $_GET['brand'];

		if ($type == "Yearly") {
			$start_date = $start_year . '-01-01';
			$until_date = $until_year . '-12-31';
		} else if ($type == "Monthly") {
			$start_month = str_pad($start_month, 2, "0", STR_PAD_LEFT);
			$until_month = str_pad($until_month, 2, "0", STR_PAD_LEFT);
			$start_date = $start_year . '-' . $start_month . '-01';
			$until_date = $start_year . '-' . $until_month . '-31';
		} else if ($type == "Weekly") {
			$start_week = str_pad($start_week, 2, "0", STR_PAD_LEFT);
			$until_week = str_pad($until_week, 2, "0", STR_PAD_LEFT);

			$year = $start_year;
			$week = $start_week;
			$start_date = date("Y-m-d", strtotime($year . "W" . $week . "1"));

			$year = $start_year;
			$week = $until_week;
			$until_date = date("Y-m-d", strtotime($year . "W" . $week . "7"));
		}

		$qry = "";

		$qry .= " WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' ";

		if ($brand) {
			$qry .= " AND brand = '$brand' ";
		}
		$channel = $_GET['channel'];
		if ($channel) {
			$qry .= " AND marketplace = '$channel' ";
		}
		$campaign = $_GET['campaign'];
		$platform = $_GET['platform'];
		$qry = "";
		if ($code == "1") {
			$total_1 = 0;
			$total_summary = array();
			$total = array();
			$text = "";
			if ($campaign) {
				$qry .= " AND id_campaign = '$campaign' ";
			}
			if ($platform) {
				$qry .= " AND platform = '$platform' ";
			}
			$query = $this->mymodel->selectWithQuery("SELECT nama_creator as username, influencer as id,platform, COUNT(id) as count
			FROM endorse 
			WHERE 1=1 $qry
			GROUP BY influencer
			ORDER BY count DESC
			");
			$list = $this->mymodel->selectWithQuery("SELECT influencer as id,status_endorse
			FROM endorse 
			WHERE 1=1 $qry
			");

			$arr = array();
			$arr[] = "1. Review";
			$arr[] = "2. Hold";
			$arr[] = "3. Acc";
			$arr[] = "4. DP";
			$arr[] = "5. FP";
			$arr[] = "6. Barang<br>Dikirim";
			$arr[] = "7. Draft<br>Content";
			$arr[] = "8. Posted<br>Content";
			$arr[] = "9. Reject";

			foreach ($list as $k => $v) {
				$i = 0;
				if ($v['status_endorse'] == "1. Review") {
					$i = 0;
					$total[$v['id']][$i] = $total[$v['id']][$i] + 1;
					$total_summary[$i] = $total_summary[$i] + 1;
				} else if ($v['status_endorse'] == "2. Hold") {
					$i = 1;
					$total[$v['id']][$i] = $total[$v['id']][$i] + 1;
					$total_summary[$i] = $total_summary[$i] + 1;
				} else if ($v['status_endorse'] == "3. Acc") {
					$i = 2;
					$total[$v['id']][$i] = $total[$v['id']][$i] + 1;
					$total_summary[$i] = $total_summary[$i] + 1;
				} else if ($v['status_endorse'] == "4. DP") {
					$i = 3;
					$total[$v['id']][$i] = $total[$v['id']][$i] + 1;
					$total_summary[$i] = $total_summary[$i] + 1;
				} else if ($v['status_endorse'] == "5. FP") {
					$i = 4;
					$total[$v['id']][$i] = $total[$v['id']][$i] + 1;
					$total_summary[$i] = $total_summary[$i] + 1;
				} else if ($v['status_endorse'] == "6. Barang Dikirim") {
					$i = 5;
					$total[$v['id']][$i] = $total[$v['id']][$i] + 1;
					$total_summary[$i] = $total_summary[$i] + 1;
				} else if ($v['status_endorse'] == "7. Draft Content") {
					$i = 6;
					$total[$v['id']][$i] = $total[$v['id']][$i] + 1;
					$total_summary[$i] = $total_summary[$i] + 1;
				} else if ($v['status_endorse'] == "8. Posted Content") {
					$i = 7;
					$total[$v['id']][$i] = $total[$v['id']][$i] + 1;
					$total_summary[$i] = $total_summary[$i] + 1;
				} else if ($v['status_endorse'] == "9. Reject") {
					$i = 8;
					$total[$v['id']][$i] = $total[$v['id']][$i] + 1;
					$total_summary[$i] = $total_summary[$i] + 1;
				}
			}

			foreach ($query as $k => $v) {
				$td = '';
				$th = '';
				foreach ($arr as $k2 => $v2) {
					$td .= '<td class="text-end">' . $this->template->separator_only($total[$v['id']][$k2]) . '</td>';
				}
				foreach ($arr as $k2 => $v2) {
					$th .= '<th class="text-end">' . $this->template->separator_only($total_summary[$k2]) . '</th>';
				}
				$text .= '
				<tr>
					<td class="text-center">' . ($k + 1) . '</td>
					<td class="text-start td-breakline">' . $v['username'] . '</td>
					<td class="text-start td-breakline">' . $v['platform'] . '</td>
					<td class="text-end">' . $this->template->separator_only($v['count']) . '</td>
					' . $td . '
				</tr>
				';
				$total_1 += $v['count'];
			}
			$th_status = '';

			foreach ($arr as $k => $v) {
				$th_status .= '<th class="text-end" style="min-width:20px!important">' . $v . '</th>';
			}
			$text = '<div class="table-responsive">
				<table class="table table-hover table-striped table-bordered">
					<tr class="bg-primary">
						<th class="text-center" style="width:20px!important">#</th>
						<th class="text-start">Username</th>
						<th class="text-start">Platform</th>
						<th class="text-end">Konten</th>
						' . $th_status . '
					</tr>
					<tr>
						<th class="text-center">#</th>
						<th class="text-start td-breakline">Total</th>
						<th class="text-start td-breakline"></th><th class="text-end" style="min-width:20px!important">' . $total_1 . '</th>
						' . $th . '
					</tr>
					
					' . $text . '
				</table></div>';
		}
		$html['html'] = $text;
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($html, true);
	}

	function minimize_sidebar()
	{
		$session = $_SESSION['minimize_sidebar'];
		if ($session) {
			$_SESSION['minimize_sidebar'] = false;
		} else {
			$_SESSION['minimize_sidebar'] = true;
		}
		$html['html'] = "";
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($html, true);
	}
	function get_price_total()
	{
		$id_trx = $_GET['id_trx'];
		$query = $this->mymodel->selectWithQuery("SELECT json FROM transaction WHERE id = '$id_trx' ");

		$query = $query[0];
		$json = json_decode($query['json'], true);
		$price = 0;
		foreach ($json as $k => $v) {
			$price += doubleval($v['price_total']);
		}

		$dt = array();
		$dt['price_total'] = strval($price);

		$this->db->update('transaction', $dt, array('id' => $id_trx));

		header('Content-Type: application/json; charset=utf-8');
		$html = array();
		$html['price_total'] = $price;
		$msg = "Update data berhasil!";
		$html['msg'] = $this->template->alert_success($msg);
		echo json_encode($html, true);
	}

	function get_birthday_list()
	{
		$type = $_GET['type'];
		if ($type == 'today') {
			$today = DATE("Y-m-d");
			$query = $this->mymodel->selectWithQuery("SELECT id, full_name, phone, birth_date
			FROM customer 
			WHERE DATE_FORMAT(birth_date, '%m-%d') = DATE_FORMAT('$today', '%m-%d')
			ORDER BY full_name");

			foreach ($query as $k => $v) {
				$bg = '#FFF';
				$bg_2 = '#60bb55';
				if (empty($v['phone'])) {
					$bg = '#fef2f2';
					$bg_2 = '#ed7881';
				}
				if (substr($v['phone'], 0, 1) === "0") {
					$v['phone'] = "62" . substr($v['phone'], 1);
				}
				$dateOfBirth = $v['birth_date'];
				$today = date("Y-m-d");
				$age = date("Y", strtotime($today)) - date("Y", strtotime($dateOfBirth));
				$text .= '
				<a style="color:#000;text-decoration: none;" target="_blank" href="https://wa.me/' . $v['phone'] . '">
				<div class="box-chart-2 tr-shadow mb-2" style="background:' . $bg . '">
				<div class="row">
				<div class="firstDiv">
				<div class="firstCircle" style="background:' . $bg_2 . '">
				<div class="centeredElement">
				' . strtoupper($v['full_name'][0]) . '
				</div>
				</div>
				</div>
				<div class="secondDiv">
				' . $v['full_name'] . '
				<br>
				Tanggal : ' . $v['birth_date'] . '
				<br>
				Usia : ' . $age . ' Tahun
				</div>
				</div>
				</div></a>';
			}
			if (empty($query)) {
				$text = 'Data tidak ditemukan!';
			}
		} else if ($type == '+1') {
			$today = DATE("Y-m-d");
			$today = date("Y-m-d", strtotime($today . " +1 days"));
			$query = $this->mymodel->selectWithQuery("SELECT id, full_name, phone, birth_date
			FROM customer 
			WHERE DATE_FORMAT(birth_date, '%m-%d') = DATE_FORMAT('$today', '%m-%d')
			ORDER BY full_name");

			foreach ($query as $k => $v) {
				$bg = '#FFF';
				$bg_2 = '#60bb55';
				if (empty($v['phone'])) {
					$bg = '#fef2f2';
					$bg_2 = '#ed7881';
				}
				if (substr($v['phone'], 0, 1) === "0") {
					$v['phone'] = "62" . substr($v['phone'], 1);
				}
				$dateOfBirth = $v['birth_date'];
				$today = date("Y-m-d");
				$age = date("Y", strtotime($today)) - date("Y", strtotime($dateOfBirth));
				$text .= '
				<a style="color:#000;text-decoration: none;" target="_blank" href="https://wa.me/' . $v['phone'] . '">
				<div class="box-chart-2 tr-shadow mb-2" style="background:' . $bg . '">
				<div class="row">
				<div class="firstDiv">
				<div class="firstCircle" style="background:' . $bg_2 . '">
				<div class="centeredElement">
				' . strtoupper($v['full_name'][0]) . '
				</div>
				</div>
				</div>
				<div class="secondDiv">
				' . $v['full_name'] . '
				<br>
				Tanggal : ' . $v['birth_date'] . '
				<br>
				Usia : ' . $age . ' Tahun
				</div>
				</div>
				</div></a>';
			}
			if (empty($query)) {
				$text = 'Data tidak ditemukan!';
			}
		} else if ($type == '+2') {
			$today = DATE("Y-m-d");
			$today = date("Y-m-d", strtotime($today . " +2 days"));
			$query = $this->mymodel->selectWithQuery("SELECT id, full_name, phone, birth_date
			FROM customer 
			WHERE DATE_FORMAT(birth_date, '%m-%d') = DATE_FORMAT('$today', '%m-%d')
			ORDER BY full_name");

			foreach ($query as $k => $v) {
				$bg = '#FFF';
				$bg_2 = '#60bb55';
				if (empty($v['phone'])) {
					$bg = '#fef2f2';
					$bg_2 = '#ed7881';
				}
				if (substr($v['phone'], 0, 1) === "0") {
					$v['phone'] = "62" . substr($v['phone'], 1);
				}
				$dateOfBirth = $v['birth_date'];
				$today = date("Y-m-d");
				$age = date("Y", strtotime($today)) - date("Y", strtotime($dateOfBirth));
				$text .= '
				<a style="color:#000;text-decoration: none;" target="_blank" href="https://wa.me/' . $v['phone'] . '">
				<div class="box-chart-2 tr-shadow mb-2" style="background:' . $bg . '">
				<div class="row">
				<div class="firstDiv">
				<div class="firstCircle" style="background:' . $bg_2 . '">
				<div class="centeredElement">
				' . strtoupper($v['full_name'][0]) . '
				</div>
				</div>
				</div>
				<div class="secondDiv">
				' . $v['full_name'] . '
				<br>
				Tanggal : ' . $v['birth_date'] . '
				<br>
				Usia : ' . $age . ' Tahun
				</div>
				</div>
				</div></a>';
			}
			if (empty($query)) {
				$text = 'Data tidak ditemukan!';
			}
		} else {
			$today = DATE("Y-m-d");
			$today = date("Y-m-d", strtotime($today . " +2 days"));
			$query = $this->mymodel->selectWithQuery("SELECT id, full_name, phone, birth_date
			FROM customer 
			WHERE DATE_FORMAT(birth_date, '%m-%d') > DATE_FORMAT('$today', '%m-%d')
			ORDER BY DATE_FORMAT(birth_date, '%m-%d') ASC,full_name ASC
			LIMIT 10");

			foreach ($query as $k => $v) {
				$bg = '#FFF';
				$bg_2 = '#60bb55';
				if (empty($v['phone'])) {
					$bg = '#fef2f2';
					$bg_2 = '#ed7881';
				}
				if (substr($v['phone'], 0, 1) === "0") {
					$v['phone'] = "62" . substr($v['phone'], 1);
				}
				$dateOfBirth = $v['birth_date'];
				$today = date("Y-m-d");
				$age = date("Y", strtotime($today)) - date("Y", strtotime($dateOfBirth));
				$text .= '
				<a style="color:#000;text-decoration: none;" target="_blank" href="https://wa.me/' . $v['phone'] . '">
				<div class="box-chart-2 tr-shadow mb-2" style="background:' . $bg . '">
				<div class="row">
				<div class="firstDiv">
				<div class="firstCircle" style="background:' . $bg_2 . '">
				<div class="centeredElement">
				' . strtoupper($v['full_name'][0]) . '
				</div>
				</div>
				</div>
				<div class="secondDiv">
				' . $v['full_name'] . '
				<br>
				Tanggal : ' . $v['birth_date'] . '
				<br>
				Usia : ' . $age . ' Tahun
				</div>
				</div>
				</div></a>';
			}
			if (empty($query)) {
				$text = 'Data tidak ditemukan!';
			}
		}

		header('Content-Type: application/json');
		$html = array();
		$html['html'] = $text;
		echo json_encode($html, true);
	}
	function get_filter()
	{
		$page = $_GET['page'];
		$type = $_GET['type'];
		$start_date = $_GET['start_date'];
		$until_date = $_GET['until_date'];
		$start_year = $_GET['start_year'];
		$until_year = $_GET['until_year'];
		$start_month = $_GET['start_month'];
		$until_month = $_GET['until_month'];
		$start_week = $_GET['start_week'];
		$until_week = $_GET['until_week'];
		$site = $_GET['site'];
		$customer = $_GET['customer'];
		$mpu = $_GET['mpu'];
		$start_year = $_GET['start_year'];
		$until_year = $_GET['until_year'];
		$start_month = $_GET['start_month'];
		$until_month = $_GET['until_month'];
		$start_week = $_GET['start_week'];
		$until_week = $_GET['until_week'];

		$text = "";

		if ($type == "Yearly") {
			for ($i = 2020; $i <= DATE("Y"); $i++) {
				$s = "";
				if ($i == $start_year) {
					$s = "selected";
				}
				$opt_year_1 .= '<option ' . $s . ' value="' . $i . '">' . $i . '</option>';
			}

			for ($i = 2020; $i <= DATE("Y"); $i++) {
				$s = "";
				if ($i == $until_year) {
					$s = "selected";
				}
				$opt_year_2 .= '<option ' . $s . ' value="' . $i . '">' . $i . '</option>';
			}
			$text = '
		
		<div class="col-md-4">
				<div class="d-flex">
				<select type="date" class="form-control " name="start_year" style="border-top-right-radius: 0px !important; border-bottom-right-radius: 0px !important; width:100%;">
				' . $opt_year_1 . '
				</select>
				<select type="date" class="form-control " name="until_year" style="border-top-left-radius: 0px !important; border-bottom-left-radius: 0px !important; width:100%;">
			' . $opt_year_2 . '
			</select>
				</div>
				</div>
			</div>

		';
		} else if ($type == "Monthly") {

			for ($i = 2020; $i <= DATE("Y"); $i++) {
				$s = "";
				if ($i == $start_year) {
					$s = "selected";
				}
				$opt_year_1 .= '<option ' . $s . ' value="' . $i . '">' . $i . '</option>';
			}

			for ($i = 1; $i <= 12; $i++) {
				$s = "";
				if ($i == $start_month) {
					$s = "selected";
				}
				$opt_month_1 .= '<option ' . $s . ' value="' . $i . '">' . $i . '</option>';
			}
			for ($i = 1; $i <= 12; $i++) {
				$s = "";
				if ($i == $until_month) {
					$s = "selected";
				}
				$opt_month_2 .= '<option ' . $s . ' value="' . $i . '">' . $i . '</option>';
			}

			$text = '<div class="col-md-3">
			<select type="date" class="form-control " name="start_year">
			' . $opt_year_1 . '
			</select>
		</div>

		<div class="col-md-3">
				<div class="d-flex">
				<select type="date" class="form-control " name="start_month" style="border-top-right-radius: 0px !important; border-bottom-right-radius: 0px !important; width:100%;">
				' . $opt_month_1 . '
				</select>
				<select type="date" class="form-control " name="until_month" style="border-top-left-radius: 0px !important; border-bottom-left-radius: 0px !important; width:100%;">
			' . $opt_month_2 . '
			</select>
				</div>
				</div>
			</div>

			';
		} else if ($type == "Weekly") {

			for ($i = 2020; $i <= DATE("Y"); $i++) {
				$s = "";
				if ($i == $start_year) {
					$s = "selected";
				}
				$opt_year_1 .= '<option ' . $s . ' value="' . $i . '">' . $i . '</option>';
			}

			for ($i = 1; $i <= 53; $i++) {
				$s = "";
				if ($i == $start_week) {
					$s = "selected";
				}
				$opt_week_1 .= '<option ' . $s . ' value="' . $i . '">' . $i . '</option>';
			}
			for ($i = 1; $i <= 53; $i++) {
				$s = "";
				if ($i == $until_week) {
					$s = "selected";
				}
				$opt_week_2 .= '<option ' . $s . ' value="' . $i . '">' . $i . '</option>';
			}

			$text = '
			<div class="col-md-3">
				<select type="date" class="form-control " name="start_year">
				' . $opt_year_1 . '
				</select>
			</div>

			<div class="col-md-3">
				<div class="d-flex">
					<select type="date" class="form-control" name="start_week" style="border-top-right-radius: 0px !important; border-bottom-right-radius: 0px !important; width:50%;">
					' . $opt_week_1 . '
					</select>
					<select type="date" class="form-control " name="until_week" style="border-top-left-radius: 0px !important; border-bottom-left-radius: 0px !important; width:50%;">
					' . $opt_week_2 . '
					</select>
					</div>
				</div>
			</div>

		

		';
		} else {
			$text = '
			<div class="col-md-7">
				<div class="d-flex">
					<input type="date" name="start_date" class="form-control" value="' . $start_date . '" style="border-top-right-radius: 0px !important; border-bottom-right-radius: 0px !important; width:100%;">
					<input type="date" name="until_date" class="form-control" value="' . $until_date . '" style="border-top-left-radius: 0px !important; border-bottom-left-radius: 0px !important; width:100%;">
				</div>
			</div>
			';
		}
		if ($page == "endorse") {
			$text .= ' <div class="col-md-3">
					<button class="btn btn-primary w-100 form-control" type="submit"><i class="bi bi-search fs-16"></i> Cari Data</button>
				</div>';
		} else {
			$text .= ' <div class="col-md-3">
					<button class="btn btn-primary w-100 form-control" type="submit"><i class="bi bi-search fs-16"></i> Cari Data</button>
				</div>';
		}
		// echo $text;
		$html = array();
		$html['html'] = $text;
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($html, true);
	}
	function get_customer_list()
	{
		$q = $_GET['search'] ?? '';



		// Use parameter binding to prevent SQL injection
		$query = $this->mymodel->selectWithQuery("SELECT id as id, CONCAT(full_name,' | ',phone,' | ',username) as text, phone, username
			FROM customer 
			WHERE full_name LIKE '%$q%' OR username LIKE '%$q%' OR phone LIKE '%$q%'
			ORDER BY full_name ASC
			LIMIT 10");



		header('Content-Type: application/json');
		echo json_encode($query, true);
	}

	function get_customer_detail()
	{
		$save = $_GET['save'];
		$id = $_GET['id'];
		$id_trx = $_GET['id_trx'];

		$query = $this->mymodel->selectWithQuery("SELECT *
		FROM customer WHERE id = '$id' ");

		$query = $query[0];

		if ($save == 'true') {
			if ($id_trx) {
				$dt = array();
				$dt['customer'] = strval($id);
				$dt['customer_text'] = strval($query['full_name']);

				$data = $this->mymodel->selectWithQuery("SELECT customer
				FROM transaction WHERE id = '$id_trx' ");
				$data = $data[0];
				if ($data['customer'] != $id) {


					$this->db->update('expense', $dt, array('id' => $id_trx));

					if ($id > 0) {
						$this->refresh_gift($id);
					}
					if ($data['customer'] > 0) {
						$this->refresh_gift($data['customer']);
					}
				} else {

					$this->db->update('expense', $dt, array('id' => $id_trx));

					$this->refresh_gift($id);
				}
			}
		}

		$html = $query;
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($html, true);
	}

	function refresh_gift($id_customer)
	{
		$data = $this->mymodel->selectWithQuery("SELECT id, date, title,transaction.desc,qty,price,price_total FROM transaction
        WHERE customer = '$id_customer' AND category = 'Gift'
        ORDER BY date ASC");
		$dt = array();
		$dt['gift'] = json_encode($data, true);
		$this->db->update('customer', $dt, array('id' => $id_customer));
	}

	function get_product_detail()
	{
		$id = $_GET['id'];
		$id_trx = $_GET['id_trx'];
		$id_customer = $_GET['id_customer'];

		$query = $this->mymodel->selectWithQuery("SELECT *
		FROM product WHERE id = '$id' ");

		$data = $query[0];

		if ($data) {
			$data['price'] = $data['price_normal'];
			if ($id_customer) {

				$query = $this->mymodel->selectWithQuery("SELECT akun_type
				FROM customer WHERE id = '$id_customer' ");

				$query = $query[0];
				if ($query['akun_type'] == "Pelanggan") {
					$data['price'] = $data['price_normal'];
				} else if ($query['akun_type'] == "Distributor") {
					$data['price'] = $data['price_distributor'];
				} else if ($query['akun_type'] == "Reseller") {
					$data['price'] = $data['price_reseller'];
				} else {
					$data['price'] = $data['price_normal'];
				}
			}
		}

		if ($id_trx) {
			$query = $this->mymodel->selectWithQuery("SELECT * FROM transaction WHERE id = '$id_trx' ");

			$query = $query[0];
			$json = json_decode($query['json'], true);
			$json[$id]['price'] = $data['price'];
			$json[$id]['price_total'] = doubleval($json[$id]['price']) * doubleval($json[$id]['qty']);
			$price_total = 0;
			foreach ($json as $k => $v) {
				$price_total += doubleval($v['price_total']);
			}
			$data['price_total'] = $price_total;
			$dt = array();
			$dt['price_total'] = $price_total;
			$dt['json'] = json_encode($json, true);


			$this->db->update('transaction', $dt, array('id' => $id_trx));
		}

		$html = $data;
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($html, true);
	}
	function get_user_detail()
	{
		$id = $_GET['id'];
		$id_trx = $_GET['id_trx'];

		$query = $this->mymodel->selectWithQuery("SELECT *
		FROM user WHERE full_name = '$id' ");

		$query = $query[0];

		if ($id_trx) {
			$dt = array();
			$dt['cs_phone'] = strval($query['phone']);


			$this->db->update('transaction', $dt, array('id' => $id_trx));
		}


		$html = $query;
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($html, true);
	}

	function get_summary_campaign()
	{
		$id = $_GET['id'];
		$id_campaign = $_GET['id_campaign'];
		$type = $_GET['type'];
		$start_date = $_GET['start_date'];
		$until_date = $_GET['until_date'];
		$start_year = $_GET['start_year'];
		$until_year = $_GET['until_year'];
		$start_month = $_GET['start_month'];
		$until_month = $_GET['until_month'];
		$start_week = $_GET['start_week'];
		$until_week = $_GET['until_week'];
		$brand = $_GET['brand'];

		$type = $_GET['type'];
		$start_date = $_GET['start_date'];
		$until_date = $_GET['until_date'];
		$start_year = $_GET['start_year'];
		$until_year = $_GET['until_year'];
		$start_month = $_GET['start_month'];
		$until_month = $_GET['until_month'];
		$start_week = $_GET['start_week'];
		$until_week = $_GET['until_week'];
		$site = $_GET['site'];
		$customer = $_GET['customer'];
		$mpu = $_GET['mpu'];

		if ($type == "Yearly") {
			$qry_opt = " YEAR(date) ";
			$start_date = $start_year . '-01-01';
			$until_date = $until_year . '-12-31';
			$group = "  GROUP BY YEAR(date) ";
		} else if ($type == "Monthly") {
			$qry_opt = " MONTH(date) ";
			$start_month = str_pad($start_month, 2, "0", STR_PAD_LEFT);
			$until_month = str_pad($until_month, 2, "0", STR_PAD_LEFT);
			$start_date = $start_year . '-' . $start_month . '-01';
			$until_date = $start_year . '-' . $until_month . '-31';
			$group = "  GROUP BY MONTH(date) ";
		} else if ($type == "Weekly") {
			$qry_opt = " WEEK(date) ";
			$start_week = str_pad($start_week, 2, "0", STR_PAD_LEFT);
			$until_week = str_pad($until_week, 2, "0", STR_PAD_LEFT);

			$year = $start_year;
			$week = $start_week;
			$start_date = date("Y-m-d", strtotime($year . "W" . $week . "1"));

			$year = $start_year;
			$week = $until_week;
			$until_date = date("Y-m-d", strtotime($year . "W" . $week . "7"));
			$group = "  GROUP BY WEEK(date) ";
		} else {
			$qry_opt = " DATE(date) ";
			$group = "  GROUP BY DATE(date) ";
		}


		$detail = $this->mymodel->selectWithQuery("SELECT * FROM endorse_campaign
		WHERE id = '$id_campaign'");
		$detail = $detail[0];

		if ($type == "Yearly") {
			$start_date = $start_year . '-01-01';
			$until_date = $until_year . '-12-31';
		} else if ($type == "Monthly") {
			$start_month = str_pad($start_month, 2, "0", STR_PAD_LEFT);
			$until_month = str_pad($until_month, 2, "0", STR_PAD_LEFT);
			$start_date = $start_year . '-' . $start_month . '-01';
			$until_date = $start_year . '-' . $until_month . '-31';
		} else if ($type == "Weekly") {
			$start_week = str_pad($start_week, 2, "0", STR_PAD_LEFT);
			$until_week = str_pad($until_week, 2, "0", STR_PAD_LEFT);

			$year = $start_year;
			$week = $start_week;
			$start_date = date("Y-m-d", strtotime($year . "W" . $week . "1"));

			$year = $start_year;
			$week = $until_week;
			$until_date = date("Y-m-d", strtotime($year . "W" . $week . "7"));
		}

		$qry = "";
		if ($brand) {
			$qry .= " AND brand = '$brand' ";
		}

		if ($_GET['keyword_category']) {
			$keyword_category = $_GET['keyword_category'];
		} else {
			$keyword_category = "Nama Creator";
		}
		$data['keyword_category'] = $keyword_category;
		$keyword = $_GET['keyword'];

		if ($_GET['start_date']) {
			$start_date = $_GET['start_date'];
		} else {
			$start_date = DATE("Y-m-d");
			$start_date = DATE('Y-m-d', strtotime($today . " -31 days"));
		}
		if ($_GET['until_date']) {
			$until_date = $_GET['until_date'];
		} else {
			$until_date = DATE('Y-m-d');
		}
		$data['start_date'] = $start_date;
		$data['until_date'] = $until_date;
		$qry = "";

		$ids = $_GET['ids'];
		$data['ids'] = $ids;
		if ($ids) {
			$qry .= " AND id  IN ($ids) ";
		}

		if ($brand) {
			$qry .= " AND brand = '$brand' ";
		}

		$cat = $_GET['cat'];
		if ($cat == "Tanggal Dibuat") {
			$qry .= " AND DATE(created_at) >= '$start_date' AND DATE(created_at) <= '$until_date' ";
		} else if ($cat == "Rencana Upload") {
			$qry .= " AND DATE(rencana_at) >= '$start_date' AND DATE(rencana_at) <= '$until_date' ";
		} else if ($cat == "Tanggal Posting") {
			$qry .= " AND DATE(posting_at) >= '$start_date' AND DATE(posting_at) <= '$until_date' ";
		} else {
			// $qry .= " AND DATE(created_at) >= '$start_date' AND DATE(created_at) <= '$until_date' ";
		}

		$status = $_GET['status'];
		if ($status) {
			if ($status == 'Ada Link Upload') {
				$qry .= " AND link_upload != '' ";
			} else if ($status == 'Tidak Ada Link Upload') {
				$qry .= " AND link_upload = '' ";
			} else if ($status == 'FYP') {
				$qry .= " AND is_fyp = 1 ";
			}
		}

		$status = $_GET['endorse_status'];
		$statusArray = $status ? explode(',', $status) : [];
		$text = '';
		foreach ($statusArray as $k => $v) {
			$text .= "'" . $v . "',";
		}
		$text = substr($text, 0, -1);

		if ($text) {
			$qry .= " AND status_endorse IN ($text) ";
		}

		$platform = $_GET['platform'];
		if ($platform) {
			$qry .= " AND platform = '$platform' ";
		}

		if ($keyword) {
			if ($keyword_category == "Nama Creator") {
				$qry .= " AND nama_creator LIKE '%$keyword%' ";
			} else if ($keyword_category == "Link Upload") {
				$qry .= " AND link_upload LIKE '%$keyword%' ";
			} else if ($keyword_category == "PIC") {
				$qry .= " AND pic LIKE '%$keyword%' ";
			} else if ($keyword_category == "Platform") {
				$qry .= " AND platform LIKE '%$keyword%' ";
			} else if ($keyword_category == "Task") {
				$qry .= " AND task LIKE '%$keyword%' ";
			} else if ($keyword_category == "Keterangan") {
				$qry .= " AND endorse.desc LIKE '%$keyword%' ";
			}
		}

		// echo $qry;die;

		$query = $this->mymodel->selectWithQuery("SELECT id
        FROM endorse
        WHERE id_campaign = '$id_campaign' $qry 
        ");
		$list = '';
		foreach ($query as $k => $v) {
			$list .= "'" . $v['id'] . "',";
		}
		$list = substr($list, 0, -1);

		if ($list) {
			$qry_list .= " AND id_endorse IN ($list) ";
		}

		$text = "0";


		$data['checkbox'] = $_SESSION['checkbox'];

		if ($id == "mar-1") {
			$text = $this->template->separator_only($detail['budget']);
		} else if ($id == "mar-2") {

			$query = $this->mymodel->selectWithQuery("SELECT SUM(total_cost) as result FROM endorse WHERE id_campaign = '$id_campaign' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);
		} else if ($id == "mar-3") {
			// $query = $this->mymodel->selectWithQuery("SELECT 
			// -- AVG(cpm) as result
			// SUM(total_cost) / SUM(views) * 1000 as result
			// FROM endorse WHERE id_campaign = '$id_campaign' $qry");
			// $query = $query[0];
			$text = $this->template->separator_only($query['result']);
		} else if ($id == "mar-4") {
			$query = $this->mymodel->selectWithQuery("SELECT influencer as id FROM endorse WHERE id_campaign = '$id_campaign' $qry GROUP BY influencer");
			$text = "0,";
			foreach ($query as $k => $v) {
				$text .= $v['id'] . ',';
			}
			$text = substr($text, 0, -1);
			$qry = "";
			$query = $this->mymodel->selectWithQuery("SELECT COUNT(id) AS count
            FROM influencer
            WHERE id IN ($text) $qry 
            ");
			$text = $this->template->separator_only($query[0]['count']);
		} else if ($id == "mar-5") {
			$query = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM endorse WHERE id_campaign = '$id_campaign' AND is_fyp = 1 $qry");
			$query = $query[0];

			$query_2 = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM endorse WHERE id_campaign = '$id_campaign' $qry");
			$query_2 = $query_2[0];

			$text = $this->template->separator_only($query['result']) . '/' . $this->template->separator_only($query_2['result']);
		} else if ($id == "mar-6") {
			// $list = $this->mymodel->selectWithQuery("SELECT *
			// FROM endorse_logs
			// WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' $qry_list AND id_campaign = '$id_campaign'
			// GROUP BY id_endorse
			// ORDER BY DATE(date) DESC");
			// $query['result'] = 0;
			// foreach($list as $k=>$v){
			// 	if($data['checkbox'][0]=='false'){
			// 		$query['result'] += intval($v['views_after']);
			// 	}else{
			// 		$query['result'] += intval($v['views']);
			// 	}
			// }
			$text = $this->template->separator_only($query['result']);
		} else if ($id == "mar-7") {
			// $list = $this->mymodel->selectWithQuery("SELECT *
			// FROM endorse_logs
			// WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' $qry_list AND id_campaign = '$id_campaign'
			// GROUP BY id_endorse
			// ORDER BY DATE(date) DESC");
			// $query['result'] = 0;
			// foreach($list as $k=>$v){
			// 	if($data['checkbox'][0]=='false'){
			// 		$query['result'] += intval($v['likes_after']);
			// 	}else{
			// 		$query['result'] += intval($v['likes']);
			// 	}
			// }
			$text = $this->template->separator_only($query['result']);
		} else if ($id == "mar-8") {
			// $list = $this->mymodel->selectWithQuery("SELECT *
			// FROM endorse_logs
			// WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' $qry_list AND id_campaign = '$id_campaign'
			// GROUP BY id_endorse
			// ORDER BY DATE(date) DESC
			// ");
			// $query['result'] = 0;
			// foreach($list as $k=>$v){
			// 	if($data['checkbox'][0]=='false'){
			// 		$query['result'] += intval($v['comment_after']);
			// 	}else{
			// 		$query['result'] += intval($v['comment']);
			// 	}
			// }
			$text = $this->template->separator_only($query['result']);
		}
		$html['html'] = $text;
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($html, true);
	}

	function get_summary()
	{
		$id = $_GET['id'];
		$type = $_GET['type'];
		$channel = $_GET['channel'];
		$start_date = $_GET['start_date'];
		$until_date = $_GET['until_date'];
		$start_year = $_GET['start_year'];
		$until_year = $_GET['until_year'];
		$start_month = $_GET['start_month'];
		$until_month = $_GET['until_month'];
		$start_week = $_GET['start_week'];
		$until_week = $_GET['until_week'];
		$brand = $_GET['brand'];

		if ($type == "Yearly") {
			$start_date = $start_year . '-01-01';
			$until_date = $until_year . '-12-31';
		} else if ($type == "Monthly") {
			$start_month = str_pad($start_month, 2, "0", STR_PAD_LEFT);
			$until_month = str_pad($until_month, 2, "0", STR_PAD_LEFT);
			$start_date = $start_year . '-' . $start_month . '-01';
			$until_date = $start_year . '-' . $until_month . '-31';
		} else if ($type == "Weekly") {
			$start_week = str_pad($start_week, 2, "0", STR_PAD_LEFT);
			$until_week = str_pad($until_week, 2, "0", STR_PAD_LEFT);

			$year = $start_year;
			$week = $start_week;
			$start_date = date("Y-m-d", strtotime($year . "W" . $week . "1"));

			$year = $start_year;
			$week = $until_week;
			$until_date = date("Y-m-d", strtotime($year . "W" . $week . "7"));
		}

		$qry = "";
		$qry_2 = "";
		if ($brand) {
			$qry .= " AND brand = '$brand' ";
			$qry_2 .= " AND brand = '$brand' ";
		}
		$channel = $_GET['channel'];
		if ($channel) {
			$qry .= " AND marketplace = '$channel' ";
		}


		$until_date_2 = $start_date;
		$until_date_2 = date("Y-m-d", strtotime($until_date_2 . " -1 days"));
		$timestamp1 = strtotime($start_date);
		$timestamp2 = strtotime($until_date);
		$interval = abs($timestamp2 - $timestamp1);
		$interval_days = floor($interval / (60 * 60 * 24));
		$start_date_2 = date("Y-m-d", strtotime($until_date_2 . " -$interval_days days"));


		$text = "0";
		$progress = '<div class="text-black"><i class="bi bi-chevron-double-right"></i> 0%</div>';

		if ($id == "order-1") {
			$query = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND type_sub = 'POS' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND type_sub = 'POS' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-2") {
			$query = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND order_status IN ('PENDING','READY_TO_SHIP')  AND type_sub = 'POS' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND order_status IN ('PENDING','READY_TO_SHIP')  AND type_sub = 'POS' $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-3") {
			$query = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND payment_status IN ('Unpaid') AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND payment_status IN ('Unpaid') AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			$query_2 = $query_2[0];

			// echo $query['result'].' --- '.$query_2['result'];die;


		} else if ($id == "order-4") {
			$query = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND order_status IN ('RETURN')  AND type_sub = 'POS' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND order_status IN ('RETURN') AND type_sub = 'POS' $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-5") {
			$query = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-6") {
			$query = $this->mymodel->selectWithQuery("SELECT SUM(diskon_penjual) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT SUM(diskon_penjual) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-7") {
			$query = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor-diskon_penjual) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date'AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor-diskon_penjual) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2'AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-8") {
			$query = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor-diskon_penjual-hpp-diskon_penjual-marketplace_fee-komisi_afiliasi) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND type_sub = 'POS' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor-diskon_penjual-hpp-diskon_penjual-marketplace_fee-komisi_afiliasi) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND type_sub = 'POS' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-9") {
			// $query = $this->mymodel->selectWithQuery("SELECT SUM(marketplace_fee) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			// $query = $query[0];
			// $text = $this->template->separator_only($query['result']);

			// $query_2 = $this->mymodel->selectWithQuery("SELECT SUM(marketplace_fee) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			// $query_2 = $query_2[0];
			$query = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor) * 0.1 as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor) * 0.1 as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-10") {
			$query = $this->mymodel->selectWithQuery("SELECT SUM(komisi_afiliasi) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT SUM(komisi_afiliasi) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-11") {
			$query = $this->mymodel->selectWithQuery("SELECT ABS(SUM(price_total)) as result FROM expense WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date'  $qry_2");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT ABS(SUM(price_total)) as result FROM expense WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2'  $qry_2");
			$query_2 = $query_2[0];
		} else if ($id == "order-12") {
			$query = $this->mymodel->selectWithQuery("SELECT SUM(hpp) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT SUM(hpp) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-13") {
			// $query = $this->mymodel->selectWithQuery("SELECT SUM(qty*hpp) as result FROM stock WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date'");
			// $query = $query[0];
			// $text = $this->template->separator_only($query['result']);

			// $query_2 = $this->mymodel->selectWithQuery("SELECT SUM(qty*hpp) as result FROM stock WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2'");
			// $query_2 = $query_2[0];

			$query = $this->mymodel->selectWithQuery("SELECT SUM(stock*price_buy) as result FROM product");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			// $query_2 = $this->mymodel->selectWithQuery("SELECT SUM(stock*price_buy) as result FROM product");
			// $query_2 = $query_2[0];
			$query_2 = $query;
		} else if ($id == "order-14") {
			$query = $this->mymodel->selectWithQuery("SELECT SUM(ongkir) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND type_sub = 'POS' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT SUM(ongkir) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND type_sub = 'POS' $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-15") {
			$query = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND payment_status = 'Unpaid' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED') AND type_sub = 'POS' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND payment_status = 'Unpaid' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED') AND type_sub = 'POS' $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-16") {
			$query = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND order_status IN ('RETURN')  AND type_sub = 'POS' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND order_status IN ('RETURN') AND type_sub = 'POS' $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-17") {
			$query = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor-diskon_penjual) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' AND marketplace = '$channel' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor-diskon_penjual) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID')  AND type_sub = 'POS' AND marketplace = '$channel' $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-18") {
			$query = $this->mymodel->selectWithQuery("SELECT SUM(komisi_afiliasi+diskon_penjual+marketplace_fee) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' AND marketplace = '$channel' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT SUM(komisi_afiliasi+diskon_penjual+marketplace_fee) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' AND marketplace = '$channel' $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-19") {
			$query = $this->mymodel->selectWithQuery("SELECT SUM(dana_pencairan) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' AND marketplace = '$channel' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT SUM(dana_pencairan) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' AND marketplace = '$channel' $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-20") {
			$query = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' AND marketplace = '$channel' $qry");
			$query = $query[0];
			$text = $this->template->separator_only($query['result']);

			$query_2 = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' AND marketplace = '$channel' $qry");
			$query_2 = $query_2[0];
		} else if ($id == "order-21") {
			$query = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND dana_pencairan > 0 AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' AND marketplace = '$channel' $qry");
			$query = $query[0];

			$query_b = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM transaction WHERE DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' AND marketplace = '$channel' $qry");
			$query_b = $query_b[0];

			$text = $this->template->separator_only($query['result']) . '/' . $this->template->separator_only($query_b['result']);

			// $query_2 = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM transaction WHERE DATE(date) >= '$start_date_2' AND DATE(date) <= '$until_date_2' AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' AND marketplace = '$channel' $qry");
			// $query_2 = $query_2[0];


		}

		if ($id == "calendar") {

			$list = $this->mymodel->selectWithQuery("SELECT *
			FROM endorse");
			foreach ($list as $k => $v) {
				$date_1 = DATE("Y-m-d", strtotime($v['created_at'])) . 'T08:00';
				$date_2 = $date_1;
				if ($v['nama_creator'] == "") {
					$v['nama_creator'] = '-';
				}
				$title = $v['nama_creator'];
				$item .= ' {
					title: "' . $title . '",
					start: "' . $date_1 . '",
					end: "' . $date_2 . '",
					id: "' . $v['id'] . '",
					type: "endorse",
					color: "#4caf50"
				},';
			}
			$text = '
			<script>
			$(document).ready(function() {
			
				$("#calendar").fullCalendar({
					header: {
						left: "prev,next today",
						center: "title",
						right: "listDay,listWeek,month"
					},
					timeFormat: "H:mm",
			
					// customize the button names,
					// otherwise they"d all just say "list"
					views: {
						listDay: {
							buttonText: "list day"
						},
						listWeek: {
							buttonText: "list week"
						}
					},
			
					eventClick: function(arg) {
						window.open("' . base_url() . '/endorse/detail?id="+arg.id, "_blank");
					},
			
					defaultView: "month",
					defaultDate: "' . DATE("Y-m-d") . '",
					navLinks: true, // can click day/week names to navigate views
					editable: false,
					eventLimit: true, // allow "more" link when too many events
					events: [
						' . $item . '
						
						
								]
				});
			
			});
			</script>
			
			<div id="calendar"></div>
			';
		} else if ($id == "order-21") {
			if ($query['result'] > 0 && $query_b['result'] > 0) {
				$val = $query['result'] * 100 / ($query_b['result']);
				$val = $this->template->separator_only($val);
				$progress = '<div class="text-black"><i class="bi bi-chevron-double-right"></i> ' . $val . '%</div>';
			} else {
				$progress = '<div class="text-black"><i class="bi bi-chevron-double-right"></i> 0%</div>';
			}
		} else {
			$query['result'] = doubleval($query['result']);
			$query_2['result'] = doubleval($query_2['result']);

			if ($query['result'] > 0 && $query_2['result'] == 0) {
			} else if ($query['result'] == 0 && $query_2['result'] > 0) {
				$progress = '<div class="text-red"><i class="bi bi-chevron-double-down"></i> 100%</div>';
			} else {
				if ($query['result'] > 0 && $query_2['result'] > 0) {
					if ($query['result'] > $query_2['result']) {
						$val = $query['result'] * 100 / ($query['result'] + $query_2['result']);
						$val = $this->template->separator_only($val);
					} else {
						$val = $query_2['result'] * 100 / ($query['result'] + $query_2['result']);
						$val = $this->template->separator_only($val);
					}
				}
				if ($query['result'] > $query_2['result']) {
					$progress = '<div class="text-green"><i class="bi bi-chevron-double-up"></i> ' . $val . '%</div>';
				} else if ($query['result'] < $query_2['result']) {
					$progress = '<div class="text-red"><i class="bi bi-chevron-double-down"></i> ' . $val . '%</div>';
				} else {
					$progress = '<div class="text-black"><i class="bi bi-chevron-double-right"></i> 0%</div>';
				}
			}
		}

		$html['html'] = $text;
		$html['progress'] = $progress;
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($html, true);
	}
	function get_summary_v2()
	{
		$id = $_GET['id'];
		$type = $_GET['type'];
		$start_date = $_GET['start_date'];
		$until_date = $_GET['until_date'];
		$start_year = $_GET['start_year'];
		$until_year = $_GET['until_year'];
		$start_month = $_GET['start_month'];
		$until_month = $_GET['until_month'];
		$start_week = $_GET['start_week'];
		$until_week = $_GET['until_week'];
		$brand = $_GET['brand'];

		if ($type == "Yearly") {
			$start_date = $start_year . '-01-01';
			$until_date = $until_year . '-12-31';
		} else if ($type == "Monthly") {
			$start_month = str_pad($start_month, 2, "0", STR_PAD_LEFT);
			$until_month = str_pad($until_month, 2, "0", STR_PAD_LEFT);
			$start_date = $start_year . '-' . $start_month . '-01';
			$until_date = $start_year . '-' . $until_month . '-31';
		} else if ($type == "Weekly") {
			$start_week = str_pad($start_week, 2, "0", STR_PAD_LEFT);
			$until_week = str_pad($until_week, 2, "0", STR_PAD_LEFT);

			$year = $start_year;
			$week = $start_week;
			$start_date = date("Y-m-d", strtotime($year . "W" . $week . "1"));

			$year = $start_year;
			$week = $until_week;
			$until_date = date("Y-m-d", strtotime($year . "W" . $week . "7"));
		}

		$qry = "";
		if ($brand) {
			$qry .= " AND brand = '$brand' ";
		}



		$text = "0";

		if ($id == "kol-1") {

			$query = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM endorse
			WHERE DATE(posting_at) >= '$start_date' AND DATE(posting_at) <= '$until_date'
			GROUP BY influencer
			");

			$query = $query[0];
			$text = $this->template->separator_only($query['result']);
		} else if ($id == "kol-2") {

			$query = $this->mymodel->selectWithQuery("SELECT COUNT(id) as result FROM endorse
			WHERE DATE(posting_at) >= '$start_date' AND DATE(posting_at) <= '$until_date'");

			$query = $query[0];
			$text = $this->template->separator_only($query['result']);
		} else if ($id == "kol-3") {
			$status = "'DP','FP','Barang Dikirim','Draft Content','Posted Content'";
			$query = $this->mymodel->selectWithQuery("SELECT SUM(total_cost) as result FROM endorse
			WHERE DATE(posting_at) >= '$start_date' AND DATE(posting_at) <= '$until_date' AND 
			status_endorse IN ($status)
 			");

			$query = $query[0];
			$text = $this->template->separator_only($query['result']);
		} else if ($id == "kol-4") {

			// $query = $this->mymodel->selectWithQuery("SELECT SUM(views) as result FROM endorse");
			// 
			// $query = $query[0];
			$text = $this->template->separator_only($query['result']);
		} else if ($id == "kol-5") {

			// $query = $this->mymodel->selectWithQuery("SELECT SUM(endorse.likes) as result FROM endorse");
			// 
			// $query = $query[0];
			$text = $this->template->separator_only($query['result']);
		} else if ($id == "kol-6") {

			// $query = $this->mymodel->selectWithQuery("SELECT SUM(comment) as result FROM endorse");
			// 
			// $query = $query[0];
			$text = $this->template->separator_only($query['result']);
		} else if ($id == "kol-7") {

			// $query = $this->mymodel->selectWithQuery("SELECT SUM(share_save) as result FROM endorse");
			// 
			// $query = $query[0];
			$text = $this->template->separator_only($query['result']);
		} else if ($id == "kol-8") {

			// $query = $this->mymodel->selectWithQuery("SELECT SUM(total_cost) / SUM(views) * 1000 as result FROM endorse");
			// 
			// $query = $query[0];
			$text = $this->template->separator_only($query['result']);
		}

		$html['html'] = $text;
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($html, true);
	}

	function createRange($start, $end, $format = 'Y-m-d')
	{
		$start = strtotime($start);
		$end = strtotime($end);
		$range = array();

		$date = strtotime("-1 day", $start);
		while ($date < $end) {
			$date = strtotime("+1 day", $date);
			$range[] = date('Y-m-d', $date);
		}
		return $range;
	}



	function get_chart()
	{


		// $product = $this->mymodel->selectWithQuery("SELECT * FROM product
		// ORDER BY sku ASC
		// ");
		// $product_arr = array();
		// foreach($product as $k=>$v){
		//     $product_arr[$v['id']] = $v;
		// }

		// $data = $this->mymodel->selectWithQuery("SELECT id,json
		// FROM transaction
		// WHERE json != ''
		// ORDER BY id DESC");

		// foreach($data as $k=>$v){
		// 	$json = json_decode($v['json'],true);
		// 	$arr = array();
		// 	$hpp = 0;
		// 	foreach($json as $kk=>$vv){
		// 		$arr[$kk] = $vv;
		// 		// echo $vv['product'];die;
		// 		$arr[$kk]['hpp'] = strval($product_arr[$vv['product']]['price_buy']);
		// 		$arr[$kk]['price_total_hpp'] = strval($product_arr[$vv['product']]['price_buy'] * $vv['qty']);
		// 		$hpp += $arr[$kk]['price_total_hpp'];
		// 	}
		// 	$dt['json'] = json_encode($arr,true);
		// 	$dt['hpp'] = $hpp;
		// 	$model = $this->db->table('transaction');
		// 	$model->where('id', $v['id']);
		// 	$model->update($dt);

		// }



		// die;

		$checkbox = $_SESSION['checkbox_dashboard'];

		$skip = 0;
		for ($i = 0; $i <= 3; $i++) {
			if ($checkbox[$i] == 'false') {
				$skip++;
			}
		}
		if ($skip >= 5) {
			$html['html'] = '<i>Pastikan memilih minimal 1 filter!</i>';
			$html['table'] = '';
			header('Content-Type: application/json; charset=utf-8');
			echo json_encode($html, true);
			die;
		}

		$type = $_GET['type'];
		$start_date = $_GET['start_date'];
		$until_date = $_GET['until_date'];
		$start_year = $_GET['start_year'];
		$until_year = $_GET['until_year'];
		$start_month = $_GET['start_month'];
		$until_month = $_GET['until_month'];
		$start_week = $_GET['start_week'];
		$until_week = $_GET['until_week'];
		$site = $_GET['site'];
		$customer = $_GET['customer'];
		$mpu = $_GET['mpu'];

		if ($type == "Yearly") {
			$qry_opt = " YEAR(date) ";
			$start_date = $start_year . '-01-01';
			$until_date = $until_year . '-12-31';
			$group = "  GROUP BY YEAR(date) ";
		} else if ($type == "Monthly") {
			$qry_opt = " MONTH(date) ";
			$start_month = str_pad($start_month, 2, "0", STR_PAD_LEFT);
			$until_month = str_pad($until_month, 2, "0", STR_PAD_LEFT);
			$start_date = $start_year . '-' . $start_month . '-01';
			$until_date = $start_year . '-' . $until_month . '-31';
			$group = "  GROUP BY MONTH(date) ";
		} else if ($type == "Weekly") {
			$qry_opt = " WEEK(date) ";
			$start_week = str_pad($start_week, 2, "0", STR_PAD_LEFT);
			$until_week = str_pad($until_week, 2, "0", STR_PAD_LEFT);

			$year = $start_year;
			$week = $start_week;
			$start_date = date("Y-m-d", strtotime($year . "W" . $week . "1"));

			$year = $start_year;
			$week = $until_week;
			$until_date = date("Y-m-d", strtotime($year . "W" . $week . "7"));
			$group = "  GROUP BY WEEK(date) ";
		} else {
			$qry_opt = " DATE(date) ";
			$group = "  GROUP BY DATE(date) ";
		}

		$qry = " DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' ";
		$qry_2 = " DATE(date) >= '$start_date' AND DATE(date) <= '$until_date' ";

		// $qry = "";
		// $qry_2 = "";
		$brand = $_GET['brand'];
		if ($brand) {
			$qry .= " AND brand = '$brand' ";
			$qry_2 .= " AND brand = '$brand' ";
		}
		$channel = $_GET['channel'];
		if ($channel) {
			$qry .= " AND marketplace = '$channel' ";
		}



		$arr = array();

		$code = $_GET['code'];
		$title = $_GET['title'];

		$list = $this->mymodel->selectWithQuery("SELECT COUNT(id) as val, $qry_opt as opt
		FROM transaction
		WHERE $qry AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $group");

		$list_2 = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor) as val, $qry_opt as opt
		FROM transaction
		WHERE $qry AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $group");

		$list_3 = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor-diskon_penjual) as val, $qry_opt as opt
		FROM transaction
		WHERE $qry AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $group");

		$list_4 = $this->mymodel->selectWithQuery("SELECT SUM(omset_kotor-diskon_penjual-hpp-diskon_penjual-marketplace_fee-komisi_afiliasi) as val, $qry_opt as opt
		FROM transaction
		WHERE $qry AND order_status NOT IN ('RETURN','REFUND','CANCELLED','IN_CANCELLED','UNPAID') AND type_sub = 'POS' $group");

		$list_5 = $this->mymodel->selectWithQuery("SELECT ABS(SUM(price_total)) as val, $qry_opt as opt
		FROM transaction
		WHERE $qry_2 AND type_sub = 'Expense' $group");



		if ($type == "Yearly") {
			$range = array();
			for ($i = $start_year; $i <= $until_year; $i++) {
				$range[] = intval($i);
			}
			foreach ($range as $k2 => $v2) {
				$val = 0;
				$val_2 = 0;
				$val_3 = 0;
				$val_4 = 0;
				$val_5 = 0;
				foreach ($list as $k => $v) {
					if ($v['opt'] == $v2) {
						$val += $v['val'];
					}
				}
				foreach ($list_2 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_2 += $v['val'];
					}
				}
				foreach ($list_3 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_3 += $v['val'];
					}
				}
				foreach ($list_4 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_4 += $v['val'];
					}
				}
				foreach ($list_5 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_5 += $v['val'];
					}
				}
				$i = $k2;
				// $v['opt'] = substr($v2, -2);
				$v['opt'] = $v2;
				$arr[$i]['opt'] = $v['opt'];
				$arr[$i]['val'] = round($val, 2);
				$arr[$i]['val_2'] = round($val_2, 2);
				$arr[$i]['val_3'] = round($val_3, 2);
				$arr[$i]['val_4'] = round($val_4, 2);
				$arr[$i]['val_5'] = round($val_5, 2);
			}
		} else if ($type == "Monthly") {
			$range = array();
			for ($i = $start_month; $i <= $until_month; $i++) {
				$range[] = intval($i);
			}
			foreach ($range as $k2 => $v2) {
				$val = 0;
				$val_2 = 0;
				$val_3 = 0;
				$val_4 = 0;
				$val_5 = 0;
				foreach ($list as $k => $v) {
					if ($v['opt'] == $v2) {
						$val += $v['val'];
					}
				}
				foreach ($list_2 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_2 += $v['val'];
					}
				}
				foreach ($list_3 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_3 += $v['val'];
					}
				}
				foreach ($list_4 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_4 += $v['val'];
					}
				}
				foreach ($list_5 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_5 += $v['val'];
					}
				}
				$i = $k2;
				$v['opt'] = substr($v2, -2);
				$arr[$i]['opt'] = $v['opt'];
				$arr[$i]['val'] = round($val, 2);
				$arr[$i]['val_2'] = round($val_2, 2);
				$arr[$i]['val_3'] = round($val_3, 2);
				$arr[$i]['val_4'] = round($val_4, 2);
				$arr[$i]['val_5'] = round($val_5, 2);
			}
		} else if ($type == "Weekly") {
			$range = array();
			for ($i = $start_week; $i <= $until_week; $i++) {
				$range[] = intval($i);
			}

			foreach ($range as $k2 => $v2) {
				$val = 0;
				$val_2 = 0;
				$val_3 = 0;
				$val_4 = 0;
				$val_5 = 0;
				foreach ($list as $k => $v) {
					if ($v['opt'] == $v2) {
						$val += $v['val'];
					}
				}
				foreach ($list_2 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_2 += $v['val'];
					}
				}
				foreach ($list_3 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_3 += $v['val'];
					}
				}
				foreach ($list_4 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_4 += $v['val'];
					}
				}
				foreach ($list_5 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_5 += $v['val'];
					}
				}
				$i = $k2;
				$v['opt'] = substr($v2, -2);
				$arr[$i]['opt'] = $v['opt'];
				$arr[$i]['val'] = round($val, 2);
				$arr[$i]['val_2'] = round($val_2, 2);
				$arr[$i]['val_3'] = round($val_3, 2);
				$arr[$i]['val_4'] = round($val_4, 2);
				$arr[$i]['val_5'] = round($val_5, 2);
			}
		} else {
			$range = ($this->createRange($start_date, $until_date));
			foreach ($range as $k2 => $v2) {
				$val = 0;
				$val_2 = 0;
				$val_3 = 0;
				$val_4 = 0;
				$val_5 = 0;
				foreach ($list as $k => $v) {
					if ($v['opt'] == $v2) {
						$val += $v['val'];
					}
				}
				foreach ($list_2 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_2 += $v['val'];
					}
				}
				foreach ($list_3 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_3 += $v['val'];
					}
				}
				foreach ($list_4 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_4 += $v['val'];
					}
				}
				foreach ($list_5 as $k => $v) {
					if ($v['opt'] == $v2) {
						$val_5 += $v['val'];
					}
				}
				$i = $k2;
				// $v['opt'] = substr($v2, -2);
				$v['opt'] = $v2;
				$arr[$i]['opt'] = $v['opt'];
				$arr[$i]['val'] = round($val, 2);
				$arr[$i]['val_2'] = round($val_2, 2);
				$arr[$i]['val_3'] = round($val_3, 2);
				$arr[$i]['val_4'] = round($val_4, 2);
				$arr[$i]['val_5'] = round($val_5, 2);
			}
		}


		$arr_new = array();

		// if ($type == "Yearly") {
		// 	for ($i = 0; $i < 12; $i++) {
		// 		$arr_new[$i] = $arr[$i];
		// 	};
		// } else if ($type == "Monthly") {
		// 	for ($i = 0; $i < 12; $i++) {
		// 		$arr_new[$i] = $arr[$i];
		// 	};
		// } else if ($type == "Weekly") {
		// 	for ($i = 0; $i < 12; $i++) {
		// 		$arr_new[$i] = $arr[$i];
		// 	};
		// } else {
		// 	for ($i = 0; $i <= 31; $i++) {
		// 		$arr_new[$i] = $arr[$i];
		// 	};
		// }

		$count = count($arr);

		if ($type == "Yearly") {
			for ($i = 0; $i < $count; $i++) {
				$arr_new[$i] = $arr[$i];
			};
		} else if ($type == "Monthly") {
			for ($i = 0; $i < $count; $i++) {
				$arr_new[$i] = $arr[$i];
			};
		} else if ($type == "Weekly") {
			for ($i = 0; $i < $count; $i++) {
				$arr_new[$i] = $arr[$i];
			};
		} else {
			for ($i = 0; $i < $count; $i++) {
				$arr_new[$i] = $arr[$i];
			};
		}

		$th_table = "";
		$td_1 = "";
		$td_2 = "";
		$td_3 = "";
		$td_4 = "";
		$td_5 = "";

		$opt = "";
		$val = "";
		$a = "";

		$color = "";
		$val_arr_1 = array(0, 0);
		$val_arr_2 = array(0, 0);
		$val_arr_3 = array(0, 0);
		$val_arr_4 = array(0, 0);
		$val_arr_5 = array(0, 0);
		foreach ($arr_new as $k => $v) {
			// $v['opt'] = substr($v['opt'], -2);

			if ($type == "Yearly") {
			} else if ($type == "Monthly") {
			} else if ($type == "Weekly") {
			} else {
				$v['opt'] = DATE("d M Y", strtotime($v['opt']));
			}

			$opt .= "'" . $v['opt'] . "',";

			if ($v['opt']) {
				$a .= "'" . $this->template->separator_number_only($v['val']) . "',";
				$b .= "'" . $this->template->separator_number_only($v['val_2']) . "',";
				$c .= "'" . $this->template->separator_number_only($v['val_3']) . "',";
				$d .= "'" . $this->template->separator_number_only($v['val_4']) . "',";
				$e .= "'" . $this->template->separator_number_only($v['val_5']) . "',";
				$th_table .= "<th>" . $v['opt'] . "</th>";
				$td_1 .= "<td>" . $this->template->separator_only((($v['val']))) . "</td>";
				$td_2 .= "<td>" . $this->template->separator_only((($v['val_2']))) . "</td>";
				$td_3 .= "<td>" . $this->template->separator_only((($v['val_3']))) . "</td>";
				$td_4 .= "<td>" . $this->template->separator_only((($v['val_4']))) . "</td>";
				$td_5 .= "<td>" . $this->template->separator_only((($v['val_5']))) . "</td>";
				$val_arr_1[] = round($v['val']);
				$val_arr_2[] = round($v['val_2']);
				$val_arr_3[] = round($v['val_3']);
				$val_arr_4[] = round($v['val_4']);
				$val_arr_5[] = round($v['val_5']);
			}

			$color .= "'" . $v['color'] . "',";
		}

		$min_1 = min($val_arr_1);
		$max_1 = max($val_arr_1);
		$min_2 = min($val_arr_2);
		$max_2 = max($val_arr_2);
		$min_3 = min($val_arr_3);
		$max_3 = max($val_arr_3);
		$min_4 = min($val_arr_4);
		$max_4 = max($val_arr_4);
		$min_5 = min($val_arr_5);
		$max_5 = max($val_arr_5);


		$min_1 = 0;
		$min_2 = 0;


		if ($checkbox[0] == 'true') {
			$max_1 = $max_1;
		} else {
			$max_1 = 0;
		}
		if ($checkbox[1] == 'true') {
			if ($max_2 > $max_1) {
				$max_1 = $max_2;
			}
		}
		if ($checkbox[2] == 'true') {
			if ($max_3 > $max_1) {
				$max_1 = $max_3;
			}
		}
		if ($checkbox[3] == 'true') {
			if ($max_4 > $max_1) {
				$max_1 = $max_4;
			}
		}
		if ($checkbox[4] == 'true') {
			if ($max_5 > $max_1) {
				$max_1 = $max_5;
			}
		}

		$max_1 = intval($max_1);


		if ($max_1 > 10000000) {
			$max_1 =  ($max_1 - ($max_1 % 10000000)) * 2.2;
		} else if ($max_1 > 1000000) {
			$max_1 =  ($max_1 - ($max_1 % 1000000)) * 2.2;
		} else if ($max_1 > 100000) {
			$max_1 =  ($max_1 - ($max_1 % 100000)) * 2.2;
		} else if ($max_1 > 10000) {
			$max_1 =  ($max_1 - ($max_1 % 10000)) * 2.2;
		} else if ($max_1 > 1000) {
			$max_1 =  ($max_1 - ($max_1 % 1000)) * 2.2;
		} else if ($max_1 > 100) {
			$max_1 =  ($max_1 - ($max_1 % 100)) * 2.2;
		} else if ($max_1 > 10) {
			$max_1 =  ($max_1 - ($max_1 % 10)) * 2.2;
		} else if ($max_1 > 0) {
			$max_1 =  ($max_1 - ($max_1 % 1)) * 2.2;
		}


		$item_1 = '';
		$item_2 = '';
		$item_3 = '';

		if ($checkbox[0] == 'true') {
			$item_1 .= '
			{
				type: "line",
				label: " Jumlah Order ",
				fill: "start",
    			backgroundColor: gradient_1,
				borderColor: ["' . $this->template->hex(4) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $a . '],
				yAxisID: "y1",
			},	
			';
			$item_3 .= '
			<tr>
			<td class="text-start"> 
				<div class="d-flex justify-content-start">
					<div style="background-color: ' . $this->template->hex(4) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
					</div>Jumlah Order
				</div>
			</td>
			' . $td_1 . '
			</tr>
													';
		}
		if ($checkbox[1] == 'true') {
			$item_1 .= '
			{
				type: "line",
				label: " Penjualan Kotor ",
				fill: "start",
    			backgroundColor: gradient_2,
				borderColor: ["' . $this->template->hex(1) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $b . '],
				yAxisID: "y2",
			},		
			';
			$item_3 .= '
		
			<tr>
			<td class="text-start"> 
				<div class="d-flex justify-content-start">
					<div style="background-color: ' . $this->template->hex(1) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
					</div>Penjualan Kotor
				</div>
			</td>
			' . $td_2 . '
			</tr>
			';
		}
		if ($checkbox[2] == 'true') {
			$item_1 .= '
			{
				type: "line",
				label: " Penjualan Bersih ",
				fill: "start",
    			backgroundColor: gradient_3,
				borderColor: ["' . $this->template->hex(2) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $c . '],
				yAxisID: "y2",
			},		
			';
			$item_3 .= '
		
			<tr>
			<td class="text-start"> 
				<div class="d-flex justify-content-start">
					<div style="background-color: ' . $this->template->hex(2) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
					</div>Penjualan Bersih
				</div>
			</td>
			' . $td_3 . '
			</tr>
			';
		}
		if ($checkbox[3] == 'true') {
			$item_1 .= '
			
			{
				type: "line",
				label: " Laba Bersih ",
				fill: "start",
    			backgroundColor: gradient_4,
				borderColor: ["' . $this->template->hex(0) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $d . '],
				yAxisID: "y3",
			},	
			';
			$item_3 .= '
			
			<tr>
			<td class="text-start"> 
				<div class="d-flex justify-content-start">
					<div style="background-color: ' . $this->template->hex(0) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
					</div>Laba Bersih
				</div>
			</td>
			' . $td_4 . '
			</tr>
			';
		}
		if ($checkbox[4] == 'true') {
			$item_1 .= '
			
			{
				type: "line",
				label: " Pengeluaran ",
				fill: "start",
    			backgroundColor: gradient_5,
				borderColor: ["' . $this->template->hex(3) . '"],
				borderWidth: 2, pointRadius: 0, cubicInterpolationMode: "monotone",
				data: [' . $e . '],
				yAxisID: "y4",
			},	
			';
			$item_3 .= '
		
			<tr>
			<td class="text-start"> 
				<div class="d-flex justify-content-start">
					<div style="background-color: ' . $this->template->hex(3) . '; width: 7px; height: 7px;margin-right:5px;margin-top:4px">
					</div>Pengeluaran
				</div>
			</td>
			' . $td_5 . '
			</tr>
			';
		}


		$key = 'get_chart_' . DATE("Ymdhis");

		$html['html'] = '
                                                    <canvas class="chart" id="' . $key . '"></canvas>
                                                    <script>
                                                    const ' . $key . ' = document.getElementById(
                                                        "' . $key . '").getContext("2d");


var gradient_1 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_1.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(4)) . '")
gradient_1.addColorStop(0.75, "rgba(225, 225, 225, 0)")

var gradient_2 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_2.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(1)) . '")
gradient_2.addColorStop(0.75, "rgba(225, 225, 225, 0)")

var gradient_3 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_3.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(2)) . '")
gradient_3.addColorStop(0.75, "rgba(225, 225, 225, 0)")

var gradient_4 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_4.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(0)) . '")
gradient_4.addColorStop(0.75, "rgba(225, 225, 225, 0)")

var gradient_5 = ' . $key . '.createLinearGradient(0,0,0,' . $key . '.canvas.clientHeight)
gradient_5.addColorStop(0, "' . $this->template->hex_to_rgb($this->template->hex(3)) . '")
gradient_5.addColorStop(0.75, "rgba(225, 225, 225, 0)")

                                                    new Chart(' . $key . ', {
                                                        type: "line",
                                                        data: {
                                                            datasets: [
                                                                		' . $item_1 . '					
                                                            ],
                                                            labels: [' . $opt . ']
                                                        },
                                                        options: {
															responsive: true,
															bezierCurve : false,
															maintainAspectRatio: false, 
															aspectRatio: 3.1, 
															interaction: {
															mode: "index",
															intersect: false,
														},
														plugins:{
															legend: { display:false,
																labels: {
																  font: {
																	size: 8
																  }
																}
															},
														},
														stacked: false,
														
														scales: {
														x:{
															ticks: {												
																autoSkip: true,	
																maxTicksLimit: 10,											
																font: {													
																	size: 11,												
																}											
															},
															grid: {
																display: false,
															}
														},
														y1: {
															type: "linear",
															display: true,
															position: "left",
															min:0,
															max:' . $max_1 . ',
															ticks: {												
																autoSkip: false,												
																font: {													
																	size: 8,												
																}											
															}
														},
														y2: {
															type: "linear",
															display: false,
															position: "left",
															min:0,
															max:' . $max_1 . ',
															ticks: {												
																autoSkip: false,												
																font: {													
																	size: 8,												
																}											
															}
														},
														y3: {
															type: "linear",
															display: false,
															position: "left",
															min:0,
															max:' . $max_1 . ',
															ticks: {												
																autoSkip: false,												
																font: {													
																	size: 8,												
																}											
															}
														},
														y4: {
															type: "linear",
															display: false,
															position: "left",
															min:0,
															max:' . $max_1 . ',
															ticks: {												
																autoSkip: false,												
																font: {													
																	size: 8,												
																}											
															}
														},
														},
														},

                                                    });
                                                    </script>';

		$html['table'] = '
													<div class="table-responsive">
													<table class="table able-bordered table-stats">
													<tr>
													<th class="text-start">#</th>
													' . $th_table . '
													</tr>
													' . $item_3 . '
													</table>
													</div>
													';
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($html, true);
	}
}
