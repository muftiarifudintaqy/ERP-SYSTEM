<?php

defined('BASEPATH') or exit('No direct script access allowed');
class Shipping extends CI_Controller
{
    public function index()
    {

        if ($_GET['keyword_category']) {
            $keyword_category = $_GET['keyword_category'];
        } else {
            $keyword_category = "Nama Ekspedisi";
        }
        $data['keyword_category'] = $keyword_category;
        $keyword = $_GET['keyword'];

        if ($_GET['start_date'] == "") {
            $start_date = DATE("Y-m-d");
        } else {
            $start_date = $_GET['start_date'];
        }
        if ($_GET['until_date'] == "") {
            $until_date = DATE("Y-m-d");
        } else {
            $until_date = $_GET['until_date'];
        }

        $data['start_date'] = $start_date;
        $data['until_date'] = $until_date;
        $data['brand'] = $brand;

        $data['title'] = 'Ekspedisi - ' . $this->template->title();


        $query = $this->mymodel->selectWithQuery("SELECT * FROM shipping ORDER BY name ASC");

        $data['shipping'] = $query;

        $query = $this->mymodel->selectWithQuery("SELECT * FROM brand WHERE status = 'ENABLE' ORDER BY name ASC");

        $data['brands'] = $query;


        $qry = "";
        $qry = " 1=1 ";

        if ($brand) {
            $qry .= " AND brand = '$brand' ";
        }

        if ($shipping) {
            $qry .= " AND shipping = '$shipping' ";
        }

        if ($keyword) {
            if ($keyword_category == "Nama Ekspedisi") {
                $qry .= " AND name LIKE '%$keyword%' ";
            } else if ($keyword_category == "Keterangan") {
                $qry .= " AND shipping.desc LIKE '%$keyword%' ";
            }
        }

        $query = $this->mymodel->selectWithQuery("SELECT COUNT(id) AS count
        FROM shipping
        WHERE $qry
        ");

        $data['page'] = CEIL($query[0]['count'] / 30);

        $data['notif'] = '<p class="mb-1"><label class="text-notif">' . $this->template->separator_only($query[0]['count']) . ' data ditemukan!</label></p>';

        $item = '';

        $current_page = intval($_GET['page']);
        if ($current_page <= 1) {
            $current_page = 1;
        }

        $url = base_url() . '/shipping/' . $this->template->get_param();
        $data['url'] = $this->template->get_param_without_keyword_category($url);
        $data['param'] = $this->template->get_param();
        $data['param_pagination'] = $this->template->get_param_without('page');
        $data['pagination'] = $this->template->pagination($data['page'], $current_page, $data['param_pagination']);

        $data['content'] = $this->load->view("shipping/all", $data, true);
        $this->load->view("TemplateDashboard", $data);
    }

    public function item()
    {

        $data['template'] = $this->template;

        if ($_GET['keyword_category']) {
            $keyword_category = $_GET['keyword_category'];
        } else {
            $keyword_category = "Nama Ekspedisi";
        }
        $data['keyword_category'] = $keyword_category;
        $keyword = $_GET['keyword'];

        if ($_GET['start_date']) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = DATE('Y-m-d');
        }
        if ($_GET['until_date']) {
            $until_date = $_GET['until_date'];
        } else {
            $until_date = DATE('Y-m-d');
        }
        $qry = "";
        $qry = " 1=1 ";

        if ($brand) {
            $qry .= " AND brand = '$brand' ";
        }

        if ($shipping) {
            $qry .= " AND shipping = '$shipping' ";
        }

        if ($keyword) {
            if ($keyword_category == "Nama Ekspedisi") {
                $qry .= " AND name LIKE '%$keyword%' ";
            } else if ($keyword_category == "Keterangan") {
                $qry .= " AND shipping.desc LIKE '%$keyword%' ";
            }
        }

        $limit = 30;

        $current_page = $_GET['page'];

        if ($current_page <= 1) {
            $offset = 0;
        } else {
            $offset = ($current_page - 1) * $limit;
        }

        $query = $this->mymodel->selectWithQuery("SELECT * FROM shipping
        WHERE $qry 
        ORDER BY name ASC, name ASC
        LIMIT $offset, $limit
        ");


        $data['data'] = $query;

        $data['start'] = $offset;
        $this->load->view("shipping/item", $data);
    }


    public function sync()
    {

        $data = $this->template->get_session('filter');

        $this->load->view("shipping/sync", $data);
    }

    public function sync_process()
    {
        $filter = $this->template->get_session('filter');
        $start_date = $filter['start_date'] . ' 00:00:00';
        $until_date = $filter['until_date'] . ' 00:00:00';

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => base_url() . '/api/shopee/get-product',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Cookie: ci_session=ji2dpajlqasgk8200eroqtjrri48iugl'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => base_url() . '/api/lazada/get-product',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Cookie: ci_session=ji2dpajlqasgk8200eroqtjrri48iugl'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        $response = str_replace('SuccessToken', '', $response);

        if ($response == "Success") {
            $msg = 'Sync data berhasil!';
            echo $this->template->alert_success($msg);
            die;
        } else {
            $msg = $response;
            echo $this->template->alert_danger($msg);
            die;
        }
    }


    public function item_stock()
    {


        $id = $_GET['id'];

        $qry = "";
        $qry = " shipping = '$id' ";

        $limit = 30;

        $current_page = $_GET['page'];

        if ($current_page <= 1) {
            $offset = 0;
        } else {
            $offset = ($current_page - 1) * $limit;
        }

        $query = $this->mymodel->selectWithQuery("
        SELECT * FROM stock
        WHERE $qry 
        ORDER BY date ASC, id ASC
        LIMIT $offset, $limit
        ");

        $data['data'] = $query;
        $data['balance'] = 0;
        if ($current_page > 1) {
            $query = $this->mymodel->selectWithQuery("SELECT sum(qty) as sum
            FROM (
                SELECT qty
                FROM stock
                WHERE shipping = '$id'
                ORDER BY date ASC, id ASC
                LIMIT 0, $offset
            ) AS subquery");

            $data['balance'] = $query[0]['sum'];
        }

        $data['start'] = $offset;
        $this->load->view("shipping/item_stock", $data);
    }



    public function stock()
    {

        $data['title'] = 'Product Stock - ' . $this->template->title();

        $id = $_GET['id'];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM shipping WHERE id = '$id'");

        $data['data'] = $query[0];

        if (empty($data['data'])) {
            return redirect()->to(site_url('stock'));
        }

        $qry = "";
        $qry = " shipping = '$id' ";


        $limit = 30;

        $offset = intval($_GET['offset']);

        $query = $this->mymodel->selectWithQuery("SELECT COUNT(id) as count FROM stock
        WHERE $qry ");

        $data['page'] = CEIL($query[0]['count'] / 30);

        $item = '';

        $current_page = intval($_GET['page']);
        if ($current_page <= 1) {
            $current_page = 1;
        }

        $url = base_url() . '/shipping/stock?id=' . $_GET['id'];

        $data['pagination'] = $this->template->pagination($data['page'], $current_page, $url);

        $data['content'] = $this->load->view("shipping/stock", $data);
        $this->load->view("TemplateDashboard", $data);
    }

    public function edit()
    {
        $id = $_GET['id'];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM shipping WHERE id = '$id'");

        $data['data'] = $query[0];

        $id_parent = $id;
        $data['item'] = $this->mymodel->selectWithQuery("SELECT * FROM product_variant_3rd WHERE id_parent = '$id_parent'
        ORDER BY name ASC
        ");

        $query = $this->mymodel->selectWithQuery("SELECT * FROM product ORDER BY name ASC");

        $data['product'] = $query;

        $text = '';
        foreach ($data['product'] as $k => $v) {
            $text .= '<option value="' . $v['id'] . '">' . $v['sku'] . ' | ' . $v['name'] . '</option>';
        }
        $data['opt_product'] = $text;
        $this->load->view("shipping/edit", $data);
    }

    public function update()
    {

        $user = $_SESSION['user'];

        $id = $_POST['id'];
        $dt = $_POST['dt'];

        if (!empty($_FILES['file']['name'])) {
            $dir  = "./assets/img/shipping/";
            $config['upload_path']   = $dir;
            $config['allowed_types'] = 'jpg|jpeg|png';
            $config['overwrite']     = TRUE;
            $config['file_name']     = $id;
            $config['max_size']      = 2048;
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('file')) {
                $error = $this->upload->display_errors();
                echo $this->template->alert_danger($error);
                die;
            } else {
                $file = $this->upload->data();
                $dt['img'] = $file['file_name'];
            }
        }

        $dt['updated_at'] = DATE("Y-m-d H:i:s");
        $dt['updated_by'] = $user['id'];

        if ($this->db->update('shipping', $dt, array('id' => $id))) {
            $msg = 'Update data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Update data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }

    public function create()
    {
        $data['data'] = array();

        $query = $this->mymodel->selectWithQuery("SELECT * FROM brand ORDER BY name aSC");

        $data['brand'] = $query;

        $this->load->view("shipping/create", $data);
    }


    public function store()
    {

        $user = $_SESSION['user'];

        $id = $_POST['id'];
        $dt = $_POST['dt'];
        $dt['created_at'] = DATE("Y-m-d H:i:s");
        $dt['created_by'] = $user['id'];

        if (!empty($_FILES['file']['name'])) {
            $dir  = "./assets/img/shipping/";
            $config['upload_path']   = $dir;
            $config['allowed_types'] = 'jpg|jpeg|png';
            $config['overwrite']     = TRUE;
            $config['file_name']     = DATE("Ymdhis");
            $config['max_size']      = 2048;
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('file')) {
                $error = $this->upload->display_errors();
                echo $this->template->alert_danger($error);
                die;
            } else {
                $file = $this->upload->data();
                $dt['img'] = $file['file_name'];
            }
        }


        if ($this->db->insert('shipping', $dt)) {
            $msg = 'Tambah data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Tambah data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }



    public function remove()
    {
        $id = $_GET['id'];
        $data['data']['id'] = $id;
        $this->load->view("shipping/delete", $data);
    }

    public function delete()
    {


        $id = $_POST['id'];

        if ($this->db->delete('shipping', array('id' => $id))) {
            $msg = 'Hapus data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Hapus data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }
}
