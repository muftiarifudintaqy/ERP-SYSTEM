<?php

defined('BASEPATH') or exit('No direct script access allowed');
class User extends CI_Controller
{
    function hasDuplicates($arr)
    {
        $counts = array_count_values($arr);
        $duplicates = array_filter($counts, function ($count) {
            return $count > 1;
        });

        return count($duplicates) > 0;
    }
    public function index()
    {
        // $marketplace = 'SHOPEE';
        // 
        // $user = $_SESSION['user'];
        // $arr = array();

        // //  // Count occurrences of each value in the array
        // //  $counts = array_count_values($arr);

        // //  // Filter the array to keep only elements that have a count greater than 1 (i.e., duplicates)
        // //  $duplicates = array_filter($counts, function($value) {
        // //      return $value > 1;
        // //  });

        // //  // Output the duplicate elements
        // //  print_r(array_keys($duplicates));
        // //  die;

        // // echo count($arr);die;
        // foreach($arr as $k=>$v){
        //     $order_id = $v;
        //     $trx = $this->mymodel->selectWithQuery("SELECT id
        //     FROM transaction WHERE order_id = '$order_id' 
        //     -- AND marketplace = '$marketplace' 
        //     ");
        //     if(empty($trx)){
        //         echo $order_id.',<br>';
        //         $dt['order_id'] = $order_id;
        //         $dt['date'] = DATE("2024-04-18 00:00:01");
        //         $dt['created_at'] = DATE("Y-m-d H:i:s");
        //         $dt['created_by'] = $user['id'];
        //         $dt['marketplace'] = $marketplace;
        //         $dt['brand'] = 'POME';
        //         $dt['type'] = 'Out';
        //         $dt['type_sub'] = 'POS';
        //         $model = $db->table('transaction');
        //         $model->insert($dt);
        //         // die;
        //     }
        // }
        // // print_r($arr);
        // die;

        if ($_GET['keyword_category']) {
            $keyword_category = $_GET['keyword_category'];
        } else {
            $keyword_category = "Nama Lengkap";
        }
        $data['keyword_category'] = $keyword_category;
        $keyword = $_GET['keyword'];

        if ($_GET['start_date'] == "") {
            $start_date = DATE("Y-m-d");
        } else {
            $start_date = $_GET['start_date'];
        }
        if ($_GET['until_date'] == "") {
            $until_date = DATE("Y-m-d");
        } else {
            $until_date = $_GET['until_date'];
        }

        $data['role'] = $this->mymodel->selectWithQuery("SELECT * FROM role");
        $data['start_date'] = $start_date;
        $data['until_date'] = $until_date;
        $data['brand'] = $brand;

        $data['title'] = 'User - ' . $this->template->title();



        $qry = "";
        $qry = " 1=1 ";

        if ($brand) {
            $qry .= " AND brand = '$brand' ";
        }
        $status = $_GET['status'];
        if ($status) {
            $qry .= " AND status_reach = '$status' ";
        }

        if ($keyword) {
            if ($keyword_category == "Nama Lengkap") {
                $qry .= " AND full_name LIKE '%$keyword%' ";
            } else if ($keyword_category == "Email") {
                $qry .= " AND user.email LIKE '%$keyword%' ";
            } else if ($keyword_category == "Keterangan") {
                $qry .= " AND user.desc LIKE '%$keyword%' ";
            } else if ($keyword_category == "Role") {
                $qry .= " AND user.role_text LIKE '%$keyword%' ";
            }
        }

        $data['user'] = $_SESSION['user'];
        if (in_array($data['user']['role'], array('1'))) {
            $query = $this->mymodel->selectWithQuery("SELECT COUNT(id) AS count
            FROM user
            WHERE $qry
            ");
        } else if (in_array($data['user']['role'], array('2'))) {
            $query = $this->mymodel->selectWithQuery("SELECT COUNT(id) AS count
            FROM user
            WHERE $qry AND role NOT IN ('1','2')
            ");
        }

        $data['page'] = CEIL($query[0]['count'] / 30);

        $data['notif'] = '<p class="mb-1"><label class="text-notif">' . $this->template->separator_only($query[0]['count']) . ' data ditemukan!</label></p>';

        $item = '';

        $current_page = intval($_GET['page']);
        if ($current_page <= 1) {
            $current_page = 1;
        }

        $url = base_url() . '/user/' . $this->template->get_param();
        $data['url_1'] = $this->template->get_param_without_status($url);
        $data['url_2'] = $this->template->get_param_without_keyword_category($url);
        $data['param'] = $this->template->get_param();
        $data['param_pagination'] = $this->template->get_param_without('page');
        $data['pagination'] = $this->template->pagination($data['page'], $current_page, $data['param_pagination']);

        $data['content'] = $this->load->view("user/all", $data, true);
        $this->load->view("TemplateDashboard", $data);
    }

    public function item()
    {



        $data['template'] = $this->template;

        if ($_GET['keyword_category']) {
            $keyword_category = $_GET['keyword_category'];
        } else {
            $keyword_category = "Nama Lengkap";
        }
        $data['keyword_category'] = $keyword_category;
        $keyword = $_GET['keyword'];

        if ($_GET['start_date']) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = DATE('Y-m-d');
        }
        if ($_GET['until_date']) {
            $until_date = $_GET['until_date'];
        } else {
            $until_date = DATE('Y-m-d');
        }
        $qry = "";
        $qry = " 1=1 ";

        if ($brand) {
            $qry .= " AND brand = '$brand' ";
        }


        $status = $_GET['status'];
        if ($status) {
            $qry .= " AND status_reach = '$status' ";
        }

        if ($keyword) {
            if ($keyword_category == "Nama Lengkap") {
                $qry .= " AND full_name LIKE '%$keyword%' ";
            } else if ($keyword_category == "Email") {
                $qry .= " AND user.email LIKE '%$keyword%' ";
            } else if ($keyword_category == "Keterangan") {
                $qry .= " AND user.desc LIKE '%$keyword%' ";
            } else if ($keyword_category == "Role") {
                $qry .= " AND user.role_text LIKE '%$keyword%' ";
            }
        }

        $limit = 30;

        $current_page = $_GET['page'];

        if ($current_page <= 1) {
            $offset = 0;
        } else {
            $offset = ($current_page - 1) * $limit;
        }

        $data['user'] = $_SESSION['user'];

        if (in_array($data['user']['role'], array('1'))) {
            $query = $this->mymodel->selectWithQuery("SELECT * FROM user
            WHERE $qry 
            ORDER BY full_name ASC
            LIMIT $offset, $limit
            ");
        } else if (in_array($data['user']['role'], array('2'))) {
            $query = $this->mymodel->selectWithQuery("SELECT * FROM user
            WHERE $qry  AND role NOT IN ('1','2')
            ORDER BY full_name ASC
            LIMIT $offset, $limit
            ");
        }


        $data['data'] = $query;

        $data['start'] = $offset;
        $this->load->view("user/item", $data);
    }

    public function edit()
    {
        $id = $_GET['id'];


        $query = $this->mymodel->selectWithQuery("SELECT * FROM user WHERE id = '$id'");

        $data['data'] = $query[0];


        $data['user'] = $_SESSION['user'];
        if (in_array($data['user']['role'], array('1'))) {
            $query = $this->mymodel->selectWithQuery("SELECT * FROM role ORDER BY id ASC");
        } else if (in_array($data['user']['role'], array('2'))) {
            $query = $this->mymodel->selectWithQuery("SELECT * FROM role WHERE id NOT IN ('1','2') ORDER BY id ASC");
        }

        $data['role'] = $query;

        $this->load->view("user/edit", $data);
    }

    public function update()
    {

        $user = $_SESSION['user'];

        $id = $_POST['id'];
        $dt = $_POST['dt'];
        $dt['updated_at'] = DATE("Y-m-d H:i:s");
        $dt['updated_by'] = $user['id'];

        if ($dt['password']) {
            $dt['password'] = MD5($dt['password']);
        } else {
            unset($dt['password']);
        }

        $email = $dt['email'];
        $username = $dt['username'];

        $other_user = $this->mymodel->selectWithQuery("SELECT id FROM user
        WHERE username = '$username' AND id != '$id' ");

        if ($other_user) {
            $msg = 'Username sudah digunakan user lain!';
            echo $this->template->alert_danger($msg);
            die;
        }

        // $other_user = $this->mymodel->selectWithQuery("SELECT id FROM user
        // WHERE email = '$email' AND id != '$id' ");

        // if($other_user){
        //     $msg = 'Email sudah digunakan user lain!';
        //     echo $this->template->alert_danger($msg);
        //     die;
        // }

        $role = $dt['role'];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM role WHERE id = '$role'");

        $dt['role_text'] = strval($query[0]['role']);

        if (!empty($_FILES['file']['name'])) {
            $dir  = "./assets/img/user/";
            $config['upload_path']   = $dir;
            $config['allowed_types'] = 'jpg|jpeg|png';
            $config['overwrite']     = TRUE;
            $config['file_name']     = $id;
            $config['max_size']      = 2048;
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('file')) {
                $error = $this->upload->display_errors();
                echo $this->template->alert_danger($error);
                die;
            } else {
                $file = $this->upload->data();
                $dt['img'] = $file['file_name'];
            }
        }



        if ($this->db->update('user', $dt, array('id' => $id))) {
            $msg = 'Update data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Update data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }

    public function create()
    {
        $data['data'] = array();



        $data['user'] = $_SESSION['user'];
        if (in_array($data['user']['role'], array('1'))) {
            $query = $this->mymodel->selectWithQuery("SELECT * FROM role ORDER BY id ASC");
        } else if (in_array($data['user']['role'], array('2'))) {
            $query = $this->mymodel->selectWithQuery("SELECT * FROM role WHERE id NOT IN ('1','2') ORDER BY id ASC");
        }

        $data['role'] = $query;

        $this->load->view("user/create", $data);
    }


    public function store()
    {

        $user = $_SESSION['user'];

        $id = $_POST['id'];
        $dt = $_POST['dt'];
        $dt['created_at'] = DATE("Y-m-d H:i:s");
        $dt['created_by'] = $user['id'];

        if ($dt['password']) {
            $dt['password'] = MD5($dt['password']);
        } else {
            unset($dt['password']);
        }

        $email = $dt['email'];
        $username = $dt['username'];

        $other_user = $this->mymodel->selectWithQuery("SELECT id FROM user
        WHERE username = '$username' AND id != '$id' ");

        if ($other_user) {
            $msg = 'Username sudah digunakan user lain!';
            echo $this->template->alert_danger($msg);
            die;
        }

        // $other_user = $this->mymodel->selectWithQuery("SELECT id FROM user
        // WHERE email = '$email' AND id != '$id' ");

        // if($other_user){
        //     $msg = 'Email sudah digunakan user lain!';
        //     echo $this->template->alert_danger($msg);
        //     die;
        // }


        $role = $dt['role'];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM role WHERE id = '$role'");

        $dt['role_text'] = strval($query[0]['role']);
        if (!empty($_FILES['file']['name'])) {
            $dir  = "./assets/img/user/";
            $config['upload_path']   = $dir;
            $config['allowed_types'] = 'jpg|jpeg|png';
            $config['overwrite']     = TRUE;
            $config['file_name']     = DATE("Ymdhis");
            $config['max_size']      = 2048;
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('file')) {
                $error = $this->upload->display_errors();
                echo $this->template->alert_danger($error);
                die;
            } else {
                $file = $this->upload->data();
                $dt['img'] = $file['file_name'];
            }
        }

        if ($this->db->insert('user', $dt)) {
            $msg = 'Tambah data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Tambah data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }

    public function sync()
    {
        $id = $_GET['id'];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM user WHERE id = '$id'");

        $data['data'] = $query[0];
        $this->load->view("user/sync", $data);
    }

    public function sync_process()
    {

        $user = $_SESSION['user'];
        $id = $_POST['id'];


        $query = $this->mymodel->selectWithQuery("SELECT * FROM user WHERE id = '$id'");

        $v = $query[0];
        $response = $this->template->get_social_media($v['type'], $v['url']);
        $dt = array();
        $dt['updated_at'] = DATE("Y-m-d H:i:s");
        $dt['updated_by'] = $user['id'];
        if ($response['data']['like'] > 0) {
            $dt['like'] = $response['data']['like'];
            $dt['comment'] = $response['data']['comment'];
            $dt['collect'] = $response['data']['collect'];
            $dt['share'] = $response['data']['share'];
            $dt['view'] = $response['data']['view'];
            if ($v['cost'] > 0 && $dt['view'] > 0) {
                $dt['cpm'] = $v['cost'] / $dt['view'] * 1000;
            }
        }

        $this->db->update('user', $dt, array('id' => $v['id']));

        if ($response['status'] == true) {
            $msg = 'Sync data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            if ($response) {
                $msg = $response['msg'];
            } else {
                $msg = 'Data user belum tersedia!';
            }
            echo $this->template->alert_danger($msg);
        }
    }

    public function remove()
    {
        $id = $_GET['id'];
        $data['data']['id'] = $id;
        $this->load->view("user/delete", $data);
    }

    public function delete()
    {

        $user = $_SESSION['user'];

        $id = $_POST['id'];



        if ($this->db->delete('user', array('id' => $id))) {
            $msg = 'Hapus data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Hapus data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }
}
