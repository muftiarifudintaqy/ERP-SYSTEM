<?php

defined('BASEPATH') or exit('No direct script access allowed');
class Expense extends CI_Controller
{
    public function index()
    {

        if ($_GET['keyword_category']) {
            $keyword_category = $_GET['keyword_category'];
        } else {
            $keyword_category = "Nama Pelanggan";
        }
        $data['keyword_category'] = $keyword_category;
        $keyword = $_GET['keyword'];

        $data['title'] = 'Pengeluaran - ' . $this->template->title();
        if ($_GET['start_date']) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = DATE('Y-m-d');
            $start_date = DATE('Y-m-d', strtotime($start_date . " -31 days"));
        }
        if ($_GET['until_date']) {
            $until_date = $_GET['until_date'];
        } else {
            $until_date = DATE('Y-m-d');
        }

        $query = $this->mymodel->selectWithQuery("SELECT * FROM brand WHERE status = 'ENABLE' ORDER BY name ASC");

        $data['brands'] = $query;


        $keyword = $_GET['keyword'];
        $brand = $_GET['brand'];
        $marketplace = $_GET['marketplace'];
        $cs = $_GET['cs'];
        $product = $_GET['product'];
        $type = $_GET['type'];
        $type_sub = $_GET['type_sub'];

        $data['start_date'] = $start_date;
        $data['until_date'] = $until_date;
        $data['brand'] = $brand;
        $brand = $_GET['brand'];
        $category = $_GET['category'];



        $qry = "";

        $qry = "";
        $qry = " DATE(date) >= '$start_date'
        AND DATE(date) <= '$until_date'";

        $keyword = $_GET['keyword'];
        $keyword_category = $_GET['keyword_category'];

        if ($keyword) {
            if ($keyword_category == "Nama Pelanggan") {
                $qry .= " AND customer_text LIKE '%$keyword%' ";
            }
        }

        $limit = 30;

        $offset = intval($_GET['offset']);

        $query = $this->mymodel->selectWithQuery("SELECT COUNT(id) as count FROM expense
        WHERE $qry ");

        $data['page'] = CEIL($query[0]['count'] / 30);

        $data['notif'] = '<p class="mb-1"><label class="text-notif">' . $this->template->separator_only($query[0]['count']) . ' data ditemukan!</label></p>';


        $item = '';

        $current_page = intval($_GET['page']);
        if ($current_page <= 1) {
            $current_page = 1;
        }

        $url = base_url() . '/expense/' . $this->template->get_param();
        $data['url'] = $this->template->get_param_without_keyword_category($url);
        $data['param'] = $this->template->get_param();
        $data['param_pagination'] = $this->template->get_param_without('page');
        $data['pagination'] = $this->template->pagination($data['page'], $current_page, $data['param_pagination']);



        $data['start_date'] = $start_date;
        $data['until_date'] = $until_date;
        $data['brand'] = $brand;
        $data['content'] = $this->load->view('expense/all', $data, true);
        $this->load->view('TemplateDashboard', $data);
    }

    public function item()
    {
        $data['template'] = $this->template;
        if ($_GET['start_date']) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = DATE('Y-m-d');
            $start_date = DATE('Y-m-d', strtotime($start_date . " -31 days"));
        }
        if ($_GET['until_date']) {
            $until_date = $_GET['until_date'];
        } else {
            $until_date = DATE('Y-m-d');
        }

        $query = $this->mymodel->selectWithQuery("SELECT * FROM brand WHERE status = 'ENABLE' ORDER BY name ASC");

        $data['brands'] = $query;

        $keyword = $_GET['keyword'];
        $brand = $_GET['brand'];
        $marketplace = $_GET['marketplace'];
        $cs = $_GET['cs'];
        $product = $_GET['product'];
        $type = $_GET['type'];
        $type_sub = $_GET['type_sub'];
        $category = $_GET['category'];

        $data['start_date'] = $start_date;
        $data['until_date'] = $until_date;
        $data['brand'] = $brand;

        $qry = "";

        $qry = "";
        $qry = " DATE(date) >= '$start_date'
        AND DATE(date) <= '$until_date' ";

        $keyword = $_GET['keyword'];
        $keyword_category = $_GET['keyword_category'];

        if ($keyword) {
            if ($keyword_category == "Nama Pelanggan") {
                $qry .= " AND customer_text LIKE '%$keyword%' ";
            }
        }

        $limit = 30;

        $current_page = $_GET['page'];

        if ($current_page <= 1) {
            $offset = 0;
        } else {
            $offset = ($current_page - 1) * $limit;
        }

        $query = $this->mymodel->selectWithQuery("
        SELECT * FROM expense
        WHERE $qry 
        ORDER BY date DESC,id DESC
        LIMIT $offset, $limit
        ");




        $data['data'] = $query;

        $data['start'] = $offset;
        $this->load->view("expense/item", $data);
    }



    public function edit()
    {
        $id = $_GET['id'];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM expense WHERE id = '$id' AND type = 'Out' AND type_sub = 'Expense' ");

        $data['data'] = $query[0];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM brand WHERE status = 'ENABLE' ORDER BY name ASC");

        $data['brands'] = $query;


        $this->load->view("expense/edit", $data);
    }

    public function update()
    {

        $user = $_SESSION['user'];

        $id = $_POST['id'];
        $dt = $_POST['dt'];
        $dt['date'] = DATE("Y-m-d H:i:s", strtotime($dt['date']));
        $dt['updated_at'] = DATE("Y-m-d H:i:s");
        $dt['updated_by'] = $user['id'];

        if ($dt['category'] != 'Gift') {
            $dt['customer_text'] = '';
            $dt['customer'] = '';
        }

        $dt['price'] = 0 - doubleval($dt['price']);
        $dt['price_total'] = doubleval($dt['price']) * doubleval($dt['qty']);
        $dt['price_total_2'] = $dt['price_total'];
        $dt['net_price'] = $dt['price_total'];
        if ($_FILES['file']['name']) {
            $input = $this->validate([
                'file' => [
                    'uploaded[file]',
                    'mime_in[file,image/jpg,image/jpeg,image/png]',
                    'max_size[file,1024]',
                ]
            ]);

            if (!$input) {
                $msg = 'Pastikan tipe file .jpg, .jpeg atau .png!';
                echo $this->template->alert_danger($msg);
                die;
            } else {
                $img = $this->request->getFile('file');
                $dir = str_replace('public/', '', FCPATH . 'assets/img/transaction/');
                $img->move($dir);
                $data = [
                    'name' =>  $img->getName(),
                    'type'  => $img->getClientMimeType()
                ];
                $currentFileName = $dir . $data['name'];
                $newfile = $id . '.' . substr(strrchr($data['name'], "."), 1);
                $newFileName = $dir . $newfile;
                rename($currentFileName, $newFileName);
                $dt['img'] = $newfile;
            }
        }

        if ($this->db->update('expense', $dt, array('id' => $id))) {

            if ($dt['category'] == "Gift") {
                $id_customer = $_POST['id_customer'];
                $this->refresh_gift($id_customer);
            }

            $msg = 'Update data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Update data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }

    public function create()
    {


        $data['data'] = array();

        $query = $this->mymodel->selectWithQuery("SELECT * FROM brand WHERE status = 'ENABLE' ORDER BY name ASC");

        $data['brands'] = $query;

        $this->load->view("expense/create", $data);
    }


    public function store()
    {

        $user = $_SESSION['user'];

        $id = $_POST['id'];
        $dt = $_POST['dt'];
        $dt['date'] = DATE("Y-m-d H:i:s", strtotime($dt['date']));
        $dt['created_at'] = DATE("Y-m-d H:i:s");
        $dt['created_by'] = $user['id'];

        if ($dt['category'] != 'Gift') {
            $dt['customer_text'] = '';
            $dt['customer'] = '';
        }

        $dt['type'] = 'Out';
        $dt['type_sub'] = 'Expense';
        $dt['price'] = 0 - doubleval($dt['price']);
        $dt['price_total'] = doubleval($dt['price']) * doubleval($dt['qty']);
        $dt['price_total_2'] = $dt['price_total'];
        $dt['net_price'] = $dt['price_total'];
        if ($_FILES['file']['name']) {
            $input = $this->validate([
                'file' => [
                    'uploaded[file]',
                    'mime_in[file,image/jpg,image/jpeg,image/png]',
                    'max_size[file,1024]',
                ]
            ]);

            if (!$input) {
                $msg = 'Pastikan tipe file .jpg, .jpeg atau .png!';
                echo $this->template->alert_danger($msg);
                die;
            } else {
                $img = $this->request->getFile('file');
                $dir = str_replace('public/', '', FCPATH . 'assets/img/transaction/');
                $img->move($dir);
                $data = [
                    'name' =>  $img->getName(),
                    'type'  => $img->getClientMimeType()
                ];
                $currentFileName = $dir . $data['name'];
                $newfile = DATE('Ymdhis') . '.' . substr(strrchr($data['name'], "."), 1);
                $newFileName = $dir . $newfile;
                rename($currentFileName, $newFileName);
                $dt['img'] = $newfile;
            }
        }





        if ($this->db->insert('expense', $dt)) {
            $msg = 'Tambah data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Tambah data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }

    public function sync()
    {
        $id = $_GET['id'];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM expense WHERE id = '$id'");

        $data['data'] = $query[0];
        $this->load->view("expense/sync", $data);
    }

    public function sync_process()
    {

        $transaction = $this->template->get_session('expense');
        $id = $_POST['id'];


        $query = $this->mymodel->selectWithQuery("SELECT * FROM expense WHERE id = '$id'");

        $v = $query[0];
        $response = $this->template->get_social_media($v['type'], $v['url']);
        $dt = array();
        $dt['date'] = DATE("Y-m-d H:i:s", strtotime($dt['date']));
        $dt['updated_at'] = DATE("Y-m-d H:i:s");
        $dt['updated_by'] = $transaction['id'];
        if ($response['data']['like'] > 0) {
            $dt['like'] = $response['data']['like'];
            $dt['comment'] = $response['data']['comment'];
            $dt['collect'] = $response['data']['collect'];
            $dt['share'] = $response['data']['share'];
            $dt['view'] = $response['data']['view'];
            if ($v['cost'] > 0 && $dt['view'] > 0) {
                $dt['cpm'] = $v['cost'] / $dt['view'] * 1000;
            }
        }

        $this->db->update('expense', $dt, array('id' => $v['id']));

        if ($response['status'] == true) {
            $msg = 'Sync data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            if ($response) {
                $msg = $response['msg'];
            } else {
                $msg = 'Data transaction belum tersedia!';
            }
            echo $this->template->alert_danger($msg);
        }
    }

    public function remove()
    {
        $data['data']['id'] = $_GET['id'];
        $this->load->view("expense/delete", $data);
    }

    public function delete()
    {

        $id = $_POST['id'];

        $data = $this->mymodel->selectWithQuery("SELECT customer
        FROM expense WHERE id = '$id' ");
        $data = $data[0];


        if ($this->db->delete('expense', array('id' => $id))) {
            $id_customer = $data['customer'];
            $this->refresh_gift($id_customer);

            $msg = 'Hapus data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Hapus data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }
    function refresh_gift($id_customer)
    {
        $data = $this->mymodel->selectWithQuery("SELECT id, date, title,expense.desc,qty,price,price_total FROM expense
        WHERE customer = '$id_customer' AND category = 'Gift'
        ORDER BY date ASC");
        $dt = array();
        $dt['gift'] = json_encode($data, true);
        $this->db->update('customer', $dt, array('id' => $id_customer));
    }
}
