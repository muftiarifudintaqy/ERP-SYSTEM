<?php

defined('BASEPATH') or exit('No direct script access allowed');
class Product extends CI_Controller
{
    public function index()
    {

        $data['user'] = $_SESSION['user'];

        if ($_GET['keyword_category']) {
            $keyword_category = $_GET['keyword_category'];
        } else {
            $keyword_category = "Nama Produk";
        }
        $data['keyword_category'] = $keyword_category;
        $keyword = $_GET['keyword'];

        if ($_GET['start_date'] == "") {
            $start_date = DATE("Y-m-d");
        } else {
            $start_date = $_GET['start_date'];
        }
        if ($_GET['until_date'] == "") {
            $until_date = DATE("Y-m-d");
        } else {
            $until_date = $_GET['until_date'];
        }

        $data['start_date'] = $start_date;
        $data['until_date'] = $until_date;
        $data['brand'] = $brand;

        $data['title'] = 'Produk - ' . $this->template->title();


        $query = $this->mymodel->selectWithQuery("SELECT * FROM marketplace ORDER BY name ASC");

        $data['marketplace'] = $query;

        $query = $this->mymodel->selectWithQuery("SELECT * FROM brand WHERE status = 'ENABLE' ORDER BY name ASC");

        $data['brands'] = $query;


        $qry = "";
        $qry = " 1=1 ";

        if ($brand) {
            $qry .= " AND brand = '$brand' ";
        }

        if ($marketplace) {
            $qry .= " AND marketplace = '$marketplace' ";
        }

        if ($keyword) {
            if ($keyword_category == "Nama Produk") {
                $qry .= " AND name LIKE '%$keyword%' ";
            } else if ($keyword_category == "SKU") {
                $qry .= " AND sku LIKE '%$keyword%' ";
            } else if ($keyword_category == "Brand") {
                $qry .= " AND brand LIKE '%$keyword%' ";
            }
        }


        $query = $this->mymodel->selectWithQuery("SELECT COUNT(id) AS count
        FROM product
        WHERE $qry
        ");

        $data['page'] = CEIL($query[0]['count'] / 30);

        $data['notif'] = '<p class="mb-1"><label class="text-notif">' . $this->template->separator_only($query[0]['count']) . ' data ditemukan!</label></p>';

        $item = '';

        $current_page = intval($_GET['page']);
        if ($current_page <= 1) {
            $current_page = 1;
        }

        $url = base_url() . '/product/' . $this->template->get_param();
        $data['url'] = $this->template->get_param_without_keyword_category($url);
        $data['param'] = $this->template->get_param();
        $data['param_pagination'] = $this->template->get_param_without('page');
        $data['pagination'] = $this->template->pagination($data['page'], $current_page, $data['param_pagination']);

        $data['content'] = $this->load->view("product/all", $data, true);
        $this->load->view("TemplateDashboard", $data);
    }

    public function item_stock()
    {


        $data['template'] = $this->template;

        $id = $_GET['id'];

        $qry = "";
        $qry = " product = '$id' ";

        $limit = 30;

        $current_page = $_GET['page'];

        if ($current_page <= 1) {
            $offset = 0;
        } else {
            $offset = ($current_page - 1) * $limit;
        }

        $query = $this->mymodel->selectWithQuery("
        SELECT * FROM stock
        WHERE $qry 
        ORDER BY date ASC, id ASC
        LIMIT $offset, $limit
        ");

        $data['data'] = $query;
        $data['balance'] = 0;
        if ($current_page > 1) {
            $query = $this->mymodel->selectWithQuery("SELECT sum(qty) as sum
            FROM (
                SELECT qty
                FROM stock
                WHERE product = '$id'
                ORDER BY date ASC, id ASC
                LIMIT 0, $offset
            ) AS subquery");

            $data['balance'] = $query[0]['sum'];
        }

        $data['start'] = $offset;
        $this->load->view("product/item_stock", $data);
    }


    public function item()
    {

        $data['user'] = $_SESSION['user'];

        $data['template'] = $this->template;

        if ($_GET['keyword_category']) {
            $keyword_category = $_GET['keyword_category'];
        } else {
            $keyword_category = "Nama Produk";
        }
        $data['keyword_category'] = $keyword_category;
        $keyword = $_GET['keyword'];

        if ($_GET['start_date']) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = DATE('Y-m-d');
        }
        if ($_GET['until_date']) {
            $until_date = $_GET['until_date'];
        } else {
            $until_date = DATE('Y-m-d');
        }
        $qry = "";
        $qry = " 1=1 ";

        if ($brand) {
            $qry .= " AND brand = '$brand' ";
        }

        if ($marketplace) {
            $qry .= " AND marketplace = '$marketplace' ";
        }

        if ($keyword) {
            if ($keyword_category == "Nama Produk") {
                $qry .= " AND name LIKE '%$keyword%' ";
            } else if ($keyword_category == "SKU") {
                $qry .= " AND sku LIKE '%$keyword%' ";
            } else if ($keyword_category == "Brand") {
                $qry .= " AND brand LIKE '%$keyword%' ";
            }
        }

        $limit = 30;

        $current_page = $_GET['page'];

        if ($current_page <= 1) {
            $offset = 0;
        } else {
            $offset = ($current_page - 1) * $limit;
        }

        $query = $this->mymodel->selectWithQuery("SELECT * FROM product
        WHERE $qry 
        ORDER BY name ASC
        LIMIT $offset, $limit
        ");


        $data['data'] = $query;

        $data['start'] = $offset;
        $this->load->view("product/item", $data);
    }


    public function stock()
    {


        $data['template'] = $this->template;

        $data['title'] = 'Stok Produk - ' . $this->template->title();

        $id = $_GET['id'];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM product WHERE id = '$id'");

        $data['data'] = $query[0];

        if (empty($data['data'])) {
            return redirect()->to(site_url('stock'));
        }

        $qry = "";
        $qry = " product = '$id' ";


        $limit = 30;

        $offset = intval($_GET['offset']);

        $query = $this->mymodel->selectWithQuery("SELECT COUNT(id) as count FROM stock
        WHERE $qry ");

        $data['page'] = CEIL($query[0]['count'] / 30);

        $data['notif'] = '<p class="mb-1"><label class="text-notif">' . $this->template->separator_only($query[0]['count']) . ' data ditemukan!</label></p>';

        $item = '';

        $current_page = intval($_GET['page']);
        if ($current_page <= 1) {
            $current_page = 1;
        }

        $url = base_url() . '/product/stock?id=' . $_GET['id'];

        $data['pagination'] = $this->template->pagination($data['page'], $current_page, $url);

        $data['content'] = $this->load->view("product/stock", $data);
        $this->load->view("TemplateDashboard", $data);
    }

    public function edit()
    {
        $id = $_GET['id'];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM product WHERE id = '$id'");

        $data['data'] = $query[0];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM brand ORDER BY name ASC");

        $data['brand'] = $query;
        $this->load->view("product/edit", $data);
    }

    public function update()
    {

        $user = $_SESSION['user'];

        $id = $_POST['id'];
        $dt = $_POST['dt'];
        $dt['updated_at'] = DATE("Y-m-d H:i:s");
        $dt['updated_by'] = $user['id'];

        // $brand = $dt['brand'];
        //
        // $query = $this->mymodel->selectWithQuery("SELECT * FROM brand WHERE id = '$brand'");
        // 
        // $dt['brand_text'] = strval($query[0]['name']);

        if (!empty($_FILES['file']['name'])) {
            $dir  = "./assets/img/product/";
            $config['upload_path']   = $dir;
            $config['allowed_types'] = 'jpg|jpeg|png';
            $config['overwrite']     = TRUE;
            $config['file_name']     = $id;
            $config['max_size']      = 2048;
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('file')) {
                $error = $this->upload->display_errors();
                echo $this->template->alert_danger($error);
                die;
            } else {
                $file = $this->upload->data();
                $dt['img'] = $file['file_name'];
            }
        }

        if ($this->db->update('product', $dt, array('id' => $id))) {
            $this->update_stock($id);
            $msg = 'Update data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Update data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }

    public function update_stock($id_product)
    {

        $dtp = array();
        $id_product = $id_product;
        $query = $this->mymodel->selectWithQuery("SELECT SUM(qty_in) as qty_in,SUM(qty_out) as qty_out,SUM(qty) as qty FROM stock WHERE product = '$id_product'");

        $dtp['stock_in'] = strval($query[0]['qty_in']);
        $dtp['stock_out'] = strval(abs($query[0]['qty_out']) * -1);
        $dtp['stock'] = strval(doubleval($query[0]['qty']));
        $this->db->update('product', $dtp, array('id' => $id_product));
    }

    public function create()
    {
        $data['data'] = array();

        $query = $this->mymodel->selectWithQuery("SELECT * FROM brand ORDER BY name aSC");

        $data['brand'] = $query;

        $this->load->view("product/create", $data);
    }


    public function store()
    {

        $user = $_SESSION['user'];

        $id = $_POST['id'];
        $dt = $_POST['dt'];
        $dt['created_at'] = DATE("Y-m-d H:i:s");
        $dt['created_by'] = $user['id'];

        // $brand = $dt['brand'];
        //
        // $query = $this->mymodel->selectWithQuery("SELECT * FROM brand WHERE id = '$brand'");
        // 
        // $dt['brand_text'] = strval($query[0]['name']);

        if (!empty($_FILES['file']['name'])) {
            $dir  = "./assets/img/product/";
            $config['upload_path']   = $dir;
            $config['allowed_types'] = 'jpg|jpeg|png';
            $config['overwrite']     = TRUE;
            $config['file_name']     = DATE("Ymdhis");
            $config['max_size']      = 2048;
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('file')) {
                $error = $this->upload->display_errors();
                echo $this->template->alert_danger($error);
                die;
            } else {
                $file = $this->upload->data();
                $dt['img'] = $file['file_name'];
            }
        }


        if ($this->db->insert('product', $dt)) {
            $msg = 'Tambah data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Tambah data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }

    public function sync()
    {
        $id = $_GET['id'];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM product WHERE id = '$id'");

        $data['data'] = $query[0];
        $this->load->view("product/sync", $data);
    }

    public function sync_process()
    {

        $product = $this->template->get_session('product');
        $id = $_POST['id'];


        $query = $this->mymodel->selectWithQuery("SELECT * FROM product WHERE id = '$id'");

        $v = $query[0];
        $response = $this->template->get_social_media($v['type'], $v['url']);
        $dt = array();
        $dt['updated_at'] = DATE("Y-m-d H:i:s");
        $dt['updated_by'] = $product['id'];
        if ($response['data']['like'] > 0) {
            $dt['like'] = $response['data']['like'];
            $dt['comment'] = $response['data']['comment'];
            $dt['collect'] = $response['data']['collect'];
            $dt['share'] = $response['data']['share'];
            $dt['view'] = $response['data']['view'];
            if ($v['cost'] > 0 && $dt['view'] > 0) {
                $dt['cpm'] = $v['cost'] / $dt['view'] * 1000;
            }
        }

        $model = $db->table('product');
        $model->where('id', $v['id']);
        $model->update($dt);

        if ($response['status'] == true) {
            $msg = 'Sync data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            if ($response) {
                $msg = $response['msg'];
            } else {
                $msg = 'Data product belum tersedia!';
            }
            echo $this->template->alert_danger($msg);
        }
    }

    public function remove()
    {
        $id = $_GET['id'];
        $data['data']['id'] = $id;
        $this->load->view("product/delete", $data);
    }

    public function delete()
    {


        $id = $_POST['id'];


        if ($this->db->delete('product', array('id' => $id))) {
            $msg = 'Hapus data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Hapus data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }
}
