<?php

defined('BASEPATH') or exit('No direct script access allowed');
class Dashboard extends CI_Controller
{
    public function index()
    {
        $data['checkbox'] = $_SESSION['checkbox_dashboard'];
        $data['checkbox_campaign'] = $_SESSION['checkbox_dashboard_campaign'];
        // print_r($data['checkbox_campaign']);
        $data['title'] = 'Dashboard - ' . $this->template->title();

        $user = $_SESSION['user'];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM brand WHERE status = 'ENABLE' ORDER BY name ASC");
        $data['brands'] = $query;

        $data['channel_2'] = $this->mymodel->selectWithQuery("SELECT *
        FROM marketplace
        ORDER BY name ASC");

        $data['channel'] = $this->mymodel->selectWithQuery("SELECT *
        FROM marketplace
        WHERE name IN ('SHOPEE','LAZADA','TIKTOK','WA')
        ORDER BY name ASC");


        if ($_GET['start_date']) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = DATE("Y-m-d");
            $start_date = DATE('Y-m-d', strtotime($today . " -31 days"));
        }
        if ($_GET['until_date']) {
            $until_date = $_GET['until_date'];
        } else {
            $until_date = DATE('Y-m-d');
        }
        $data['title_2'] = $this->template->date_format_indo($start_date) . ' - ' . $this->template->date_format_indo($until_date);

        $url = base_url() . '/dashboard/' . $this->template->get_param();
        $data['url'] = $this->template->get_param_without_keyword_category($url);
        $data['param'] = $this->template->get_param();

        if ($_GET['t'] == "kol") {
            $data['content'] = $this->load->view('dashboard/all-kol', $data, true);
        } else  if ($_GET['t'] == "influencer") {
            $data['campaign'] = $this->mymodel->selectWithQuery("
           SELECT *
           FROM endorse_campaign
           ORDER BY title ASC");
            $data['content'] = $this->load->view('dashboard/all-influencer', $data, true);
        } else {
            $data['content'] = $this->load->view('dashboard/all', $data, true);
        }
        $this->load->view('TemplateDashboard', $data);
    }
}
