<?php

defined('BASEPATH') or exit('No direct script access allowed');
class Endorse_campaign extends CI_Controller
{
    public function index()
    {

        if (empty($_GET)) {
            for ($i = 0; $i <= 0; $i++) {
                $dt[$i] = 'false';
            }
            for ($i = 1; $i <= 6; $i++) {
                $dt[$i] = 'false';
            }
            $dt[1] = 'true';
            $_SESSION['checkbox'] = $dt;
        }

        if ($_GET['keyword_category']) {
            $keyword_category = $_GET['keyword_category'];
        } else {
            $keyword_category = "Judul Campaign";
        }

        $data['keyword_category'] = $keyword_category;
        $keyword = $_GET['keyword'];

        if ($_GET['start_date']) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = DATE("Y-m-d");
            $start_date = DATE('Y-m-d', strtotime($today . " -1 years"));
        }
        if ($_GET['until_date']) {
            $until_date = $_GET['until_date'];
        } else {
            $until_date = DATE('Y-m-d');
        }

        $data['start_date'] = $start_date;
        $data['until_date'] = $until_date;
        $data['brand'] = $brand;

        $data['title'] = 'Endorse Campaign - ' . $this->template->title();


        $query = $this->mymodel->selectWithQuery("SELECT * FROM marketplace ORDER BY name ASC");

        $data['marketplace'] = $query;

        $query = $this->mymodel->selectWithQuery("SELECT * FROM brand WHERE status = 'ENABLE' ORDER BY name ASC");

        $data['brands'] = $query;


        $qry = "";

        $qry = " DATE(start_at) >= '$start_date'
        AND DATE(start_at) <= '$until_date' ";

        if ($brand) {
            $qry .= " AND brand = '$brand' ";
        }

        if ($marketplace) {
            $qry .= " AND marketplace = '$marketplace' ";
        }

        if ($keyword) {
            if ($keyword_category == "Judul Campaign") {
                $qry .= " AND title LIKE '%$keyword%' ";
            } else if ($keyword_category == "SKU") {
                $qry .= " AND sku LIKE '%$keyword%' ";
            } else if ($keyword_category == "Brand") {
                $qry .= " AND brand LIKE '%$keyword%' ";
            } else if ($keyword_category == "Keterangan") {
                $qry .= " AND endorse_campaign.desc LIKE '%$keyword%' ";
            } else if ($keyword_category == "Status") {
                $qry .= " AND status = '$keyword' ";
            }
        }


        $query = $this->mymodel->selectWithQuery("SELECT COUNT(id) AS count
        FROM endorse_campaign
        WHERE $qry
        ");

        $data['page'] = CEIL($query[0]['count'] / 30);

        $data['notif'] = '<p class="mb-1"><label class="text-notif">' . $this->template->separator_only($query[0]['count']) . ' data ditemukan!</label></p>';

        $item = '';

        $current_page = intval($_GET['page']);
        if ($current_page <= 1) {
            $current_page = 1;
        }

        $url = base_url() . '/endorse_campaign/' . $this->template->get_param();
        $data['url'] = $this->template->get_param_without_keyword_category($url);
        $data['param'] = $this->template->get_param();
        $data['param_pagination'] = $this->template->get_param_without('page');
        $data['pagination'] = $this->template->pagination($data['page'], $current_page, $data['param_pagination']);

        $data['content'] = $this->load->view('endorse_campaign/all', $data, true);
        $this->load->view('TemplateDashboard', $data);
    }

    public function item()
    {


        if ($_GET['keyword_category']) {
            $keyword_category = $_GET['keyword_category'];
        } else {
            $keyword_category = "Judul Campaign";
        }
        $data['keyword_category'] = $keyword_category;
        $keyword = $_GET['keyword'];

        if ($_GET['start_date']) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = DATE("Y-m-d");
            $start_date = DATE('Y-m-d', strtotime($today . " -1 years"));
        }
        if ($_GET['until_date']) {
            $until_date = $_GET['until_date'];
        } else {
            $until_date = DATE('Y-m-d');
        }
        $qry = "";

        $qry = " DATE(start_at) >= '$start_date'
        AND DATE(start_at) <= '$until_date' ";

        if ($brand) {
            $qry .= " AND brand = '$brand' ";
        }

        if ($marketplace) {
            $qry .= " AND marketplace = '$marketplace' ";
        }

        if ($keyword) {
            if ($keyword_category == "Judul Campaign") {
                $qry .= " AND title LIKE '%$keyword%' ";
            } else if ($keyword_category == "SKU") {
                $qry .= " AND sku LIKE '%$keyword%' ";
            } else if ($keyword_category == "Brand") {
                $qry .= " AND brand LIKE '%$keyword%' ";
            } else if ($keyword_category == "Keterangan") {
                $qry .= " AND endorse_campaign.desc LIKE '%$keyword%' ";
            } else if ($keyword_category == "Status") {
                $qry .= " AND status = '$keyword' ";
            }
        }



        $limit = 30;

        $current_page = $_GET['page'];

        if ($current_page <= 1) {
            $offset = 0;
        } else {
            $offset = ($current_page - 1) * $limit;
        }

        $query = $this->mymodel->selectWithQuery("SELECT * FROM endorse_campaign
        WHERE $qry 
        ORDER BY start_at DESC
        LIMIT $offset, $limit
        ");


        $data['data'] = $query;

        $data['start'] = $offset;
        $this->load->view("endorse_campaign/item", $data);
    }


    public function edit()
    {
        $id = $_GET['id'];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM endorse_campaign WHERE id = '$id'");

        $data['data'] = $query[0];

        $data['pic'] = $this->mymodel->selectWithQuery("SELECT * FROM user ORDER BY full_name ASC");
        $data['brand'] = $this->mymodel->selectWithQuery("SELECT * FROM brand ORDER BY code ASC");

        $query = $this->mymodel->selectWithQuery("SELECT * FROM brand ORDER BY name ASC");

        $data['brand'] = $query;
        $this->load->view("endorse_campaign/edit", $data);
    }

    function update_endorse_parent($id_parent)
    {
        $id_campaign = $id_parent;
        $user = $_SESSION['user'];

        $v['id'] = $id_parent;
        $today = DATE("Y-m-d");
        $yesterday = DATE('Y-m-d', strtotime($today . " -1 days"));
        $query = $this->mymodel->selectWithQuery("SELECT id
        FROM endorse_campaign_logs
        WHERE id_campaign = '$id_parent' AND date = '$today' ");
        $query = $query[0];

        $query_yesterday = $this->mymodel->selectWithQuery("SELECT *
        FROM endorse_campaign_logs
        WHERE id_campaign = '$id_parent' AND date < '$today' ORDER BY date DESC LIMIT 1 ");
        $query_yesterday = $query_yesterday[0];

        $item_detail = $this->mymodel->selectWithQuery("SELECT SUM(total_cost) as total_cost, COUNT(id) as count_endorse,
        SUM(likes) as likes, SUM(comment) as comment, SUM(share_save) as share_save, SUM(views) as views, AVG(cpm) as cpm
        FROM endorse
        WHERE id_campaign = '$id_parent'  AND link_upload != ''
        AND status = 'Aktif' ");
        $item_detail = $item_detail[0];

        $item = $this->mymodel->selectWithQuery("SELECT SUM(likes) as likes, SUM(comment) as comment, SUM(share_save) as share_save, SUM(views) as views, AVG(cpm) as cpm,
        SUM(likes_after) as likes_after, SUM(comment_after) as comment_after, SUM(share_save_after) as share_save_after, SUM(views_after) as views_after, AVG(cpm_after) as cpm_after,
        SUM(likes_before) as likes_before, SUM(comment_before) as comment_before, SUM(share_save_before) as share_save_before, SUM(views_before) as views_before, AVG(cpm_before) as cpm_before
        FROM endorse_logs
        WHERE id_campaign = '$id_parent';");
        $dt = array();
        $dt['id_campaign'] = $v['id'];
        $dt['total_cost'] = doubleval($item_detail['total_cost']);
        $dt['date'] = $today;
        foreach ($item[0] as $k2 => $v2) {
            $dt[$k2] = doubleval($v2);
        }


        $dtt = array();
        foreach ($item_detail as $k3 => $v3) {
            $dtt[$k3] = doubleval($v3);
        }

        $id_parent = $v['id'];

        $summary = $this->mymodel->selectWithQuery("SELECT COUNT(id) as count
        FROM endorse WHERE id_campaign = '$id_parent'  ");
        $summary = $summary[0];
        $dtt['count_endorse'] = intval($summary['count']);
        $dt['ce_now'] = $dtt['count_endorse'];

        $summary = $this->mymodel->selectWithQuery("SELECT COUNT(id) as count
        FROM endorse WHERE id_campaign = '$id_parent' AND status = 'Aktif'  ");
        $summary = $summary[0];
        $dtt['count_endorse_active'] = intval($summary['count']);
        $dt['ce_active_now'] = $dtt['count_endorse_active'];

        $summary = $this->mymodel->selectWithQuery("SELECT COUNT(id) as count
        FROM endorse WHERE id_campaign = '$id_parent' AND status = 'Aktif' 
        AND link_upload != '' ");
        $summary = $summary[0];
        $dtt['count_endorse_processed'] = intval($summary['count']);
        $dt['ce_processed_now'] = $dtt['count_endorse_processed'];


        $summary = $this->mymodel->selectWithQuery("SELECT COUNT(DISTINCT influencer) as count
        FROM endorse WHERE id_campaign = '$id_parent'  ");
        $summary = $summary[0];
        $dtt['count_influencer'] = intval($summary['count']);
        $dt['ci_now'] = $dtt['count_influencer'];

        $summary = $this->mymodel->selectWithQuery("SELECT COUNT(DISTINCT influencer) as count
        FROM endorse WHERE id_campaign = '$id_parent' AND status = 'Aktif'  ");
        $summary = $summary[0];
        $dtt['count_influencer_active'] = intval($summary['count']);
        $dt['ci_active_now'] = $dtt['count_influencer_active'];

        $summary = $this->mymodel->selectWithQuery("SELECT COUNT(DISTINCT influencer) as count
        FROM endorse WHERE id_campaign = '$id_parent' AND status = 'Aktif'  
        AND link_upload != '' ");
        $summary = $summary[0];
        $dtt['count_influencer_processed'] = intval($summary['count']);
        $dt['ci_processed_now'] = $dtt['count_influencer_processed'];

        // print_r($query_yesterday);die;
        $dt['ci_before'] =  $query_yesterday['ci_now'];
        $dt['ci_active_before'] = $query_yesterday['ci_active_now'];
        $dt['ci_processed_before'] = $query_yesterday['ci_processed_now'];

        $dt['ce_before'] =  $query_yesterday['ce_now'];
        $dt['ce_active_before'] = $query_yesterday['ce_active_now'];
        $dt['ce_processed_before'] = $query_yesterday['ce_processed_now'];

        $dt['ci_before'] =  $query_yesterday['ci_now'];
        $dt['ci_active_before'] = $query_yesterday['ci_active_now'];
        $dt['ci_processed_before'] = $query_yesterday['ci_processed_now'];
        $dt['ce_before'] =  $query_yesterday['ce_now'];
        $dt['ce_active_before'] = $query_yesterday['ce_active_now'];
        $dt['ce_processed_before'] = $query_yesterday['ce_processed_now'];

        $dt['ci_after'] =  $dt['ci_now'];
        $dt['ci_active_after'] = $dt['ci_active_now'];
        $dt['ci_processed_after'] = $dt['ci_processed_now'];
        $dt['ce_after'] =  $dt['ce_now'];
        $dt['ce_active_after'] = $dt['ce_active_now'];
        $dt['ce_processed_after'] = $dt['ce_processed_now'];

        $dt['ci_now'] =  $dt['ci_after'] - $dt['now_before'];
        $dt['ci_active_now'] = $dt['ci_active_after'] - $dt['ci_active_before'];
        $dt['ci_processed_now'] = $dt['ci_processed_after'] - $dt['ci_processed_before'];
        $dt['ce_now'] =  $dt['ce_after'] - $dt['ce_before'];
        $dt['ce_active_now'] = $dt['ce_active_after'] - $dt['ce_active_before'];
        $dt['ce_processed_now'] = $dt['ce_processed_after'] - $dt['ce_processed_before'];

        // $dt['is_cron'] = '1';
        $dt_tmp = array();
        foreach ($dt as $kt => $vt) {
            $dt_tmp[$kt] = strval($vt);
        }
        $dt = $dt_tmp;

        if ($query) {
            $dt['updated_at'] = DATE("Y-m-d H:i:s");
            $dt['updated_by'] = strval($user['id']);
            $this->db->update('endorse_campaign_logs', $dt, array('id' => $query['id']));
            // $id_parent = $query['id'];
        } else {
            $dt['created_at'] = DATE("Y-m-d H:i:s");
            $dt['created_by'] = strval($user['id']);
            $this->db->insert('endorse_campaign_logs', $dt);
            // $id_parent = $this->db->insertID();
        }

        $dt_tmp = array();
        foreach ($dtt as $kt => $vt) {
            $dt_tmp[$kt] = strval($vt);
        }
        $dtt = $dt_tmp;

        $dtt['updated_at'] = DATE("Y-m-d H:i:s");
        $dtt['updated_by'] = strval($user['id']);

        $cpm = 0;
        $list = $this->mymodel->selectWithQuery("SELECT SUM(total_cost) as total_cost, SUM(views) as views,SUM(likes) as likes, SUM(share_save) as share_save, SUM(comment) as comment FROM endorse WHERE id_campaign = '$id_campaign'");
        $list = $list[0];
        if ($list['total_cost'] > 0 && $list['views'] > 0) {
            $cpm =  $list['total_cost'] / $list['views'] * 1000;
        }
        $dtt['cpm'] = doubleval($cpm);
        $dtt['views'] = doubleval($list['views']);
        $dtt['comment'] = doubleval($list['comment']);
        $dtt['likes'] = doubleval($list['likes']);
        $dtt['share_save'] = doubleval($list['share_save']);

        $ids = '';
        $list_id = $this->mymodel->selectWithQuery("SELECT id FROM endorse
        WHERE id_campaign = '$id_campaign'
        AND link_upload != ''
        ");
        foreach ($list_id as $k => $v) {
            $ids .= $v['id'] . ',';
        }
        $ids = substr($ids, 0, -1);
        if ($ids) {
            $list = $this->mymodel->selectWithQuery("SELECT SUM(likes) as likes, SUM(comment) as comment,SUM(share_save) as share_save, SUM(views) as views
            FROM endorse_logs
            WHERE id_endorse IN ($ids)
            GROUP BY id_endorse
            ORDER BY id DESC");
            $list = $list[0];
            // print_r($list);
            // die;
            if ($list['total_cost'] > 0 && $list['views'] > 0) {
                $cpm =  $list['total_cost'] / $list['views'] * 1000;
            }
            $dtt['cpm'] = doubleval($cpm);
            $dtt['views'] = doubleval($list['views']);
            $dtt['comment'] = doubleval($list['comment']);
            $dtt['likes'] = doubleval($list['likes']);
            $dtt['share_save'] = doubleval($list['share_save']);
        }


        $this->db->update('endorse_campaign', $dtt, array('id' => $v['id']));
    }

    public function update()
    {

        $user = $_SESSION['user'];

        $id = $_POST['id'];
        $dt = $_POST['dt'];
        $dt['updated_at'] = DATE("Y-m-d H:i:s");
        $dt['updated_by'] = $user['id'];

        // $brand = $dt['brand'];
        // 
        // $query = $this->mymodel->selectWithQuery("SELECT * FROM brand WHERE id = '$brand'");
        // 
        // $dt['brand_text'] = strval($query[0]['name']);

        if ($_FILES['file']['name']) {
            $input = $this->validate([
                'file' => [
                    'uploaded[file]',
                    'mime_in[file,image/jpg,image/jpeg,image/png]',
                    'max_size[file,1024]',
                ]
            ]);

            if (!$input) {
                $msg = 'Pastikan tipe file .jpg, .jpeg atau .png!';
                echo $this->template->alert_danger($msg);
                die;
            } else {
                $img = $this->request->getFile('file');
                $dir = str_replace('public/', '', FCPATH . 'assets/img/endorse_campaign/');
                $img->move($dir);
                $data = [
                    'name' =>  $img->getName(),
                    'type'  => $img->getClientMimeType()
                ];
                $currentFileName = $dir . $data['name'];
                $newfile = $id . '.' . substr(strrchr($data['name'], "."), 1);
                $newFileName = $dir . $newfile;
                rename($currentFileName, $newFileName);
                $dt['img'] = $newfile;
            }
        }

        $dt_2['status_campaign'] = $dt['status'];
        $this->db->update('endorse', $dt_2, array('id_campaign' => $id));

        if ($this->db->update('endorse_campaign', $dt, array('id' => $id))) {
            $id_campaign = $_POST['id_campaign'];
            $id_parent = $id_campaign;
            $this->update_endorse_parent($id_parent);

            if ($dt['brand'] != $_POST['brand']) {
                $dtt = array();
                $dtt['brand'] = $dt['brand'];
                $this->db->update('endorse', $dtt, array('id_campaign' => $id_campaign));
                $this->db->update('endorse_logs', $dtt, array('id_campaign' => $id_campaign));
                $this->db->update('endorse_campaign_logs', $dtt, array('id_campaign' => $id_campaign));
            }
            $msg = 'Update data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Update data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }



    public function create()
    {
        $data['data'] = array();

        $data['pic'] = $this->mymodel->selectWithQuery("SELECT * FROM user ORDER BY full_name ASC");
        $data['brand'] = $this->mymodel->selectWithQuery("SELECT * FROM brand ORDER BY code ASC");


        $this->load->view("endorse_campaign/create", $data);
    }


    public function store()
    {

        $user = $_SESSION['user'];

        $id = $_POST['id'];
        $dt = $_POST['dt'];
        $dt['created_at'] = DATE("Y-m-d H:i:s");
        $dt['created_by'] = $user['id'];

        // $brand = $dt['brand'];
        // 
        // $query = $this->mymodel->selectWithQuery("SELECT * FROM brand WHERE id = '$brand'");
        // 
        // $dt['brand_text'] = strval($query[0]['name']);

        if ($_FILES['file']['name']) {
            $input = $this->validate([
                'file' => [
                    'uploaded[file]',
                    'mime_in[file,image/jpg,image/jpeg,image/png]',
                    'max_size[file,1024]',
                ]
            ]);

            if (!$input) {
                $msg = 'Pastikan tipe file .jpg, .jpeg atau .png!';
                echo $this->template->alert_danger($msg);
                die;
            } else {
                $img = $this->request->getFile('file');
                $dir = str_replace('public/', '', FCPATH . 'assets/img/endorse_campaign/');
                $img->move($dir);
                $data = [
                    'name' =>  $img->getName(),
                    'type'  => $img->getClientMimeType()
                ];
                $currentFileName = $dir . $data['name'];
                $newfile = DATE('Ymdhis') . '.' . substr(strrchr($data['name'], "."), 1);
                $newFileName = $dir . $newfile;
                rename($currentFileName, $newFileName);
                $dt['img'] = $newfile;
            }
        }

        if ($this->db->insert('endorse_campaign', $dt)) {
            $msg = 'Tambah data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Tambah data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }
    public function remove()
    {
        $id = $_GET['id'];
        $data['data']['id'] = $id;
        $this->load->view("endorse_campaign/delete", $data);
    }

    public function delete()
    {


        $id = $_POST['id'];


        if ($this->db->delete('endorse_campaign', array('id' => $id))) {
            $msg = 'Hapus data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Hapus data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }
}
