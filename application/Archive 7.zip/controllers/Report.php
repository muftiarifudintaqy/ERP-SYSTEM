<?php

defined('BASEPATH') or exit('No direct script access allowed');
class Report extends CI_Controller
{
    public function index()
    {

        $data['title'] = 'Report - ' . $this->template->title();

        $user = $_SESSION['user'];


        $query = $this->mymodel->selectWithQuery("SELECT * FROM brand WHERE status = 'ENABLE' ORDER BY name ASC");
        $data['brands'] = $query;

        $data['channel_2'] = $this->mymodel->selectWithQuery("SELECT *
        FROM marketplace
        ORDER BY name ASC");

        $data['channel'] = $this->mymodel->selectWithQuery("SELECT *
        FROM marketplace
        WHERE name IN ('SHOPEE','LAZADA','TIKTOK')
        ORDER BY name ASC");

        $url = base_url() . 'dashboard/' . $this->template->get_param();
        $data['url'] = $this->template->get_param_without_keyword_category($url);
        $data['param'] = $this->template->get_param();

        $data['content'] = $this->load->view('dashboard/report', $data, true);
        $this->load->view('TemplateDashboard', $data);
    }
}
