<?php

defined('BASEPATH') or exit('No direct script access allowed');
class Endorse extends CI_Controller
{

    public function stats()
    {

        $id_campaign = $_GET['id_campaign'];
        $id_influencer = $_GET['id_influencer'];

        $data['template'] = $this->template;

        $data['title'] = 'Campaign Detail - ' . $this->template->title();

        $data['checkbox'] = $_SESSION['checkbox'];
        $id_campaign = $_GET['id_campaign'];
        $data['detail'] = $this->mymodel->selectWithQuery("SELECT *
        FROM endorse_campaign WHERE id = '$id_campaign'");
        $data['detail'] = $data['detail'][0];

        $id_campaign = $_GET['id_campaign'];

        $add_param = "";
        if ($id_influencer) {

            $qry = "";
            if ($id_campaign) {
                $qry .= " AND id_campaign = '$id_campaign' ";
            }

            $query = $this->mymodel->selectWithQuery("SELECT COUNT(id) AS count
            FROM endorse
            WHERE influencer = '$id_influencer' $qry 
            ");
        } else if ($id_campaign) {

            $qry = "";

            $type = $_GET['type'];
            $start_date = $_GET['start_date'];
            $until_date = $_GET['until_date'];
            $start_year = $_GET['start_year'];
            $until_year = $_GET['until_year'];
            $start_month = $_GET['start_month'];
            $until_month = $_GET['until_month'];
            $start_week = $_GET['start_week'];
            $until_week = $_GET['until_week'];
            $site = $_GET['site'];
            $customer = $_GET['customer'];
            $mpu = $_GET['mpu'];

            if ($type == "Yearly") {
                $qry_opt = " YEAR(date) ";
                $start_date = $start_year . '-01-01';
                $until_date = $until_year . '-12-31';
                $group = "  GROUP BY YEAR(date) ";
            } else if ($type == "Monthly") {
                $qry_opt = " MONTH(date) ";
                $start_month = str_pad($start_month, 2, "0", STR_PAD_LEFT);
                $until_month = str_pad($until_month, 2, "0", STR_PAD_LEFT);
                $start_date = $start_year . '-' . $start_month . '-01';
                $until_date = $start_year . '-' . $until_month . '-31';
                $group = "  GROUP BY MONTH(date) ";
            } else if ($type == "Weekly") {
                $qry_opt = " WEEK(date) ";
                $start_week = str_pad($start_week, 2, "0", STR_PAD_LEFT);
                $until_week = str_pad($until_week, 2, "0", STR_PAD_LEFT);

                $year = $start_year;
                $week = $start_week;
                $start_date = date("Y-m-d", strtotime($year . "W" . $week . "1"));

                $year = $start_year;
                $week = $until_week;
                $until_date = date("Y-m-d", strtotime($year . "W" . $week . "7"));
                $group = "  GROUP BY WEEK(date) ";
            } else {
                $qry_opt = " DATE(date) ";
                $group = "  GROUP BY DATE(date) ";
            }



            if ($_GET['keyword_category']) {
                $keyword_category = $_GET['keyword_category'];
            } else {
                $keyword_category = "Nama Creator";
            }
            $data['keyword_category'] = $keyword_category;
            $keyword = $_GET['keyword'];

            if ($_GET['start_date']) {
                $start_date = $_GET['start_date'];
            } else {
                $start_date = DATE("Y-m-d");
                $start_date = DATE('Y-m-d', strtotime($today . " -31 days"));
            }
            if ($_GET['until_date']) {
                $until_date = $_GET['until_date'];
            } else {
                $until_date = DATE('Y-m-d');
            }
            $data['start_date'] = $start_date;
            $data['until_date'] = $until_date;
            $qry = "";

            $ids = $_GET['ids'];
            $data['ids'] = $ids;
            if ($ids) {
                $qry .= " AND id  IN ($ids) ";
            }

            if ($brand) {
                $qry .= " AND brand = '$brand' ";
            }

            $cat = $_GET['cat'];
            if ($cat == "Tanggal Dibuat") {
                $qry .= " AND DATE(created_at) >= '$start_date' AND DATE(created_at) <= '$until_date' ";
            } else if ($cat == "Rencana Upload") {
                $qry .= " AND DATE(rencana_at) >= '$start_date' AND DATE(rencana_at) <= '$until_date' ";
            } else if ($cat == "Tanggal Posting") {
                $qry .= " AND DATE(posting_at) >= '$start_date' AND DATE(posting_at) <= '$until_date' ";
            } else {
                // $qry .= " AND DATE(created_at) >= '$start_date' AND DATE(created_at) <= '$until_date' ";
            }

            $status = $_GET['status'];
            if ($status) {
                if ($status == 'Ada Link Upload') {
                    $qry .= " AND link_upload != '' ";
                } else if ($status == 'Tidak Ada Link Upload') {
                    $qry .= " AND link_upload = '' ";
                } else if ($status == 'FYP') {
                    $qry .= " AND is_fyp = 1 ";
                }
            }

            $status = $_GET['endorse_status'];
            $statusArray = $status ? explode(',', $status) : [];
            $text = '';
            foreach ($statusArray as $k => $v) {
                $text .= "'" . $v . "',";
            }
            $text = substr($text, 0, -1);

            if ($text) {
                $qry .= " AND status_endorse IN ($text) ";
            }


            $platform = $_GET['platform'];
            if ($platform) {
                $qry .= " AND platform = '$platform' ";
            }


            if ($keyword) {
                if ($keyword_category == "Nama Creator") {
                    $qry .= " AND nama_creator LIKE '%$keyword%' ";
                } else if ($keyword_category == "Link Upload") {
                    $qry .= " AND link_upload LIKE '%$keyword%' ";
                } else if ($keyword_category == "PIC") {
                    $qry .= " AND pic LIKE '%$keyword%' ";
                } else if ($keyword_category == "Platform") {
                    $qry .= " AND platform LIKE '%$keyword%' ";
                } else if ($keyword_category == "Task") {
                    $qry .= " AND task LIKE '%$keyword%' ";
                } else if ($keyword_category == "Keterangan") {
                    $qry .= " AND endorse.desc LIKE '%$keyword%' ";
                }
            }

            $query = $this->mymodel->selectWithQuery("SELECT influencer as id
            FROM endorse
            WHERE id_campaign = '$id_campaign' $qry 
            GROUP BY influencer
            ");
            $text = "0,";
            foreach ($query as $k => $v) {
                $text .= $v['id'] . ',';
            }
            $text = substr($text, 0, -1);

            $qry = "";

            $query = $this->mymodel->selectWithQuery("SELECT COUNT(id) AS count
            FROM influencer
            WHERE id IN ($text) $qry 
            ");
            $add_param = "&id_influencer=$text";
        }
        $data['page'] = CEIL($query[0]['count'] / 30);

        $data['notif'] = '<p class="mb-1"><label class="text-notif">' . $this->template->separator_only($query[0]['count']) . ' data ditemukan!</label></p>';

        $item = '';

        $current_page = intval($_GET['page']);
        if ($current_page <= 1) {
            $current_page = 1;
        }

        $data['title_2'] = $this->template->date_format_indo($start_date) . ' - ' . $this->template->date_format_indo($until_date);

        $url = base_url() . '/endorse/' . $this->template->get_param();
        $data['url'] = $this->template->get_param_without('endorse_status');
        $data['url_2'] = $this->template->get_param_without('status');
        $data['url_item'] = $this->template->get_param() . $add_param;
        $data['param'] = $this->template->get_param();
        $data['param_pagination'] = $this->template->get_param_without('page');
        $data['pagination'] = $this->template->pagination($data['page'], $current_page, $data['param_pagination']);

        if ($id_influencer) {
            $data['content'] = $this->load->view("endorse/stats_endorse", $data, true);
            $this->load->view("TemplateDashboard", $data);
        } else if ($id_campaign) {
            $data['content'] = $this->load->view("endorse/stats_influencer", $data, true);
            $this->load->view("TemplateDashboard", $data);
        }
    }

    public function item_influencer()
    {

        $data['template'] = $this->template;

        if ($_GET['keyword_category']) {
            $keyword_category = $_GET['keyword_category'];
        } else {
            $keyword_category = "Username";
        }
        $data['keyword_category'] = $keyword_category;
        $keyword = $_GET['keyword'];

        if ($_GET['start_date']) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = DATE('Y-m-d');
        }
        if ($_GET['until_date']) {
            $until_date = $_GET['until_date'];
        } else {
            $until_date = DATE('Y-m-d');
        }
        $qry = "";
        $qry = " 1=1 ";

        $id_influencer = $_GET['id_influencer'];
        if ($id_influencer) {
            $qry .= " AND id  IN ($id_influencer) ";
        }




        $status = $_GET['status'];
        $statusArray = $status ? explode(',', $status) : [];
        $text = '';
        foreach ($statusArray as $k => $v) {
            $text .= "'" . $v . "',";
        }
        $text = substr($text, 0, -1);

        if ($text) {
            $qry .= " AND status_reach IN ($text) ";
        }

        if ($keyword) {
            if ($keyword_category == "Nama Creator") {
                $qry .= " AND full_name LIKE '%$keyword%' ";
            } else if ($keyword_category == "Username") {
                $qry .= " AND influencer.username LIKE '%$keyword%' ";
            } else if ($keyword_category == "URL") {
                $qry .= " AND influencer.url LIKE '%$keyword%' ";
            } else if ($keyword_category == "Keterangan") {
                $qry .= " AND influencer.desc LIKE '%$keyword%' ";
            } else if ($keyword_category == "Platform") {
                $qry .= " AND influencer.type LIKE '%$keyword%' ";
            } else if ($keyword_category == "Niche") {
                $qry .= " AND influencer.niche LIKE '%$keyword%' ";
            } else if ($keyword_category == "PIC") {
                $qry .= " AND influencer.pic LIKE '%$keyword%' ";
            }
        }

        $order_by = ' ORDER BY ';
        $sort = $_GET['sort'];
        $sort_sub = $_GET['sort_sub'];

        if ($sort == "Frequency") {
            $order_by .= " frequency ";
        } else if ($sort == "RC") {
            $order_by .= " ratecard ";
        } else if ($sort == "CPM") {
            $order_by .= " cpm ";
        } else if ($sort == "ER") {
            $order_by .= " er ";
        } else {
            $order_by .= " id ";
        }

        if ($sort_sub == "Asc") {
            $order_by .= " ASC ";
        } else {
            $order_by .= " DESC ";
        }

        $limit = 30;

        $current_page = $_GET['page'];

        if ($current_page <= 1) {
            $offset = 0;
        } else {
            $offset = ($current_page - 1) * $limit;
        }

        $query = $this->mymodel->selectWithQuery("SELECT * FROM influencer
        WHERE $qry 
        $order_by
        LIMIT $offset, $limit
        ");


        $data['campaign']['id'] = $_GET['id_campaign'];



        $data['data'] = $query;

        $data['start'] = $offset;
        $this->load->view("influencer/item", $data);
    }

    public function item_endorse()
    {

        $id_campaign = $_GET['id_campaign'];

        $type = $_GET['type'];
        $start_date = $_GET['start_date'];
        $until_date = $_GET['until_date'];
        $start_year = $_GET['start_year'];
        $until_year = $_GET['until_year'];
        $start_month = $_GET['start_month'];
        $until_month = $_GET['until_month'];
        $start_week = $_GET['start_week'];
        $until_week = $_GET['until_week'];
        $site = $_GET['site'];
        $customer = $_GET['customer'];
        $mpu = $_GET['mpu'];

        if ($type == "Yearly") {
            $qry_opt = " YEAR(date) ";
            $start_date = $start_year . '-01-01';
            $until_date = $until_year . '-12-31';
            $group = "  GROUP BY YEAR(date) ";
        } else if ($type == "Monthly") {
            $qry_opt = " MONTH(date) ";
            $start_month = str_pad($start_month, 2, "0", STR_PAD_LEFT);
            $until_month = str_pad($until_month, 2, "0", STR_PAD_LEFT);
            $start_date = $start_year . '-' . $start_month . '-01';
            $until_date = $start_year . '-' . $until_month . '-31';
            $group = "  GROUP BY MONTH(date) ";
        } else if ($type == "Weekly") {
            $qry_opt = " WEEK(date) ";
            $start_week = str_pad($start_week, 2, "0", STR_PAD_LEFT);
            $until_week = str_pad($until_week, 2, "0", STR_PAD_LEFT);

            $year = $start_year;
            $week = $start_week;
            $start_date = date("Y-m-d", strtotime($year . "W" . $week . "1"));

            $year = $start_year;
            $week = $until_week;
            $until_date = date("Y-m-d", strtotime($year . "W" . $week . "7"));
            $group = "  GROUP BY WEEK(date) ";
        } else {
            $qry_opt = " DATE(date) ";
            $group = "  GROUP BY DATE(date) ";
        }



        if ($_GET['keyword_category']) {
            $keyword_category = $_GET['keyword_category'];
        } else {
            $keyword_category = "Nama Creator";
        }
        $data['keyword_category'] = $keyword_category;
        $keyword = $_GET['keyword'];

        if ($_GET['start_date']) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = DATE("Y-m-d");
            $start_date = DATE('Y-m-d', strtotime($today . " -31 days"));
        }
        if ($_GET['until_date']) {
            $until_date = $_GET['until_date'];
        } else {
            $until_date = DATE('Y-m-d');
        }
        $data['start_date'] = $start_date;
        $data['until_date'] = $until_date;
        $qry = "";

        $ids = $_GET['ids'];
        $data['ids'] = $ids;
        if ($ids) {
            $qry .= " AND id  IN ($ids) ";
        }

        if ($brand) {
            $qry .= " AND brand = '$brand' ";
        }

        $cat = $_GET['cat'];
        if ($cat == "Tanggal Dibuat") {
            $qry .= " AND DATE(created_at) >= '$start_date' AND DATE(created_at) <= '$until_date' ";
        } else if ($cat == "Rencana Upload") {
            $qry .= " AND DATE(rencana_at) >= '$start_date' AND DATE(rencana_at) <= '$until_date' ";
        } else if ($cat == "Tanggal Posting") {
            $qry .= " AND DATE(posting_at) >= '$start_date' AND DATE(posting_at) <= '$until_date' ";
        } else {
            // $qry .= " AND DATE(created_at) >= '$start_date' AND DATE(created_at) <= '$until_date' ";
        }

        $status = $_GET['status'];
        if ($status) {
            if ($status == 'Ada Link Upload') {
                $qry .= " AND link_upload != '' ";
            } else if ($status == 'Tidak Ada Link Upload') {
                $qry .= " AND link_upload = '' ";
            } else if ($status == 'FYP') {
                $qry .= " AND is_fyp = 1 ";
            }
        }

        $status = $_GET['endorse_status'];
        $statusArray = $status ? explode(',', $status) : [];
        $text = '';
        foreach ($statusArray as $k => $v) {
            $text .= "'" . $v . "',";
        }
        $text = substr($text, 0, -1);

        if ($text) {
            $qry .= " AND status_endorse IN ($text) ";
        }


        $platform = $_GET['platform'];
        if ($platform) {
            $qry .= " AND platform = '$platform' ";
        }


        if ($keyword) {
            if ($keyword_category == "Nama Creator") {
                $qry .= " AND nama_creator LIKE '%$keyword%' ";
            } else if ($keyword_category == "Link Upload") {
                $qry .= " AND link_upload LIKE '%$keyword%' ";
            } else if ($keyword_category == "PIC") {
                $qry .= " AND pic LIKE '%$keyword%' ";
            } else if ($keyword_category == "Platform") {
                $qry .= " AND platform LIKE '%$keyword%' ";
            } else if ($keyword_category == "Task") {
                $qry .= " AND task LIKE '%$keyword%' ";
            } else if ($keyword_category == "Keterangan") {
                $qry .= " AND endorse.desc LIKE '%$keyword%' ";
            }
        }

        $limit = 30;

        $current_page = $_GET['page'];

        if ($current_page <= 1) {
            $offset = 0;
        } else {
            $offset = ($current_page - 1) * $limit;
        }
        $id_influencer = $_GET['id_influencer'];
        $id_campaign = $_GET['id_campaign'];
        $qry = "";
        if ($id_campaign) {
            $qry .= " AND id_campaign = '$id_campaign' ";
        }
        $query = $this->mymodel->selectWithQuery("SELECT * FROM endorse
        WHERE influencer = '$id_influencer' $qry 
        ORDER BY id DESC
        LIMIT $offset, $limit
        ");


        $data['data'] = $query;

        $data['template'] = $this->template;

        $url = base_url() . '/endorse/' . $this->template->get_param();
        $data['url'] = $this->template->get_param_without_status();
        $data['param'] = $this->template->get_param_without('endorse_status');

        $data['start'] = $offset;
        $this->load->view("endorse/item", $data);
    }

    public function index()
    {

        $data['template'] = $this->template;

        $data['title'] = 'Campaign Detail - ' . $this->template->title();

        $data['checkbox'] = $_SESSION['checkbox'];
        $id_campaign = $_GET['id_campaign'];
        $data['detail'] = $this->mymodel->selectWithQuery("SELECT *
        FROM endorse_campaign WHERE id = '$id_campaign'");
        $data['detail'] = $data['detail'][0];
        if (empty($data['detail'])) {
            redirect(base_url() . 'endorse-campaign');
        }

        $id_campaign = $_GET['id_campaign'];

        $type = $_GET['type'];
        $start_date = $_GET['start_date'];
        $until_date = $_GET['until_date'];
        $start_year = $_GET['start_year'];
        $until_year = $_GET['until_year'];
        $start_month = $_GET['start_month'];
        $until_month = $_GET['until_month'];
        $start_week = $_GET['start_week'];
        $until_week = $_GET['until_week'];
        $site = $_GET['site'];
        $customer = $_GET['customer'];
        $mpu = $_GET['mpu'];

        if ($type == "Yearly") {
            $qry_opt = " YEAR(date) ";
            $start_date = $start_year . '-01-01';
            $until_date = $until_year . '-12-31';
            $group = "  GROUP BY YEAR(date) ";
        } else if ($type == "Monthly") {
            $qry_opt = " MONTH(date) ";
            $start_month = str_pad($start_month, 2, "0", STR_PAD_LEFT);
            $until_month = str_pad($until_month, 2, "0", STR_PAD_LEFT);
            $start_date = $start_year . '-' . $start_month . '-01';
            $until_date = $start_year . '-' . $until_month . '-31';
            $group = "  GROUP BY MONTH(date) ";
        } else if ($type == "Weekly") {
            $qry_opt = " WEEK(date) ";
            $start_week = str_pad($start_week, 2, "0", STR_PAD_LEFT);
            $until_week = str_pad($until_week, 2, "0", STR_PAD_LEFT);

            $year = $start_year;
            $week = $start_week;
            $start_date = date("Y-m-d", strtotime($year . "W" . $week . "1"));

            $year = $start_year;
            $week = $until_week;
            $until_date = date("Y-m-d", strtotime($year . "W" . $week . "7"));
            $group = "  GROUP BY WEEK(date) ";
        } else {
            $qry_opt = " DATE(date) ";
            $group = "  GROUP BY DATE(date) ";
        }



        if ($_GET['keyword_category']) {
            $keyword_category = $_GET['keyword_category'];
        } else {
            $keyword_category = "Nama Creator";
        }
        $data['keyword_category'] = $keyword_category;
        $keyword = $_GET['keyword'];

        if ($_GET['start_date']) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = DATE("Y-m-d");
            $start_date = DATE('Y-m-d', strtotime($today . " -31 days"));
        }
        if ($_GET['until_date']) {
            $until_date = $_GET['until_date'];
        } else {
            $until_date = DATE('Y-m-d');
        }
        $data['start_date'] = $start_date;
        $data['until_date'] = $until_date;
        $qry = "";

        $ids = $_GET['ids'];
        $data['ids'] = $ids;
        if ($ids) {
            $qry .= " AND id  IN ($ids) ";
        }

        if ($brand) {
            $qry .= " AND brand = '$brand' ";
        }

        $cat = $_GET['cat'];
        if ($cat == "Tanggal Dibuat") {
            $qry .= " AND DATE(created_at) >= '$start_date' AND DATE(created_at) <= '$until_date' ";
        } else if ($cat == "Rencana Upload") {
            $qry .= " AND DATE(rencana_at) >= '$start_date' AND DATE(rencana_at) <= '$until_date' ";
        } else if ($cat == "Tanggal Posting") {
            $qry .= " AND DATE(posting_at) >= '$start_date' AND DATE(posting_at) <= '$until_date' ";
        } else {
            // $qry .= " AND DATE(created_at) >= '$start_date' AND DATE(created_at) <= '$until_date' ";
        }

        $status = $_GET['status'];
        if ($status) {
            if ($status == 'Ada Link Upload') {
                $qry .= " AND link_upload != '' ";
            } else if ($status == 'Tidak Ada Link Upload') {
                $qry .= " AND link_upload = '' ";
            } else if ($status == 'FYP') {
                $qry .= " AND is_fyp = 1 ";
            }
        }

        $status = $_GET['endorse_status'];
        $statusArray = $status ? explode(',', $status) : [];
        $text = '';
        foreach ($statusArray as $k => $v) {
            $text .= "'" . $v . "',";
        }
        $text = substr($text, 0, -1);

        if ($text) {
            $qry .= " AND status_endorse IN ($text) ";
        }

        $platform = $_GET['platform'];
        if ($platform) {
            $qry .= " AND platform = '$platform' ";
        }


        if ($keyword) {
            if ($keyword_category == "Nama Creator") {
                $qry .= " AND nama_creator LIKE '%$keyword%' ";
            } else if ($keyword_category == "Link Upload") {
                $qry .= " AND link_upload LIKE '%$keyword%' ";
            } else if ($keyword_category == "PIC") {
                $qry .= " AND pic LIKE '%$keyword%' ";
            } else if ($keyword_category == "Platform") {
                $qry .= " AND platform LIKE '%$keyword%' ";
            } else if ($keyword_category == "Task") {
                $qry .= " AND task LIKE '%$keyword%' ";
            } else if ($keyword_category == "Keterangan") {
                $qry .= " AND endorse.desc LIKE '%$keyword%' ";
            }
        }


        $query = $this->mymodel->selectWithQuery("SELECT COUNT(id) AS count
        FROM endorse
        WHERE id_campaign = '$id_campaign' $qry 
        ");

        $data['page'] = CEIL($query[0]['count'] / 30);

        $data['notif'] = '<p class="mb-1"><label class="text-notif">' . $this->template->separator_only($query[0]['count']) . ' data ditemukan!</label></p>';

        $item = '';

        $current_page = intval($_GET['page']);
        if ($current_page <= 1) {
            $current_page = 1;
        }

        $data['title_2'] = $this->template->date_format_indo($start_date) . ' - ' . $this->template->date_format_indo($until_date);

        $url = base_url() . '/endorse/' . $this->template->get_param();
        $data['url'] = $this->template->get_param_without('endorse_status');
        $data['url_2'] = $this->template->get_param_without('status');
        $data['url_item'] = $this->template->get_param();
        $data['param'] = $this->template->get_param();
        $data['param_pagination'] = $this->template->get_param_without('page');
        $data['pagination'] = $this->template->pagination($data['page'], $current_page, $data['param_pagination']);

        $data['content'] = $this->load->view("endorse/all", $data, true);
        $this->load->view("TemplateDashboard", $data);
    }

    public function detail()
    {

        $data['template'] = $this->template;
        $data['title'] = 'Endorse Detail - ' . $this->template->title();
        if ($_GET['start_date']) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = DATE("Y-m-d");
            $start_date = DATE('Y-m-d', strtotime($today . " -31 days"));
        }
        if ($_GET['until_date']) {
            $until_date = $_GET['until_date'];
        } else {
            $until_date = DATE('Y-m-d');
        }
        $data['start_date'] = $start_date;
        $data['until_date'] = $until_date;
        $data['checkbox'] = $_SESSION['checkbox'];
        $id = $_GET['id'];
        $data['detail'] = $this->mymodel->selectWithQuery("SELECT *
        FROM endorse WHERE id = '$id'");
        $data['detail'] = $data['detail'][0];

        $data['title_2'] = $this->template->date_format_indo($start_date) . ' - ' . $this->template->date_format_indo($until_date);


        $data['content'] = $this->load->view("endorse/detail", $data, true);
        $this->load->view("TemplateDashboard", $data);
    }

    public function item()
    {

        $id_campaign = $_GET['id_campaign'];

        $type = $_GET['type'];
        $start_date = $_GET['start_date'];
        $until_date = $_GET['until_date'];
        $start_year = $_GET['start_year'];
        $until_year = $_GET['until_year'];
        $start_month = $_GET['start_month'];
        $until_month = $_GET['until_month'];
        $start_week = $_GET['start_week'];
        $until_week = $_GET['until_week'];
        $site = $_GET['site'];
        $customer = $_GET['customer'];
        $mpu = $_GET['mpu'];

        if ($type == "Yearly") {
            $qry_opt = " YEAR(date) ";
            $start_date = $start_year . '-01-01';
            $until_date = $until_year . '-12-31';
            $group = "  GROUP BY YEAR(date) ";
        } else if ($type == "Monthly") {
            $qry_opt = " MONTH(date) ";
            $start_month = str_pad($start_month, 2, "0", STR_PAD_LEFT);
            $until_month = str_pad($until_month, 2, "0", STR_PAD_LEFT);
            $start_date = $start_year . '-' . $start_month . '-01';
            $until_date = $start_year . '-' . $until_month . '-31';
            $group = "  GROUP BY MONTH(date) ";
        } else if ($type == "Weekly") {
            $qry_opt = " WEEK(date) ";
            $start_week = str_pad($start_week, 2, "0", STR_PAD_LEFT);
            $until_week = str_pad($until_week, 2, "0", STR_PAD_LEFT);

            $year = $start_year;
            $week = $start_week;
            $start_date = date("Y-m-d", strtotime($year . "W" . $week . "1"));

            $year = $start_year;
            $week = $until_week;
            $until_date = date("Y-m-d", strtotime($year . "W" . $week . "7"));
            $group = "  GROUP BY WEEK(date) ";
        } else {
            $qry_opt = " DATE(date) ";
            $group = "  GROUP BY DATE(date) ";
        }



        if ($_GET['keyword_category']) {
            $keyword_category = $_GET['keyword_category'];
        } else {
            $keyword_category = "Nama Creator";
        }
        $data['keyword_category'] = $keyword_category;
        $keyword = $_GET['keyword'];

        if ($_GET['start_date']) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = DATE("Y-m-d");
            $start_date = DATE('Y-m-d', strtotime($today . " -31 days"));
        }
        if ($_GET['until_date']) {
            $until_date = $_GET['until_date'];
        } else {
            $until_date = DATE('Y-m-d');
        }
        $data['start_date'] = $start_date;
        $data['until_date'] = $until_date;
        $qry = "";

        $ids = $_GET['ids'];
        $data['ids'] = $ids;
        if ($ids) {
            $qry .= " AND id  IN ($ids) ";
        }

        if ($brand) {
            $qry .= " AND brand = '$brand' ";
        }

        $cat = $_GET['cat'];
        if ($cat == "Tanggal Dibuat") {
            $qry .= " AND DATE(created_at) >= '$start_date' AND DATE(created_at) <= '$until_date' ";
        } else if ($cat == "Rencana Upload") {
            $qry .= " AND DATE(rencana_at) >= '$start_date' AND DATE(rencana_at) <= '$until_date' ";
        } else if ($cat == "Tanggal Posting") {
            $qry .= " AND DATE(posting_at) >= '$start_date' AND DATE(posting_at) <= '$until_date' ";
        } else {
            // $qry .= " AND DATE(created_at) >= '$start_date' AND DATE(created_at) <= '$until_date' ";
        }

        $status = $_GET['status'];
        if ($status) {
            if ($status == 'Ada Link Upload') {
                $qry .= " AND link_upload != '' ";
            } else if ($status == 'Tidak Ada Link Upload') {
                $qry .= " AND link_upload = '' ";
            } else if ($status == 'FYP') {
                $qry .= " AND is_fyp = 1 ";
            }
        }

        $status = $_GET['endorse_status'];
        $statusArray = $status ? explode(',', $status) : [];
        $text = '';
        foreach ($statusArray as $k => $v) {
            $text .= "'" . $v . "',";
        }
        $text = substr($text, 0, -1);

        if ($text) {
            $qry .= " AND status_endorse IN ($text) ";
        }


        $platform = $_GET['platform'];
        if ($platform) {
            $qry .= " AND platform = '$platform' ";
        }


        if ($keyword) {
            if ($keyword_category == "Nama Creator") {
                $qry .= " AND nama_creator LIKE '%$keyword%' ";
            } else if ($keyword_category == "Link Upload") {
                $qry .= " AND link_upload LIKE '%$keyword%' ";
            } else if ($keyword_category == "PIC") {
                $qry .= " AND pic LIKE '%$keyword%' ";
            } else if ($keyword_category == "Platform") {
                $qry .= " AND platform LIKE '%$keyword%' ";
            } else if ($keyword_category == "Task") {
                $qry .= " AND task LIKE '%$keyword%' ";
            } else if ($keyword_category == "Keterangan") {
                $qry .= " AND endorse.desc LIKE '%$keyword%' ";
            }
        }

        $limit = 30;

        $current_page = $_GET['page'];

        if ($current_page <= 1) {
            $offset = 0;
        } else {
            $offset = ($current_page - 1) * $limit;
        }
        $query = $this->mymodel->selectWithQuery("SELECT * FROM endorse
        WHERE id_campaign = '$id_campaign' $qry 
        ORDER BY id DESC
        LIMIT $offset, $limit
        ");


        $data['data'] = $query;

        $data['template'] = $this->template;

        $url = base_url() . '/endorse/' . $this->template->get_param();
        $data['url'] = $this->template->get_param_without_status();
        $data['param'] = $this->template->get_param_without('endorse_status');

        $data['start'] = $offset;
        $this->load->view("endorse/item", $data);
    }

    public function sync_all()
    {
        $id = $_GET['id'];
        $data['data']['id'] = $id;
        $this->load->view("endorse/sync_all", $data);
    }
    public function sync_all_process()
    {
        $id = $_POST['id'];
        $filter = $_GET;

        // $target = DATE("Y-m-d 12:00:00");
        $target = DATE("Y-m-d 23:30:00");
        $now = DATE("Y-m-d H:i:s");

        $user = $_SESSION['user'];
        $today = DATE("Y-m-d");
        $yesterday = DATE('Y-m-d', strtotime($today . " -1 days"));

        $mode = $_GET['mode'];
        $ids = $_GET['ids'];
        if ($mode == "refresh_data") {
            $qry = " AND a.id IN ($ids) ";
            $id = $_GET['id_campaign'];
        }


        $data = $this->mymodel->selectWithQuery("SELECT a.*
        FROM endorse a 
        JOIN endorse_campaign b
        ON a.id_campaign = b.id
        WHERE a.id_campaign = '$id'
        AND a.link_upload != '' 
        AND a.status = 'Aktif' AND b.status = 'Aktif'
        $qry
        ");



        foreach ($data as $k => $v) {
            $id_endorse = $v['id'];
            $query = $this->mymodel->selectWithQuery("SELECT id
            FROM endorse_logs
            WHERE id_endorse = '$id_endorse' AND date = '$today' ");
            $query = $query[0];

            $query_yesterday = $this->mymodel->selectWithQuery("SELECT * 
            FROM endorse_logs
            WHERE id_endorse = '$id_endorse' AND date < '$today' AND views > 0 ORDER BY date DESC LIMIT 1 ");
            $query_yesterday = $query_yesterday[0];

            $dt = array();
            $dt['id_endorse'] = strval($v['id']);
            $dt['id_campaign'] = strval($v['id_campaign']);
            $dt['date'] = $today;

            $response = $this->template->get_social_media($v['platform'], $v['link_upload']);

            if ($response['data']['view'] > 0) {
                $dt['likes'] = $response['data']['like'];
                $dt['comment'] = $response['data']['comment'];
                $dt['share_save'] = doubleval($response['data']['share']) + doubleval($response['data']['collect']);
                $dt['views'] = $response['data']['view'];

                if ($dt['views'] >= 50000) {
                    $id_influencer = $v['influencer'];
                    $creator = $this->mymodel->selectWithQuery("SELECT follower
                    FROM influencer WHERE id = '$id_influencer'");
                    $creator = $creator[0];
                    $percentage = 0;
                    $follower = intval($creator['follower']);
                    if ($follower > 0) {
                        $batas = intval($follower * 30 / 100);
                        if ($dt['views'] >= $batas) {
                            $dt['is_fyp'] = "1";
                        }
                    } else {
                        $dt['is_fyp'] = "1";
                    }
                }
                if ($v['total_cost'] > 0 && $dt['views'] > 0) {
                    $dt['cpm'] = doubleval($v['total_cost']) / doubleval($dt['views']) * 1000;
                } else {
                    $dt['cpm'] = 0;
                }
                $dtt = $dt;
                unset($dtt['id_endorse']);
                unset($dtt['id_campaign']);
                unset($dtt['date']);
                $dtt['updated_at'] = DATE("Y-m-d H:i:s");

                $this->db->update('endorse', $dtt, array('id' => $id_endorse));

                $dtt = array();
                $dtt['sync_at'] = DATE("Y-m-d H:i:s");
                $dtt['posting_at'] = $response['data']['created_at'];
                $dtt['likes'] = doubleval($dt['likes']);
                $dtt['comment'] = doubleval($dt['comment']);
                $dtt['share_save'] = doubleval($dt['share_save']);
                $dtt['views'] = doubleval($dt['views']);
                $dtt['cpm'] = doubleval($dt['cpm']);

                $dt['total_cost'] = doubleval($v['total_cost']);

                $dt['link_upload'] = strval($v['link_upload']);
                $dt['platform'] = strval($v['platform']);

                $dt['likes_after'] = intval($dt['likes']);
                $dt['comment_after'] = intval($dt['comment']);
                $dt['share_save_after'] = intval($dt['share_save']);
                $dt['views_after'] = intval($dt['views']);

                if ($v['total_cost'] > 0 && $dt['views_after'] > 0) {
                    $dt['cpm_after'] = doubleval($v['total_cost']) / doubleval($dt['views_after']) * 1000;
                } else {
                    $dt['cpm_after'] = 0;
                }

                $dt['likes'] -= intval($query_yesterday['likes_after']);
                $dt['comment'] -= intval($query_yesterday['comment_after']);
                $dt['share_save'] -= intval($query_yesterday['share_save_after']);
                $dt['views'] -= intval($query_yesterday['views_after']);

                if ($v['total_cost'] > 0 && $dt['views'] > 0) {
                    $dt['cpm'] = doubleval($v['total_cost']) / doubleval($dt['views']) * 1000;
                } else {
                    $dt['cpm'] = 0;
                }

                $dt['likes_before'] = intval($query_yesterday['likes_after']);
                $dt['comment_before'] = intval($query_yesterday['comment_after']);
                $dt['share_save_before'] = intval($query_yesterday['share_save_after']);
                $dt['views_before'] = intval($query_yesterday['views_after']);

                if ($v['total_cost'] > 0 && $dt['views_before'] > 0) {
                    $dt['cpm_before'] = doubleval($v['total_cost']) / doubleval($dt['views_before']) * 1000;
                } else {
                    $dt['cpm_before'] = 0;
                }
            }

            // $dt['is_cron'] = '1';
            // print_r($dt);die;

            $dt_tmp = array();
            foreach ($dt as $kt => $vt) {
                $dt_tmp[$kt] = strval($vt);
            }
            $dt = $dt_tmp;


            unset($dt['is_fyp']);
            unset($dt['posting_at']);
            unset($dt['sync_at']);

            if ($query) {
                $dt['updated_at'] = DATE("Y-m-d H:i:s");
                $dt['updated_by'] = strval($user['id']);
                $this->db->update('endorse_logs', $dt, array('id' => $query['id']));
                $id_parent = $query['id'];
            } else {
                $dt['created_at'] = DATE("Y-m-d H:i:s");
                $dt['created_by'] = strval($user['id']);
                $this->db->insert('endorse_logs', $dt);
                $id_parent = $this->db->insert_id();
            }

            $dt_tmp = array();
            foreach ($dtt as $kt => $vt) {
                $dt_tmp[$kt] = strval($vt);
            }
            $dtt = $dt_tmp;

            $dtt['updated_at'] = DATE("Y-m-d H:i:s");
            $dtt['updated_by'] = strval($user['id']);
            // print_r($dtt);die;
            $this->db->update('endorse', $dtt, array('id' => $v['id']));
        }
        $data = $this->mymodel->selectWithQuery("SELECT id
        FROM endorse_campaign 
        WHERE status = 'Aktif' 
        AND id = '$id'");
        foreach ($data as $k => $v) {
            $id_parent = $v['id'];
            $this->update_endorse_parent($id_parent);
        }
        $msg = 'Refresh data berhasil!';
        echo $this->template->alert_success($msg);
    }
    function update_endorse_parent($id_parent)
    {
        $user = $_SESSION['user'];

        $v['id'] = $id_parent;
        $today = DATE("Y-m-d");
        $yesterday = DATE('Y-m-d', strtotime($today . " -1 days"));
        $query = $this->mymodel->selectWithQuery("SELECT id
        FROM endorse_campaign_logs
        WHERE id_campaign = '$id_parent' AND date = '$today' ");
        $query = $query[0];

        $query_yesterday = $this->mymodel->selectWithQuery("SELECT *
        FROM endorse_campaign_logs
        WHERE id_campaign = '$id_parent' AND date < '$today' ORDER BY date DESC LIMIT 1 ");
        $query_yesterday = $query_yesterday[0];

        $item_detail = $this->mymodel->selectWithQuery("SELECT SUM(total_cost) as total_cost, COUNT(id) as count_endorse,
        SUM(likes) as likes, SUM(comment) as comment, SUM(share_save) as share_save, SUM(views) as views, AVG(cpm) as cpm
        FROM endorse
        WHERE id_campaign = '$id_parent'  AND link_upload != ''
        AND status = 'Aktif' ");
        $item_detail = $item_detail[0];

        $item = $this->mymodel->selectWithQuery("SELECT SUM(likes) as likes, SUM(comment) as comment, SUM(share_save) as share_save, SUM(views) as views, AVG(cpm) as cpm,
        SUM(likes_after) as likes_after, SUM(comment_after) as comment_after, SUM(share_save_after) as share_save_after, SUM(views_after) as views_after, AVG(cpm_after) as cpm_after,
        SUM(likes_before) as likes_before, SUM(comment_before) as comment_before, SUM(share_save_before) as share_save_before, SUM(views_before) as views_before, AVG(cpm_before) as cpm_before
        FROM endorse_logs
        WHERE id_campaign = '$id_parent';");
        $dt = array();
        $dt['id_campaign'] = $v['id'];
        $dt['total_cost'] = doubleval($item_detail['total_cost']);
        $dt['date'] = $today;
        foreach ($item[0] as $k2 => $v2) {
            $dt[$k2] = doubleval($v2);
        }


        $dtt = array();
        foreach ($item_detail as $k3 => $v3) {
            $dtt[$k3] = doubleval($v3);
        }

        $id_parent = $v['id'];

        $summary = $this->mymodel->selectWithQuery("SELECT COUNT(id) as count
        FROM endorse WHERE id_campaign = '$id_parent'  ");
        $summary = $summary[0];
        $dtt['count_endorse'] = intval($summary['count']);
        $dt['ce_now'] = $dtt['count_endorse'];

        $summary = $this->mymodel->selectWithQuery("SELECT COUNT(id) as count
        FROM endorse WHERE id_campaign = '$id_parent' AND status = 'Aktif'  ");
        $summary = $summary[0];
        $dtt['count_endorse_active'] = intval($summary['count']);
        $dt['ce_active_now'] = $dtt['count_endorse_active'];

        $summary = $this->mymodel->selectWithQuery("SELECT COUNT(id) as count
        FROM endorse WHERE id_campaign = '$id_parent' AND status = 'Aktif' 
        AND link_upload != '' ");
        $summary = $summary[0];
        $dtt['count_endorse_processed'] = intval($summary['count']);
        $dt['ce_processed_now'] = $dtt['count_endorse_processed'];


        $summary = $this->mymodel->selectWithQuery("SELECT COUNT(DISTINCT influencer) as count
        FROM endorse WHERE id_campaign = '$id_parent'  ");
        $summary = $summary[0];
        $dtt['count_influencer'] = intval($summary['count']);
        $dt['ci_now'] = $dtt['count_influencer'];

        $summary = $this->mymodel->selectWithQuery("SELECT COUNT(DISTINCT influencer) as count
        FROM endorse WHERE id_campaign = '$id_parent' AND status = 'Aktif'  ");
        $summary = $summary[0];
        $dtt['count_influencer_active'] = intval($summary['count']);
        $dt['ci_active_now'] = $dtt['count_influencer_active'];

        $summary = $this->mymodel->selectWithQuery("SELECT COUNT(DISTINCT influencer) as count
        FROM endorse WHERE id_campaign = '$id_parent' AND status = 'Aktif'  
        AND link_upload != '' ");
        $summary = $summary[0];
        $dtt['count_influencer_processed'] = intval($summary['count']);
        $dt['ci_processed_now'] = $dtt['count_influencer_processed'];

        // print_r($query_yesterday);die;
        $dt['ci_before'] =  $query_yesterday['ci_now'];
        $dt['ci_active_before'] = $query_yesterday['ci_active_now'];
        $dt['ci_processed_before'] = $query_yesterday['ci_processed_now'];

        $dt['ce_before'] =  $query_yesterday['ce_now'];
        $dt['ce_active_before'] = $query_yesterday['ce_active_now'];
        $dt['ce_processed_before'] = $query_yesterday['ce_processed_now'];

        $dt['ci_before'] =  $query_yesterday['ci_now'];
        $dt['ci_active_before'] = $query_yesterday['ci_active_now'];
        $dt['ci_processed_before'] = $query_yesterday['ci_processed_now'];
        $dt['ce_before'] =  $query_yesterday['ce_now'];
        $dt['ce_active_before'] = $query_yesterday['ce_active_now'];
        $dt['ce_processed_before'] = $query_yesterday['ce_processed_now'];

        $dt['ci_after'] =  $dt['ci_now'];
        $dt['ci_active_after'] = $dt['ci_active_now'];
        $dt['ci_processed_after'] = $dt['ci_processed_now'];
        $dt['ce_after'] =  $dt['ce_now'];
        $dt['ce_active_after'] = $dt['ce_active_now'];
        $dt['ce_processed_after'] = $dt['ce_processed_now'];

        $dt['ci_now'] =  $dt['ci_after'] - $dt['now_before'];
        $dt['ci_active_now'] = $dt['ci_active_after'] - $dt['ci_active_before'];
        $dt['ci_processed_now'] = $dt['ci_processed_after'] - $dt['ci_processed_before'];
        $dt['ce_now'] =  $dt['ce_after'] - $dt['ce_before'];
        $dt['ce_active_now'] = $dt['ce_active_after'] - $dt['ce_active_before'];
        $dt['ce_processed_now'] = $dt['ce_processed_after'] - $dt['ce_processed_before'];

        // $dt['is_cron'] = '1';
        $dt_tmp = array();
        foreach ($dt as $kt => $vt) {
            $dt_tmp[$kt] = strval($vt);
        }
        $dt = $dt_tmp;

        if ($query) {
            $dt['updated_at'] = DATE("Y-m-d H:i:s");
            $dt['updated_by'] = strval($user['id']);
            $this->db->update('endorse_campaign_logs', $dt, array('id' => $query['id']));
            // $id_parent = $query['id'];
        } else {
            $dt['created_at'] = DATE("Y-m-d H:i:s");
            $dt['created_by'] = strval($user['id']);
            $this->db->insert('endorse_campaign_logs', $dt);
            // $id_parent = $this->db->insert_id();
        }

        $dt_tmp = array();
        foreach ($dtt as $kt => $vt) {
            $dt_tmp[$kt] = strval($vt);
        }
        $dtt = $dt_tmp;

        $campaign = $this->mymodel->selectDataOne('endorse_campaign', array('id' => $id_parent));
        $dt['brand'] = strval($campaign['brand']);

        $dtt['updated_at'] = DATE("Y-m-d H:i:s");
        $dtt['updated_by'] = strval($user['id']);
        $this->db->update('endorse_campaign', $dtt, array('id' => $v['id']));
    }

    public function clone()
    {
        $id = $_GET['id'];
        $data['data']['id'] = $id;
        $this->load->view("endorse/clone", $data);
    }

    public function clone_process()
    {
        $user = $_SESSION['user'];
        $id = $_POST['id'];

        $query = $this->mymodel->selectDataOne("endorse", array('id' => $id));
        if ($query) {

            $dt = array();
            $dt = $query;
            $dt['created_at'] = DATE("Y-m-d H:i:s");
            $dt['sync_at'] = "";
            unset($dt['id']);
            unset($dt['cpm']);
            unset($dt['views']);
            unset($dt['comment']);
            unset($dt['likes']);
            unset($dt['share_save']);
            $this->db->insert('endorse', $dt);

            $id_parent = $query['id_campaign'];
            $this->update_endorse_parent($id_parent);
            $msg = 'Kloning konten berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = "Kloning konten tidak berhasil!";
            echo $this->template->alert_danger($msg);
        }
    }


    public function sync()
    {
        $id = $_GET['id'];
        $data['data']['id'] = $id;
        $this->load->view("endorse/sync", $data);
    }

    public function sync_process()
    {
        $user = $_SESSION['user'];
        $id = $_POST['id'];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM endorse WHERE id = '$id'");

        $v = $query[0];
        $detail = $query[0];
        $response = $this->template->get_social_media($v['platform'], $v['link_upload']);

        if ($response['status'] == true) {
            if ($response['data']['view'] > 0) {
                $dt['sync_at'] = DATE("Y-m-d H:i:s");
                // $dt['sync_at'] = "2024-06-18 H:i:s";
                $dt['posting_at'] = $response['data']['created_at'];
                $dt['likes'] = $response['data']['like'];

                $dt['comment'] = $response['data']['comment'];
                $dt['share_save'] = doubleval($response['data']['share']) + doubleval($response['data']['collect']);
                $dt['views'] = $response['data']['view'];

                if ($dt['views'] >= 50000) {
                    $id_influencer = $detail['influencer'];
                    $creator = $this->mymodel->selectWithQuery("SELECT follower
                    FROM influencer WHERE id = '$id_influencer'");
                    $creator = $creator[0];
                    $percentage = 0;
                    $follower = intval($creator['follower']);
                    if ($follower > 0) {
                        $batas = intval($follower * 30 / 100);
                        if ($dt['views'] >= $batas) {
                            $dt['is_fyp'] = "1";
                        }
                    } else {
                        $dt['is_fyp'] = "1";
                    }
                }

                if ($v['total_cost'] > 0 && $dt['views'] > 0) {
                    $dt['cpm'] = doubleval($v['total_cost']) / doubleval($dt['views']) * 1000;
                } else {
                    $dt['cpm'] = 0;
                }
            }
            $dt['updated_at'] = DATE("Y-m-d H:i:s");

            if ($this->db->update('endorse', $dt, array('id' => $id))) {

                unset($dt['is_fyp']);
                unset($dt['posting_at']);
                unset($dt['sync_at']);

                $today = DATE("Y-m-d");
                // $today = "2024-06-18";
                $yesterday = DATE('Y-m-d', strtotime($today . " -1 days"));

                $id_endorse = $v['id'];
                $query = $this->mymodel->selectWithQuery("SELECT id
                FROM endorse_logs
                WHERE id_endorse = '$id_endorse' AND date = '$today' ");
                $query = $query[0];

                $query_yesterday = $this->mymodel->selectWithQuery("SELECT * 
                FROM endorse_logs
                WHERE id_endorse = '$id_endorse' AND date < '$today' AND views > 0 ORDER BY date DESC LIMIT 1");
                $query_yesterday = $query_yesterday[0];

                $dt['id_endorse'] = strval($v['id']);
                $dt['id_campaign'] = strval($v['id_campaign']);
                $dt['date'] = $today;


                $dtt = array();
                $dtt['likes'] = doubleval($dt['likes']);
                $dtt['comment'] = doubleval($dt['comment']);
                $dtt['share_save'] = doubleval($dt['share_save']);
                $dtt['views'] = doubleval($dt['views']);
                $dtt['cpm'] = doubleval($dt['cpm']);

                $dt['total_cost'] = doubleval($v['total_cost']);

                $dt['link_upload'] = strval($v['link_upload']);
                $dt['platform'] = strval($v['platform']);

                $dt['likes_after'] = intval($dt['likes']);
                $dt['comment_after'] = intval($dt['comment']);
                $dt['share_save_after'] = intval($dt['share_save']);
                $dt['views_after'] = intval($dt['views']);

                if ($v['total_cost'] > 0 && $dt['views_after'] > 0) {
                    $dt['cpm_after'] = doubleval($v['total_cost']) / doubleval($dt['views_after']) * 1000;
                } else {
                    $dt['cpm_after'] = 0;
                }

                $dt['likes'] -= intval($query_yesterday['likes_after']);
                $dt['comment'] -= intval($query_yesterday['comment_after']);
                $dt['share_save'] -= intval($query_yesterday['share_save_after']);
                $dt['views'] -= intval($query_yesterday['views_after']);

                if ($v['total_cost'] > 0 && $dt['views'] > 0) {
                    $dt['cpm'] = doubleval($v['total_cost']) / doubleval($dt['views']) * 1000;
                } else {
                    $dt['cpm'] = 0;
                }

                $dt['likes_before'] = intval($query_yesterday['likes_after']);
                $dt['comment_before'] = intval($query_yesterday['comment_after']);
                $dt['share_save_before'] = intval($query_yesterday['share_save_after']);
                $dt['views_before'] = intval($query_yesterday['views_after']);

                if ($v['total_cost'] > 0 && $dt['views_before'] > 0) {
                    $dt['cpm_before'] = doubleval($v['total_cost']) / doubleval($dt['views_before']) * 1000;
                } else {
                    $dt['cpm_before'] = 0;
                }

                $dt['brand'] = strval($detail['brand']);

                $dt_tmp = array();
                foreach ($dt as $kt => $vt) {
                    $dt_tmp[$kt] = strval($vt);
                }
                $dt = $dt_tmp;

                if ($query) {
                    $dt['updated_at'] = DATE("Y-m-d H:i:s");
                    $dt['updated_by'] = strval($user['id']);
                    $this->db->update('endorse_logs', $dt, array('id' => $query['id']));
                    $id_parent = $query['id'];
                } else {
                    $dt['created_at'] = DATE("Y-m-d H:i:s");
                    $dt['created_by'] = strval($user['id']);
                    $this->db->insert('endorse_logs', $dt);
                    $id_parent = $this->db->insert_id();
                }
                $id_parent = $detail['id_campaign'];
                $this->update_endorse_parent($id_parent);
                $msg = 'Refresh data berhasil!';
                echo $this->template->alert_success($msg);
            } else {
                $msg = 'Refresh data tidak berhasil!';
                echo $this->template->alert_danger($msg);
            }
        } else {
            echo $this->template->alert_danger($response['msg']);
        }
    }


    public function edit()
    {
        $id = $_GET['id'];

        $query = $this->mymodel->selectWithQuery("SELECT * FROM endorse WHERE id = '$id'");

        $data['data'] = $query[0];

        $data['pic'] = $this->mymodel->selectWithQuery("SELECT * FROM user ORDER BY full_name ASC");
        $data['brand'] = $this->mymodel->selectWithQuery("SELECT * FROM brand ORDER BY code ASC");
        $data['influencer'] = $this->mymodel->selectWithQuery("SELECT * FROM influencer ORDER BY full_name ASC");


        $query = $this->mymodel->selectWithQuery("SELECT * FROM brand ORDER BY name ASC");

        $data['brand'] = $query;
        $this->load->view("endorse/edit", $data);
    }

    public function update()
    {

        $user = $_SESSION['user'];

        $id = $_POST['id'];
        $id_campaign = $_POST['id_campaign'];
        $dt = $_POST['dt'];
        $dt['updated_at'] = DATE("Y-m-d H:i:s");
        $dt['updated_by'] = $user['id'];

        $id_data = $dt['influencer'];
        $detail = $this->mymodel->selectWithQuery("SELECT *
        FROM influencer WHERE id = '$id_data'");
        $detail = $detail[0];
        $dt['nama_creator'] = strval($detail['username']);


        if ($dt['status_endorse'] == "Barang Dikirim" && $dt['status_endorse'] != $_POST['status_endorse_existing']) {
            $dt['barang_dikirim_at'] = DATE("Y-m-d H:i:s");
        }

        if ($dt['link_upload']) {
            $dt['status_endorse'] = 'Posted Content';
        }

        if ($_FILES['file']['name']) {
            $input = $this->validate([
                'file' => [
                    'uploaded[file]',
                    'mime_in[file,image/jpg,image/jpeg,image/png]',
                    'max_size[file,1024]',
                ]
            ]);

            if (!$input) {
                $msg = 'Pastikan tipe file .jpg, .jpeg atau .png!';
                echo $this->template->alert_danger($msg);
                die;
            } else {
                $img = $this->request->getFile('file');
                $dir = str_replace('public/', '', FCPATH . 'assets/img/endorse/');
                $img->move($dir);
                $data = [
                    'name' =>  $img->getName(),
                    'type'  => $img->getClientMimeType()
                ];
                $currentFileName = $dir . $data['name'];
                $newfile = $id . '.' . substr(strrchr($data['name'], "."), 1);
                $newFileName = $dir . $newfile;
                rename($currentFileName, $newFileName);
                $dt['img'] = $newfile;
            }
        }
        $dt['updated_at'] = DATE("Y-m-d H:i:s");

        if ($this->db->update('endorse', $dt, array('id' => $id))) {
            $id_parent = $id_campaign;
            $this->update_endorse_parent($id_parent);

            $msg = 'Update data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Update data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }



    public function create()
    {
        $data['data'] = array();

        $data['detail']['id'] = $_GET['id'];
        // print_r($_GET);

        $data['pic'] = $this->mymodel->selectWithQuery("SELECT * FROM user ORDER BY full_name ASC");
        $data['brand'] = $this->mymodel->selectWithQuery("SELECT * FROM brand ORDER BY code ASC");
        $data['influencer'] = $this->mymodel->selectWithQuery("SELECT * FROM influencer ORDER BY full_name ASC");


        $this->load->view("endorse/create", $data);
    }


    public function store()
    {

        $user = $_SESSION['user'];

        $id = $_POST['id'];
        $id_campaign = $_POST['id_campaign'];
        $dt = $_POST['dt'];
        $dt['created_at'] = DATE("Y-m-d H:i:s");
        $dt['created_by'] = $user['id'];

        $id_data = $dt['influencer'];
        $detail = $this->mymodel->selectWithQuery("SELECT *
        FROM influencer WHERE id = '$id_data'");
        $detail = $detail[0];
        $dt['nama_creator'] = strval($detail['username']);

        if ($dt['status_endorse'] == "Barang Dikirim" && $dt['status_endorse'] != $_POST['status_endorse_existing']) {
            $dt['barang_dikirim_at'] = DATE("Y-m-d H:i:s");
        }

        if ($dt['link_upload']) {
            $dt['status_endorse'] = 'Posted Content';
        }

        if ($_FILES['file']['name']) {
            $input = $this->validate([
                'file' => [
                    'uploaded[file]',
                    'mime_in[file,image/jpg,image/jpeg,image/png]',
                    'max_size[file,1024]',
                ]
            ]);

            if (!$input) {
                $msg = 'Pastikan tipe file .jpg, .jpeg atau .png!';
                echo $this->template->alert_danger($msg);
                die;
            } else {
                $img = $this->request->getFile('file');
                $dir = str_replace('public/', '', FCPATH . 'assets/img/endorse/');
                $img->move($dir);
                $data = [
                    'name' =>  $img->getName(),
                    'type'  => $img->getClientMimeType()
                ];
                $currentFileName = $dir . $data['name'];
                $newfile = DATE('Ymdhis') . '.' . substr(strrchr($data['name'], "."), 1);
                $newFileName = $dir . $newfile;
                rename($currentFileName, $newFileName);
                $dt['img'] = $newfile;
            }
        }


        if ($this->db->insert('endorse', $dt)) {
            $id_parent = $id_campaign;
            $this->update_endorse_parent($id_parent);
            $msg = 'Tambah data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Tambah data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }
    public function remove()
    {
        $id = $_GET['id'];
        $data['data']['id'] = $id;
        $this->load->view("endorse/delete", $data);
    }

    public function delete()
    {

        $id = $_POST['id'];


        if ($this->db->delete('endorse', array('id' => $id))) {
            $msg = 'Hapus data berhasil!';
            echo $this->template->alert_success($msg);
        } else {
            $msg = 'Hapus data tidak berhasil!';
            echo $this->template->alert_danger($msg);
        }
    }

    public function action()
    {
        $data['id_campaign'] = $_GET['id_campaign'];

        $id_selected_v2 = $_POST['id_selected_v2'];
        $id_selected = $_POST['id_selected'];
        if ($id_selected) {
            $id = explode(',', $id_selected);
        }

        $is_manual = $_POST['is_manual'];
        $marketplace = $_POST['marketplace'];
        $brand = $_POST['brand'];
        $order_id = $_POST['order_id'];
        $code = $_GET['code'];
        $data['data']['id'] = $id;
        $data['data']['code'] = $code;
        if ($code == "hapus_data") {
            $data['question'] = "Apakah kamu yakin ingin menghapus data endorse ini?";
            $data['btn'] = "Hapus Data";
        } else if ($code == "refresh_data") {
            $data['question'] = "Apakah kamu yakin ingin merefresh data endorse ini?";
            $data['btn'] = "Refresh Data";
        } else if ($code == "ubah_status") {
            $data['question'] = "Apakah kamu yakin ingin mengubah status data endorse ini?";
            $data['btn'] = "Ubah Status Konten";
        } else if ($code == "ubah_status_data") {
            $data['question'] = "Apakah kamu yakin ingin mengubah status data ini?";
            $data['btn'] = "Ubah Status";
        }
        $this->load->view("endorse/action", $data);
    }

    public function action_process()
    {
        $list_id = "";
        $code = $_POST['code'];
        $user = $_SESSION['user'];

        $id_selected = $_POST['id_selected'];
        if ($id_selected) {
            $id = explode(',', $id_selected);
        }
        $is_manual = $_POST['is_manual'];
        $marketplace = $_POST['marketplace'];
        $brand = $_POST['brand'];
        $order_id = $_POST['order_id'];
        if ($code == "hapus_data") {
            foreach ($id as $k => $v) {
                $list_id .= "'" . $v . "',";
            }

            $list_id = substr($list_id, 0, -1);

            if ($list_id) {
                $dt = array();
                $this->db->delete('endorse', "id IN ($list_id)");
                $msg = 'Hapus data berhasil!';
                echo $this->template->alert_success($msg);
            } else {
                $msg = 'Pastikan kamu sudah memilih minimal 1 data!';
                echo $this->template->alert_danger($msg);
            }
        } else if ($code == "refresh_data") {
            foreach ($id as $k => $v) {
                if ($v > 0) {
                    $list_id .= "" . $v . ",";
                }
            }
            $list_id = substr($list_id, 0, -1);
            if ($list_id) {
                $id_campaign = $_POST['id_campaign'];
                $url = base_url() . '/endorse/sync-all-process?id_campaign=' . $id_campaign . '&mode=refresh_data&ids=' . $list_id;
                $curl = curl_init();

                // echo '<br>';

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_HTTPHEADER => array(
                        'Content-Type: application/json'
                    ),
                ));

                $response = curl_exec($curl);
                echo $response;
                die;
                // $response = json_decode($response,true);
                curl_close($curl);
            } else {
                $msg = 'Pastikan kamu sudah memilih minimal 1 data!';
                echo $this->template->alert_danger($msg);
            }
        } else if ($code == "ubah_status") {
            $status = $_POST['status'];
            foreach ($id as $k => $v) {
                if ($v > 0) {
                    $list_id .= "" . $v . ",";
                }
            }
            $list_id = substr($list_id, 0, -1);
            if ($list_id) {
                $dtt = array();
                $dtt['status_endorse'] = $status;
                $dtt['updated_at'] = DATE("Y-m-d H:i:s");
                $this->db->update('endorse', $dtt, "id IN ($list_id)");

                $msg = 'Ubah status endorse berhasil!';
                echo $this->template->alert_success($msg);
            } else {
                $msg = 'Pastikan kamu sudah memilih minimal 1 data!';
                echo $this->template->alert_danger($msg);
            }
        } else if ($code == "ubah_status") {
            $status = $_POST['status'];
            foreach ($id as $k => $v) {
                if ($v > 0) {
                    $list_id .= "" . $v . ",";
                }
            }
            $list_id = substr($list_id, 0, -1);
            if ($list_id) {
                $dtt = array();
                $dtt['status'] = $status;
                $dtt['updated_at'] = DATE("Y-m-d H:i:s");
                $this->db->update('endorse', $dtt, "id IN ($list_id)");

                $msg = 'Ubah status berhasil!';
                echo $this->template->alert_success($msg);
            } else {
                $msg = 'Pastikan kamu sudah memilih minimal 1 data!';
                echo $this->template->alert_danger($msg);
            }
        }
    }
}
