<?php
if (!$_SESSION['is_login']) {
  redirect(base_url() . 'auth/login');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title><?= $title ?></title>
  <meta name="description" content="We are Building Legacy, that Impactfull to the Society">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="<?= base_url() ?>assets/css/bootstrap-datepicker.min.css">
  <!-- Include jQuery -->
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script> -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <!-- <script src="<?= base_url() ?>assets/js/bootstrap-datepicker.min.js"></script> -->

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
  <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script> -->


  <link rel="shortcut icon" type="image/png" href="<?= base_url() ?>assets/img/fav.png">

  <link rel="stylesheet" href="<?= base_url() ?>assets/css/style.css?v=1.0.1" type="text/css" media="screen" />

  <?php
  if ($data[0]['img']) {
    $img = base_url() . '/assets/webfile/home/' . $data[0]['img'];
  } else {
    $img = base_url() . '/assets/img/logo.png';
  }
  $img = base_url() . '/assets/img/fav.png';
  ?>
  <meta property="og:image" content="<?= $img ?>" />
  <meta property="og:image:width" content="1000" />
  <meta property="og:image:height" content="1000" />

  <link rel="stylesheet" href="https://icons.getbootstrap.com/assets/font/bootstrap-icons.css">
  <link href="https://pictogrammers.github.io/@mdi/font/2.0.46/css/materialdesignicons.min.css" media="all" rel="stylesheet" type="text/css" />


  <!-- <script src="https://cdn.jsdelivr.net/npm/chart.js@3.3.2/dist/chart.min.js"></script> -->
  <script src="<?= base_url() ?>assets/chart/chart.js"></script>
  <script src="<?= base_url() ?>assets/chart/gauge.min.js"></script>

  <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>

  <link rel="stylesheet" href="<?= base_url() ?>assets/toast/jquery.toast.css">
  <script src="<?= base_url() ?>assets/toast/jquery.toast.js"></script>

  <link rel="stylesheet" href="https://owlcarousel2.github.io/OwlCarousel2/assets/owlcarousel/assets/owl.theme.default.min.css">
  <link rel="stylesheet" href="https://owlcarousel2.github.io/OwlCarousel2/assets/owlcarousel/assets/owl.carousel.min.css">
  <script src="https://owlcarousel2.github.io/OwlCarousel2/assets/owlcarousel/owl.carousel.js"></script>


  <link href='<?= base_url() ?>assets/fullcalendar/fullcalendar.min.css' rel='stylesheet' />
  <link href='<?= base_url() ?>assets/fullcalendar/fullcalendar.print.min.css' rel='stylesheet' media='print' />
  <script src='<?= base_url() ?>assets/fullcalendar/moment.min.js'></script>
  <script src='<?= base_url() ?>assets/fullcalendar/fullcalendar.min.js'></script>

  <style>
    #calendar {
      border-radius: 10px;
      /* padding:20px 15px; */
      max-width: 100%;
      margin: 0 auto;
      background: #FFF;
    }

    .fc-center h2 {
      font-size: 21px;
    }

    input[type="file"]::-webkit-file-upload-button {
      height: 45px;
    }

    .form-table-1 {
      border: unset;
      background: transparent;
      min-width: 100px !important;
    }

    .btn-action {
      font-size: 15px;
    }

    .btn-action {
      font-size: 11px;
      height: 32px;
      padding-top: 0px !important;
    }

    .content-body {
      padding: 32px;
      min-height: 101vh;
      background-color: #F2F2F2;
    }

    .box-legend {
      width: 7px !important;
      height: 7px !important;
      margin-right: 5px !important;
      margin-top: 4px !important;
    }

    .select2 {
      height: 45px !important;
      margin-top: 0px !important;
      margin-bottom: 10px !important;
      box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.07) !important;
      /* min-width: 100% !important; */
      /* max-width: 100% !important; */
      /* width: 100% !important; */
    }

    .select2-container .select2-selection--single {
      box-sizing: border-box;
      cursor: pointer;
      display: block;
      height: 45px !important;
      user-select: none;
      -webkit-user-select: none;
      border: 1px solid #ced4da;
      border-radius: 0.5rem !important;
    }


    .select2-container--default .select2-selection--single .select2-selection__rendered {
      color: #444;
      line-height: 45px !important;
    }

    .select2-container--default .select2-selection--single .select2-selection__arrow {
      height: 45px !important;
      position: absolute;
      top: 0px;
      right: 1px;
      width: 20px;
    }

    .floating-div {
      position: fixed;
      bottom: 10px;
      right: 30px;
      max-width: fit-content;
    }
  </style>


  <style>
    @supports (-webkit-appearance: none) or (-moz-appearance: none) {
      .checkbox-wrapper-13 input[type=checkbox] {
        --active: #275EFE;
        --active-inner: #fff;
        --focus: 2px rgba(39, 94, 254, .3);
        --border: #BBC1E1;
        --border-hover: #275EFE;
        --background: #fff;
        --disabled: #F6F8FF;
        --disabled-inner: #E1E6F9;
        -webkit-appearance: none;
        -moz-appearance: none;
        height: 21px;
        outline: none;
        display: inline-block;
        vertical-align: top;
        position: relative;
        margin: 0;
        cursor: pointer;
        border: 1px solid var(--bc, var(--border));
        background: var(--b, var(--background));
        transition: background 0.3s, border-color 0.3s, box-shadow 0.2s;
      }

      .checkbox-wrapper-13 input[type=checkbox]:after {
        content: "";
        display: block;
        left: 0;
        top: 0;
        position: absolute;
        transition: transform var(--d-t, 0.3s) var(--d-t-e, ease), opacity var(--d-o, 0.2s);
      }

      .checkbox-wrapper-13 input[type=checkbox]:checked {
        --b: var(--active);
        --bc: var(--active);
        --d-o: .3s;
        --d-t: .6s;
        --d-t-e: cubic-bezier(.2, .85, .32, 1.2);
      }

      .checkbox-wrapper-13 input[type=checkbox]:disabled {
        --b: var(--disabled);
        cursor: not-allowed;
        opacity: 0.9;
      }

      .checkbox-wrapper-13 input[type=checkbox]:disabled:checked {
        --b: var(--disabled-inner);
        --bc: var(--border);
      }

      .checkbox-wrapper-13 input[type=checkbox]:disabled+label {
        cursor: not-allowed;
      }

      .checkbox-wrapper-13 input[type=checkbox]:hover:not(:checked):not(:disabled) {
        --bc: var(--border-hover);
      }

      .checkbox-wrapper-13 input[type=checkbox]:focus {
        box-shadow: 0 0 0 var(--focus);
      }

      .checkbox-wrapper-13 input[type=checkbox]:not(.switch) {
        width: 21px;
      }

      .checkbox-wrapper-13 input[type=checkbox]:not(.switch):after {
        opacity: var(--o, 0);
      }

      .checkbox-wrapper-13 input[type=checkbox]:not(.switch):checked {
        --o: 1;
      }

      .checkbox-wrapper-13 input[type=checkbox]+label {
        display: inline-block;
        vertical-align: middle;
        cursor: pointer;
        margin-left: 2px;
      }

      .checkbox-wrapper-13 input[type=checkbox]:not(.switch) {
        border-radius: 7px;
      }

      .checkbox-wrapper-13 input[type=checkbox]:not(.switch):after {
        width: 5px;
        height: 9px;
        border: 2px solid var(--active-inner);
        border-top: 0;
        border-left: 0;
        left: 7px;
        top: 4px;
        transform: rotate(var(--r, 20deg));
      }

      .checkbox-wrapper-13 input[type=checkbox]:not(.switch):checked {
        --r: 43deg;
      }
    }

    .checkbox-wrapper-13 * {
      box-sizing: inherit;
    }

    .checkbox-wrapper-13 *:before,
    .checkbox-wrapper-13 *:after {
      box-sizing: inherit;
    }

    .d-inline {
      display: inline;
    }
  </style>

  <style>
    .box-main {
      border: 1px #ced4da solid;
      padding: 16px;
      background: #FFF;
      border-radius: 12px;
      margin-bottom: 10px;
    }

    .card {
      border-radius: 12px;
      border: #FFF 1px solid;
      padding: 10px;
    }

    /* input[readonly] {
      background-color: rgba(0, 0, 0, 0.05);
    } */

    /* .modal-dialog {
        min-height: 100vh;
    } */


    .bg-b {
      background: #ebf6f6;
    }

    .bg-o {
      background: #ffe8e7;
    }

    .sidebar,
    .img-logo {
      z-index: 100 !important;
    }

    .td-breakline {
      word-wrap: break-word;
    }

    .tr-search td {
      padding-top: 20px !important;
      padding-bottom: 20px !important;
    }

    .summary th {
      font-size: 12px !important;
      padding: 5px !important;
    }

    .summary td {
      font-size: 12px !important;
      padding: 5px !important;
    }

    .summary table tr:first-child th:first-child {
      font-size: 12px !important;
      padding: 5px !important;
    }

    .summary table tr:first-child th:last-child {
      font-size: 12px !important;
      padding: 5px !important;
    }

    .dropdown-items {
      display: block;
      width: 100%;
      padding: 0px;
      clear: both;
      font-weight: 400;
      color: var(--bs-dropdown-link-color);
      text-align: inherit;
      text-decoration: none;
      white-space: nowrap;
      background-color: transparent;
      border: 0;
    }

    .w-100 {
      width: 100% !important;
    }

    .select2-container {
      width: 100% !important;
    }

    /* width */
    ::-webkit-scrollbar {
      width: 9px !important;
      height: 5px;
    }

    /* Track */
    ::-webkit-scrollbar-track {
      background: #f1f1f1;
    }
  </style>

  <style>
    .btn-copy {
      background: #c2b5071a;
      border-color: #c2b507;
    }

    .btn-copy:hover {
      background: #c2b507;
      border-color: #c2b507;
      color: #fff !important;
    }
  </style>



</head>

<body>

  <nav class="sidebar offcanvas-md offcanvas-start <?php if ($_SESSION['minimize_sidebar']) {
                                                      echo 'active';
                                                    } ?>" data-bs-scroll="true" data-bs-backdrop="false">
    <div class="d-flex justify-content-end m-3 d-block d-md-none">
      <button aria-label="Close" data-bs-dismiss="offcanvas" data-bs-target=".sidebar" class="btn p-0 border-0 fs-4" style="background:transparent!important;color:#fff!important">
        <i class="fa fa-close"></i>
      </button>
    </div>
    <div class="d-flex mb-3 img-logo" style="padding-left:15px;padding-top:20px;padding-bottom:20px;position:sticky!important;top:0;background:#FFF;z-index:100;
    z-index: 100;box-shadow: 4px 4px 4px #adb5bd1A;">
      <a href="<?= base_url() ?>">
        <img src="<?= base_url() ?>assets/img/logo-sidebar-v5.png" alt="Logo" style="width:214px;padding-left:10px" />
      </a>
    </div>
    <!-- <div class="d-flex justify-content-start mb-3">
        <h1 class="sidebar-title text-white">DNX1SCREEN</h1>
      </div> -->
    <?php
    $uri_1  = $this->uri->segment(1);
    $uri_2  = $this->uri->segment(2);
    if ($uri_1 == 'dashboard') {
      $menu_dashboard = 'active';
    } else if ($uri_1 == 'report') {
      $menu_report = 'active';
    } else if ($uri_1 == 'transaction') {
      $menu_transaction = 'active';
    } else if ($uri_1 == 'stock') {
      $menu_stock = 'active';
    } else if ($uri_1 == 'crm' && $_GET['brand'] == 'MG' || $customer['brand'] == 'MG') {
      $menu_crm_mg = 'active';
    } else if ($uri_1 == 'crm' && $_GET['brand'] == 'POME' || $customer['brand'] == 'POME') {
      $menu_crm_pome = 'active';
    } else if ($uri_1 == 'endorse-campaign' || $uri_1 == 'endorse') {
      $menu_endorse_campaign = 'active';
    } else if ($uri_1 == 'expense') {
      $menu_expense = 'active';
    } else if ($uri_1 == 'influencer') {
      $menu_influencer = 'active';
    } else if ($uri_1 == 'product') {
      $menu_product = 'active';
    } else if ($uri_1 == 'product-3rd') {
      $menu_product_3rd = 'active';
    } else if ($uri_1 == 'discount') {
      $menu_discount = 'active';
    } else if ($uri_1 == 'marketplace') {
      $menu_marketplace = 'active';
    } else if ($uri_1 == 'marketplace-account') {
      $menu_marketplace_account = 'active';
    } else if ($uri_1 == 'shipping') {
      $menu_shipping = 'active';
    } else if ($uri_1 == 'label') {
      $menu_label = 'active';
    } else if ($uri_1 == 'group-wa') {
      $menu_group = 'active';
    } else if ($uri_1 == 'profile') {
      $menu_profile = 'active';
    } else if ($uri_1 == 'user') {
      $menu_user = 'active';
    } else if ($uri_1 == 'material') {
      $menu_material = 'active';
    } else if ($uri_1 == 'digger') {
      $menu_digger = 'active';
    } else if ($uri_1 == 'layer') {
      $menu_layer = 'active';
    } else if ($uri_1 == 'master-plan') {
      $menu_master_plan = 'active';
    } else if ($uri_1 == 'pricelist-kurs-idr') {
      $menu_kurs = 'active';
    } else if ($uri_1 == 'pricelist-product') {
      $menu_pricelist_product = 'active';
    } else if ($uri_1 == 'pricelist-ammonium-nitrate') {
      $menu_pricelist_ammonium = 'active';
    } else if ($uri_1 == 'rate') {
      $menu_rate = 'active';
    } else if ($uri_1 == 'equipment') {
      $menu_equipment = 'active';
    } else if ($uri_1 == 'site') {
      $menu_site = 'active';
    } else if ($uri_1 == 'customer') {
      $menu_customer = 'active';
    } else if ($uri_1 == 'customer-location') {
      $menu_customer_location = 'active';
    } else if ($uri_1 == 'loading-sheet') {
      $menu_loading_sheet = 'active';
    } else {
      $menu_dashboard = 'active';
    }
    ?>
    <div class="pt-0 d-flex flex-column gap-5">
      <div class="menu p-0">
        <a href="<?= base_url() ?>dashboard" class="item-menu <?= $menu_dashboard ?>">
          <i class="icon bi bi-house"></i>
          DASHBOARD
        </a>
        <a href="<?= base_url() ?>report" class="item-menu <?= $menu_report ?>">
          <i class="icon bi bi-graph-up-arrow"></i>
          REPORT
        </a>

        <?php if (in_array($_SESSION['user']['role'], array('1', '2'))) { ?>
          <a href="<?= base_url() ?>expense" class="item-menu <?= $menu_expense ?>">
            <i class="icon bi bi-credit-card"></i>
            PENGELUARAN
          </a>
        <?php } ?>
        <?php if (!in_array($_SESSION['user']['role'], array('3', '6'))) { ?>
          <p class="text-white pt-4">MARKETING</p>
        <?php } ?>
        <?php if (!in_array($_SESSION['user']['role'], array('3', '6'))) { ?>
          <a href="<?= base_url() ?>endorse-campaign" class="item-menu <?= $menu_endorse_campaign ?>">
            <i class="icon bi bi-person-video2"></i>
            ENDORSE CAMPAIGN
          </a>
        <?php } ?>
        <?php if (!in_array($_SESSION['user']['role'], array('3', '6'))) { ?>
          <a href="<?= base_url() ?>influencer" class="item-menu <?= $menu_influencer ?>">
            <i class="icon bi bi-person-bounding-box"></i>
            INFLUENCER
          </a>
        <?php } ?>

        <p class="text-white pt-4">ORDER & CUSTOMER</p>

        <a href="<?= base_url() ?>marketplace-account" class="item-menu <?= $menu_marketplace_account ?>">
          <i class="icon bi bi-houses"></i>
          TOKO
        </a>

        <a href="<?= base_url() ?>transaction" class="item-menu <?= $menu_transaction ?>">
          <i class="icon bi bi-handbag"></i>
          ORDER
        </a>

        <?php if (!in_array($_SESSION['user']['role'], array('5'))) { ?>
          <a href="<?= base_url() ?>crm?brand=MG" class="item-menu <?= $menu_crm_mg ?>">
            <i class="icon bi bi-person-heart"></i>
            CRM MG
          </a>
        <?php } ?>
        <?php if (!in_array($_SESSION['user']['role'], array('5'))) { ?>
          <a href="<?= base_url() ?>crm?brand=POME" class="item-menu <?= $menu_crm_pome ?>">
            <i class="icon bi bi-person-heart"></i>
            CRM POME
          </a>
        <?php } ?>
        <?php if (!in_array($_SESSION['user']['role'], array('5'))) { ?>
          <a href="<?= base_url() ?>group-wa" class="item-menu <?= $menu_group ?>">
            <i class="icon bi bi-whatsapp"></i>
            GRUP WA
          </a>
        <?php } ?>

      </div>

      <div class="menu">
        <p class="text-white">OPERASIONAL</p>

        <?php if (!in_array($_SESSION['user']['role'], array('5', '3'))) { ?>
          <a href="<?= base_url() ?>stock" class="item-menu <?= $menu_stock
                                                            ?>">
            <i class="icon bi bi-arrow-left-right"></i>
            STOK
          </a>
        <?php } ?>
        <a href="<?= base_url() ?>product" class="item-menu <?= $menu_product ?>">
          <i class="icon bi bi-box"></i>
          PRODUK
        </a>
        <?php if (!in_array($_SESSION['user']['role'], array('5', '3'))) { ?>
          <a href="<?= base_url() ?>product-3rd" class="item-menu <?= $menu_product_3rd ?>">
            <i class="icon bi bi-box-seam"></i>
            KONFIGURASI PRODUK
          </a>
        <?php } ?>
        <?php if (!in_array($_SESSION['user']['role'], array('5'))) { ?>
          <a href="<?= base_url() ?>marketplace" class="item-menu <?= $menu_marketplace ?>">
            <i class="icon bi bi-shop"></i>
            CHANNEL
          </a>
        <?php } ?>
        <?php if (!in_array($_SESSION['user']['role'], array('5'))) { ?>
          <a href="<?= base_url() ?>shipping" class="item-menu <?= $menu_shipping ?>">
            <i class="icon bi bi-truck"></i>
            EKSPEDISI
          </a>
        <?php } ?>

      </div>

      <div class="menu">
        <p class="text-white">AKUN</p>
        <?php if (in_array($_SESSION['user']['role'], array('1', '2'))) { ?>
          <a href="<?= base_url() ?>user" class="item-menu <?= $menu_user ?>">
            <i class="icon bi bi-person-vcard"></i>
            USER
          </a>
        <?php } ?>
        <a href="<?= base_url() ?>profile" class="item-menu <?= $menu_profile ?>">
          <i class="icon bi bi-person-circle"></i>
          AKUN SAYA
        </a>
        <a href="<?= base_url() ?>auth/logout-process" class="item-menu">
          <i class="icon bi bi-door-open"></i>
          KELUAR
        </a>
      </div>
    </div>
  </nav>

  <?php
  $style_1 = '';
  $style_2 = '';
  $style_3 = '';
  ?>

  <!-- Main Content -->
  <main class="content div-dashboard <?php if ($_SESSION['minimize_sidebar']) {
                                        echo 'active';
                                      } ?>">

    <nav class="navbar navbar-expand-lg" style="top: 0;
    position: sticky;
    background: #FFF;
    padding: 10px 30px;
    z-index: 100;box-shadow: 4px 4px 4px #adb5bd1A;
">
      <div class="container-fluid" style="padding-right: 0px; padding-left: 0px;">
        <div class="avatar-icon">
          <button class="sidebarCollapseDefault btn p-0 border-0 d-none d-md-block mt-0 mb-0" aria-label="Hamburger Button" style="padding-top:0px!important;">
            <i class="mdi menu-sidebar mdi-menu"></i>
          </button>
          <button data-bs-toggle="offcanvas" data-bs-target=".sidebar" aria-controls="sidebar" aria-label="Hamburger Button" class="sidebarCollapseMobile btn p-0 border-0 d-block d-md-none" style="padding-top:0px!important;">
            <i class="mdi menu-sidebar mdi-menu"></i>
          </button>
        </div>
        <div class="d-flex align-items-center justify-content-end gap-4">

          <a href="<?= base_url() ?>profile">
            <?php
            $img = $_SESSION['user']['img'];
            if ($img == "") {
              $img = base_url() . '/assets/img/user/default.png';
            } else {
              $img = base_url() . '/assets/img/user/' . $img . '?token=' . DATE("Ymdhis", strtotime($_SESSION['user']['updated_at']));
            }
            ?>
            <img src="<?= $img ?>" class="avatar">
          </a>
        </div>
      </div>
    </nav>

    <div class="content-body">

      <div class="w-100 pt-0 pb-5">
        <?= $content ?>
      </div>
    </div>
    <!-- <footer>
        <div class="row">
          <div class="col-lg-6 text-center text-lg-start">
            <p class="mb-0">Copyright <a class="a-green" href="https://karyastudio.com" target="_blank">Karya Studio Teknologi Digital</a> &#169; 2022</p>
          </div>
          <div class="col-lg-6 text-center text-lg-end">
            <p class="mb-0">PT Kargo Maritim Indonesia V.1.0.1</p>
          </div>
        </div>
      </footer> -->
  </main>

  <style>
    .select2-container--open .select2-dropdown {
      z-index: 10000 !important;
    }

    .h-100 {
      height: 100%;
    }

    .divIcon {
      width: 55px;
      height: 55px;
      border-radius: 10px;
      object-fit: cover;
    }
  </style>
  <script>
    $('.select2').select2();
  </script>

  <script>
    $(document).ready(function() {
      $('.sidebarCollapseDefault').on('click', function() {
        $('.sidebar').toggleClass('active');
        $('.content').toggleClass('active');
        $.ajax({
          dataType: "json",
          url: '<?= base_url() ?>ajax/minimize-sidebar',
          success: function(html) {}
        });
      });
    });

    function func_pass_1() {
      var x = document.getElementById("password_1");
      var show_eye_1 = document.getElementById("show_eye_1");
      var hide_eye_1 = document.getElementById("hide_eye_1");
      hide_eye_1.classList.remove("d-none");
      if (x.type === "password") {
        x.type = "text";
        show_eye_1.style.display = "none";
        hide_eye_1.style.display = "block";
      } else {
        x.type = "password";
        show_eye_1.style.display = "block";
        hide_eye_1.style.display = "none";
      }
    }

    function func_pass_2() {
      var y = document.getElementById("password_2");
      var show_eye_2 = document.getElementById("show_eye_2");
      var hide_eye_2 = document.getElementById("hide_eye_2");
      hide_eye_2.classList.remove("d-none");
      if (y.type === "password") {
        y.type = "text";
        show_eye_2.style.display = "none";
        hide_eye_2.style.display = "block";
      } else {
        y.type = "password";
        show_eye_2.style.display = "block";
        hide_eye_2.style.display = "none";
      }
    }

    function func_pass_3() {
      var z = document.getElementById("password_3");
      var show_eye_3 = document.getElementById("show_eye_3");
      var hide_eye_3 = document.getElementById("hide_eye_3");
      hide_eye_3.classList.remove("d-none");
      if (z.type === "password") {
        z.type = "text";
        show_eye_3.style.display = "none";
        hide_eye_3.style.display = "block";
      } else {
        z.type = "password";
        show_eye_3.style.display = "block";
        hide_eye_3.style.display = "none";
      }
    }
    // $(document).ready(function() {
    //   $('#datatable').DataTable({
    //     // scrollX: true,
    //     // "ordering": false,
    //     // columnDefs: [ {
    //     //   targets: 0,
    //     //   orderable: true
    //     // } ]


    //   });
    // });


    // select();

    // function select() {
    //   $(document).ready(function() {
    //     $('.select').select2();
    //   });
    // }

    select2_product();

    function select2_product() {
      $(document).ready(function() {
        $('#select2-product').select2();
      });
    }

    select2();

    function select2() {
      $(document).ready(function() {
        $('#select2').select2();
      });
    }


    function select3() {
      $(document).ready(function() {
        $('#select3').select2();
      });
    }

    // select3();

    // function select3() {
    //   $(document).ready(function() {
    //     $('.form-table-select2').select2();
    //   });
    // }



    select_5();

    function select_5() {
      $(document).ready(function() {
        $('.select-5').select2();
      });
    }


    function copy(id) {
      // Get the text field
      var copyText = document.getElementById("box-order-id-" + id);

      // Select the text field
      copyText.select();
      copyText.setSelectionRange(0, 99999); // For mobile devices

      // Copy the text inside the text field
      navigator.clipboard.writeText(copyText.value);

      // Alert the copied text
      // alert("Copied the text: " + );
      $(document).ready(function() {
        $.toast({
          heading: "Informasi",
          text: "Kode order <b>" + copyText.value + "</b> berhasil disalin!",
          showHideTransition: "slide",
          icon: "success",
          position: "top-right",
          loaderBg: "#def7f0",
          hideAfter: 2500,
        });
      });
    }

    $(document).ready(function() {
      $(".checkAll").click(function() {
        $(".checkItem").prop('checked', $(this).prop('checked'));
        get_id();
      });
    });
  </script>
  <script>
    var refreshTime = 180000; // every 3 minutes in milliseconds
    $(document).ready(function() {
      setInterval(sessionCheck, refreshTime);
    });

    function sessionCheck() {
      $.ajax({
        cache: false,
        type: "GET",
        url: "<?= base_url() ?>ajax/refresh-token",
        success: function(data) {
          console.log("Refresh token");
        }
      });
    }
  </script>
</body>

</html>