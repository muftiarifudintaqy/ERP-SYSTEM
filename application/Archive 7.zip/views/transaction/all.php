<?php

if ($_GET['start_date'] == "") {
    $start_date = DATE("Y-m-d");
    $start_date = DATE('Y-m-d', strtotime($today . " -30 days"));
} else {
    $start_date = $_GET['start_date'];
}
if ($_GET['until_date'] == "") {
    $until_date = DATE("Y-m-d");
} else {
    $until_date = $_GET['until_date'];
}
?>
<div class="form-message"></div>
<div class="w-100">
    <div class="row align-items-center">
        <div class="col-lg-12 mb-3">
            <h3 class="text-primary fw-600">ORDER</h3>
        </div>
        <div class="col-lg-12">
            <form action="">
                <div class="row">

                    <div class="col-md-12">
                        <?php

                        $arr_val = array();
                        $arr_val[] = '';
                        $arr_val[] = 'ACTIVE';
                        $arr_val[] = 'UNPAID';
                        // $arr_val[] = 'PENDING';
                        $arr_val[] = 'READY_TO_SHIP';
                        $arr_val[] = 'PROCESSED';
                        $arr_val[] = 'SHIPPED';
                        $arr_val[] = 'DELIVERED';
                        $arr_val[] = 'COMPLETED';
                        $arr_val[] = 'CANCELLED';
                        $arr_val[] = 'RETURN';
                        $arr_val[] = 'REFUND';
                        $arr_val[] = 'WEBHOOK';

                        $arr = array();
                        $arr[] = 'Semua Order';
                        $arr[] = 'Order Aktif';
                        $arr[] = 'Belum Bayar';
                        // $arr[] = 'Order Menunggu Diproses';
                        $arr[] = 'Menunggu Diproses';
                        $arr[] = 'Diproses';
                        $arr[] = 'Pengiriman';
                        $arr[] = 'Diterima';
                        $arr[] = 'Selesai';
                        $arr[] = 'Dibatalkan';
                        $arr[] = 'Return';
                        $arr[] = 'Refund';
                        $arr[] = 'Webhook';
                        foreach ($arr_val as $k => $val) {
                            $class = "btn-default";
                            $class_2 = "dot";
                            if ($_GET['order_status'] == $val) {
                                $class = "btn-default-selected";
                                $class_2 = "dot-active";
                            }
                        ?>
                            <a href="<?= $url_1 ?>&order_status=<?= $val ?>" class="btn mb-2 <?= $class ?> mb-2 me-2"><span class="<?= $class_2 ?>"></span> <?= $arr[$k] ?></a>
                        <?php }  ?>

                        <?php

                        $arr_val = array();
                        $arr_val[] = '';
                        $arr_val[] = 'ACTIVE';
                        $arr_val[] = 'UNPAID';
                        // $arr_val[] = 'PENDING';
                        $arr_val[] = 'READY_TO_SHIP';
                        $arr_val[] = 'PROCESSED';
                        $arr_val[] = 'SHIPPED';
                        $arr_val[] = 'DELIVERED';
                        $arr_val[] = 'COMPLETED';
                        $arr_val[] = 'CANCELLED';
                        $arr_val[] = 'RETURN';
                        $arr_val[] = 'REFUND';
                        $arr_val[] = 'WEBHOOK';

                        $arr = array();
                        $arr[] = 'Semua Tipe';
                        $arr[] = 'Manual';
                        $arr[] = 'Marketplace';

                        $arr_val = array();
                        $arr_val[] = '';
                        $arr_val[] = 'Manual';
                        $arr_val[] = 'Marketplace';
                        foreach ($arr_val as $k => $val) {
                            $class = "btn-default";
                            $class_2 = "dot";
                            if ($_GET['order_type'] == $val) {
                                $class = "btn-default-selected";
                                $class_2 = "dot-active";
                            }
                        ?>
                            <a href="<?= $url_3 ?>&order_type=<?= $val ?>" class="btn mb-2 <?= $class ?> mb-2 me-2"><span class="<?= $class_2 ?>"></span> <?= $arr[$k] ?></a>
                        <?php }  ?>

                    </div>

                    <div class="col-lg-3">
                        <div class="input-group">
                            <button class="btn mb-2 btn-outline-secondary-category dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="border-top-right-radius: 0px !important;
                            border-bottom-right-radius: 0px !important;"><?= $keyword_category ?></button>
                            <ul class="dropdown-menu">
                                <?php
                                $arr = array();
                                $arr[] = 'Order ID';
                                $arr[] = 'Username';
                                $arr[] = 'Nama Pelanggan';
                                $arr[] = 'Nomor Pelanggan';
                                $arr[] = 'Nomor Resi';
                                $arr[] = 'Nama Produk';
                                foreach ($arr as $k => $val) {
                                    $class = "btn-default";
                                    if ($_GET['order_status'] == $val) {
                                        $class = "btn-default-selected";
                                    }
                                ?>
                                    <li><a class="dropdown-item" href="<?= $url_2 ?>&keyword_category=<?= $val ?>"><?= $val ?></a></li>
                                <?php }  ?>
                            </ul>
                            <input type="hidden" name="ids" value="<?= $ids ?>">
                            <input type="hidden" name="keyword_category" value="<?= $keyword_category ?>">
                            <input type="hidden" name="order_status" value="<?= $_GET['order_status'] ?>">
                            <input type="text" name="keyword" class="form-control" value="<?= $_GET['keyword'] ?>" style="border-top-left-radius: 0px !important;
                            border-bottom-left-radius: 0px !important;">
                        </div>
                    </div>

                    <div class="col-lg-9 text-lg-end text-start">
                        <a href="#!" onclick="sync_data('<?= $start_date ?>','<?= $until_date ?>')" class="btn mb-2 btn-edit px-2 mt-0 ms-1"><i class="bi bi-cloud-download fs-16"></i> Sync Data</a>
                        <a href="#!" onclick="download_file()" class="btn mb-2 btn-edit px-2 mt-0 ms-1"><i class="bi bi-download fs-16"></i> Download</a>
                        <a href="#!" onclick="import_data()" class="btn mb-2 btn-edit px-2 mt-0 ms-1"><i class="bi bi-cart2 fs-16"></i> Import Order</a>
                        <a href="#!" onclick="import_resi()" class="btn mb-2 btn-edit px-2 mt-0 ms-1"><i class="bi bi-truck fs-16"></i> Import Resi</a>
                        <a href="#!" onclick="import_customer()" class="btn mb-2 btn-edit px-2 mt-0 ms-1"><i class="bi bi-people fs-16"></i> Import Pelanggan</a>
                        <a href="<?= base_url() ?>/transaction/create" class="btn mb-2 btn-edit-active px-2 mt-0 ms-1"><i class="bi bi-plus-circle-dotted fs-16"></i> Buat Order</a>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="card">
                            <h3 class="mb-0 text-notif">Filter Order</h3>
                            <hr>

                            <div class="row">
                                <!-- <div class="col-md-1">
                                    <label for="">Brand</label>
                                    <select class="form-control select2" name="brand" id="brand">
                                        <option value="">-</option>
                                        <?php
                                        foreach ($brands as $val) :
                                            $text = '';
                                            if ($_GET['brand'] == $val['code']) {
                                                $text = 'selected';
                                            }
                                        ?>
                                            <option <?= $text ?> value="<?= $val['code'] ?>"><?= $val['code'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div> -->
                                <div class="col-md-2">
                                    <label for="">Toko</label>
                                    <select class="form-control" name="shop_id">
                                        <option value="">-</option>
                                        <?php
                                        foreach ($store as $val) :
                                            $text = '';
                                            if ($_GET['shop_id'] == $val['id']) {
                                                $text = 'selected';
                                            }
                                        ?>
                                            <option <?= $text ?> value="<?= $val['id'] ?>"><?= $val['opt'] ?> <?= ucwords(strtolower($val['marketplace'])) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label for="">Channel</label>
                                    <select class="form-control select2" name="marketplace">
                                        <option value="">-</option>
                                        <!-- <option <?php if ($_GET['marketplace'] == 'UNCATEGORIZED') {
                                                            echo 'selected';
                                                        } ?> value="UNCATEGORIZED">UNCATEGORIZED</option> -->
                                        <?php
                                        foreach ($marketplace as $val) :
                                            $text = '';
                                            if ($_GET['marketplace'] == $val['name']) {
                                                $text = 'selected';
                                            }
                                        ?>
                                            <option <?= $text ?> value="<?= $val['name'] ?>"><?= $val['name'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label for="">Ekspedisi</label>
                                    <select class="form-control select2" name="ekspedisi">
                                        <option value="">-</option>
                                        <?php
                                        foreach ($shipping as $val) :
                                            $text = '';
                                            if ($_GET['ekspedisi'] == $val['name']) {
                                                $text = 'selected';
                                            }
                                        ?>
                                            <option <?= $text ?> value="<?= $val['name'] ?>"><?= $val['name'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label for="">CS</label>
                                    <select class="form-control select2" name="cs">
                                        <option value="">-</option>
                                        <?php
                                        foreach ($cs as $val) :
                                            $text = '';
                                            if ($_GET['cs'] == $val['full_name']) {
                                                $text = 'selected';
                                            }
                                        ?>
                                            <option <?= $text ?> value="<?= $val['full_name'] ?>"><?= $val['full_name'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-1">
                                    <label for="">TF/COD</label>
                                    <select class="form-control select2" name="payment_type">
                                        <option value="">-</option>
                                        <?php
                                        $arr = array();
                                        $arr[] = "TF";
                                        $arr[] = "COD";
                                        foreach ($arr as $val) :
                                            $text = '';
                                            if ($_GET['payment_type'] == $val) {
                                                $text = 'selected';
                                            }
                                        ?>
                                            <option <?= $text ?> value="<?= $val ?>"><?= $val ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="">Tanggal Order</label>
                                    <div class="d-flex">
                                        <input type="date" name="start_date" class="form-control" value="<?= $start_date ?>" style="border-top-right-radius: 0px !important; border-bottom-right-radius: 0px !important; width:100%;">
                                        <input type="date" name="until_date" class="form-control" value="<?= $until_date ?>" style="border-top-left-radius: 0px !important; border-bottom-left-radius: 0px !important; width:100%;">
                                    </div>
                                </div>

                                <div class="col-md-2 text-lg-end text-start mb-2">
                                    <!-- <label for="">&nbsp;</label> -->
                                    <button class="btn mb-2 btn-edit-active w-100" type="submit">Cari Data</button>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 d-none">
                        <div class="row">
                            <div class="col-md-2">
                                <!-- <label for="">&nbsp;</label> -->
                                <button class="btn mb-2 btn-primary w-100 form-control" type="submit">FILTER DATA</button>
                            </div>
                            <div class="col-md-2">
                                <!-- <label for="">&nbsp;</label> -->
                                <a href="<?= base_url() ?>transaction/create?start_date=<?= $start_date ?>&until_date=<?= $until_date ?>&brand=<?= $brand ?>&marketplace=<?= $_GET['marketplace'] ?>&cs=<?= $_GET['cs'] ?>&keyword=<?= $_GET['keyword'] ?>" class="btn mb-2 btn-primary w-100 form-control">TAMBAH DATA</a>
                            </div>
                            <div class="col-md-2">
                                <!-- <label for="">&nbsp;</label> -->
                                <a href="#!" onclick="import_data('<?= $start_date ?>','<?= $until_date ?>')" class="btn mb-2 btn-primary w-100 form-control">IMPORT DATA</a>
                            </div>
                            <div class="col-md-2">
                                <!-- <label for="">&nbsp;</label> -->
                                <a href="#!" onclick="sync_data('<?= $start_date ?>','<?= $until_date ?>')" class="btn mb-2 btn-primary w-100 form-control">SYNC DATA</a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <?= $notif ?>
        </div>
    </div>

    <div class="col-lg-12 mb-3">
        <div class="checkbox-wrapper-13">
            <input id="c1-13" type="checkbox" value="1" class="checkAll">
            <label for="c1-13">Pilih Semua Data</label>
        </div>
    </div>

    <div class="col-lg-12">
        <div id="tbody">
            <?php $this->load->view('loading', true) ?>
        </div>
    </div>

    <?= $pagination ?>
</div>

<div class="floating-div">
    <button class="btn mb-2 btn-edit-active dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
        <i class="bi bi-gear fs-16"></i> Aksi
    </button>
    <ul class="dropdown-menu text-lg-end text-start" style="padding:0px;background:unset;border:unset">
        <li><a class="dropdown-items" href="#!" style="padding:0px">
                <button type="button" class="btn mb-2 btn-edit-active" data-bs-toggle="modal" data-bs-target="#modal-print">
                    <i class="bi bi-printer fs-16"></i> Print Data
                </button>
            </a></li>

        <li><a class="dropdown-items" href="#!" style="padding:0px;">
                <button type="button" class="btn mb-2 btn-edit-active" onclick="barang_diterima()">
                    <i class="bi bi-house-check fs-16"></i> Barang Diterima
                </button>
            </a></li>

        <li><a class="dropdown-items" href="#!" style="padding:0px;">
                <button type="button" class="btn mb-2 btn-edit-active" onclick="refresh_data()">
                    <i class="bi bi-bootstrap-reboot fs-16"></i> Refresh Data
                </button>
            </a></li>

        <li><a class="dropdown-items" href="#!" style="padding:0px;">
                <button type="button" class="btn mb-2 btn-edit-active" onclick="tampilkan_data()">
                    <i class="bi bi-eye fs-16"></i> Tampilkan Data
                </button>
            </a></li>

        <li><a class="dropdown-items" href="#!" style="padding:0px">
                <button type="button" class="btn mb-2 btn-edit-active" onclick="hapus_data()">
                    <i class="bi bi-trash fs-16"></i> Hapus Data
                </button>
            </a></li>

    </ul>

</div>


<div class="modal fade bd-example-modal-sm" tabindex="-1" varietas="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="modal-form">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="title-form"></h5>
                <a class="close a-link" data-bs-dismiss="modal"><i class="bi bi-x-circle fs-24"></i></a>
            </div>
            <div class="modal-body">
                <div id="load-form"></div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bd-example-modal-sm" tabindex="-1" varietas="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="modal-print">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Print Data</h5>
                <a class="close a-link" data-bs-dismiss="modal"><i class="bi bi-x-circle fs-24"></i></a>
            </div>
            <div class="modal-body">
                <p>Apakah kamu yakin ingin melakukan print data?</p>
                <form target="_blank" action="<?= base_url() ?>/transaction/print-v2" method="POST" id="form-action">
                    <button class="btn mb-2 btn-edit-active" type="submit"><i class="bi bi-printer fs-16"></i> Print Data</button>
                </form>
            </div>
        </div>
    </div>
</div>

<input type="hidden" id="id_selected" name="id_selected" form="form-action">

<script>
    var list_id_v2 = '';

    function get_id() {
        list_id_v2 = '';
        var selectedValues = [];
        $('input[name="list_id"]').each(function() {
            if ($(this).is(":checked")) {
                selectedValues.push($(this).val());
                list_id_v2 += $(this).val() + ',';
            } else {
                selectedValues.push('0');
            }
        });
        if (list_id_v2.length > 0) {
            list_id_v2 = list_id_v2.slice(0, -1); // Remove the trailing comma
        }
        $('#id_selected').val(selectedValues.join(','));
    }

    function remove(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Hapus Data');
        $("#load-form").load("<?= base_url() ?>transaction/remove?id=" + id);
    }

    function barang_diterima(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Barang Diterima');
        $("#load-form").load("<?= base_url() ?>transaction/action?code=barang_diterima&id=" + id);
    }

    function tampilkan_data(id) {
        window.location.href = "<?= base_url() ?>/transaction?ids=" + list_id_v2;
    }

    function hapus_data(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Hapus Data');
        $("#load-form").load("<?= base_url() ?>transaction/action?code=hapus_data&id=" + id);
    }

    function refresh_data(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Refresh Data');
        $("#load-form").load("<?= base_url() ?>transaction/action?code=refresh_data&id=" + id);
    }

    function set_cs(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Atur CS');
        $("#load-form").load("<?= base_url() ?>transaction/set_cs?id=" + id);
    }

    function set_resi(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Atur No Resi');
        $("#load-form").load("<?= base_url() ?>transaction/set_resi?id=" + id);
    }

    function set_return(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Atur Return');
        $("#load-form").load("<?= base_url() ?>transaction/set_return?id=" + id);
    }


    function refresh(order_id, marketplace) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Refresh');
        $("#load-form").load("<?= base_url() ?>transaction/refresh?order_id=" + order_id + '&marketplace=' + marketplace);
    }


    function import_data(start_date, until_date) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Import Data');
        $("#load-form").load("<?= base_url() ?>transaction/import<?= $param ?>");
    }

    function download_file() {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Download Order');
        $("#load-form").load("<?= base_url() ?>transaction/download-file<?= $param ?>");
    }

    function import_resi(start_date, until_date) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Import Resi');
        $("#load-form").load("<?= base_url() ?>transaction/import-resi<?= $param ?>");
    }

    function import_customer(start_date, until_date) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Import Pelanggan');
        $("#load-form").load("<?= base_url() ?>transaction/import_customer?start_date=" + start_date + "&until_date=" + until_date);
    }

    function sync_data(start_date, until_date) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Sync Data');
        $("#load-form").load("<?= base_url() ?>transaction/sync?start_date=" + start_date + "&until_date=" + until_date);
    }
</script>

<script>
    function loadMoreData() {
        $.ajax({
            type: 'GET',
            url: "<?= base_url() ?>transaction/item<?= $param ?>",
            success: function(data) {
                $('#tbody').html('');
                $('#tbody').append(data);
                select3();
            },
            error: function(xhr, status, error) {}
        });
    }
    loadMoreData();
</script>