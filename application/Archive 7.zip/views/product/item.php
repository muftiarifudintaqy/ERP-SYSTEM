<?php
$k = $start;
foreach ($data as $v) {
    if($v['img']){
        $v['img'] = base_url().'/assets/img/product/'.$v['img'];
    }else{
        $v['img'] = base_url().'/assets/img/icon/icon-no.png';
    }
?>
<tbody>
    <tr>
    <td class="text-start">
    <p class="mb-1 text-blue fw-700 fs-16">#<?=$k+1?></p>
    </td>
        <td class="text-start">

    <div class="row">
        <div class="col-12" style="position:relative">
        <div class="row">
        <div class="firstDivImg">
            <a href="<?=$v['img']?>" target="_blank"><img class="divIcon" src="<?=$v['img']?>" alt=""></a>
        </div>
        <div class="secondDivImg">
        <a class="mb-1 a-none fw-700 fs-16" href="<?=base_url()?>/product/stock?id=<?=$v['id']?>"><?=$v['name']?></a>
        <p class="mb-1">Brand : <?=$v['brand']?></p>
        <p class="mb-1">SKU : <?=$v['sku']?></p>
        </div>
        </div>
        </div>
    </div>
        </td>
        <td class="text-start">
            <?php if(in_array($user['role'],array('1','3'))){ ?>
            <p class="mb-1">HPP : <?=$template->separator_only($v['price_buy'])?></p>
            <?php } ?>
            <p class="mb-1">H. Jual Pelanggan : <?=$template->separator_only($v['price_normal'])?></p>
            <p class="mb-1">H. Jual Reseller : <?=$template->separator_only($v['price_reseller'])?></p>
            <p class="mb-1">H. Jual Distributor : <?=$template->separator_only($v['price_distributor'])?></p>
        </td>
        <td class="text-end">
            <?=$template->separator_only($v['stock_in'])?>
        </td>
        <td class="text-end">
            <?=$template->separator_only($v['stock_out'])?>
        </td>
        <td class="text-end">
            <?=$template->separator_only($v['stock'])?>
        </td>
        
        <?php if(in_array($user['role'],array('1','3'))){ ?>
    <td class="text-end">
        <a href="#!" onclick="edit('<?=$v['id']?>')" class="mt-0 text-blue me-1"><i class="bi bi-pen text-icon"></i></a>
        <a href="#!" onclick="remove('<?=$v['id']?>')" class="mt-0 text-red"><i class="bi bi-trash text-icon"></i></a>
    </td>
    <?php } ?>
    </tr>
</tbody>
<?php $k += 1;} ?>
