<?php if($_GET['page'] > 1){ ?>
   <tbody>
   <tr>
   <td class="text-start"><p class="mb-1 text-blue fw-700 fs-16">#</p></td>
            <td class="text-start" colspan="4">Stok Sebelumnya</td>
            <td class="text-end"><?= $balance ?></td>
            <td class="text-start" colspan="3"></td>
        </tr>
   </tbody>
<?php } ?>

<?php
$k = $start;
foreach ($data as $v) {  
    $balance += $v['qty'];
    $class = "text-red";
    if($v['type']=="In"){
        $class="text-green";
    }
    ?>
       <tbody>
       <tr>
            <td class="text-start"><p class="mb-1 text-blue fw-700 fs-16">#<?=$k+1?></p></td>
            <td class="text-start"><?=$template->date_format_indo_with_time($v['date'])?></td>
            <td class="text-start"><?= $v['type'] ?><br><?= $v['type_sub'] ?></td>
            <td class="text-start"><a target="_blank" href="<?= base_url() ?>/transaction?keyword_category=Order ID&keyword=<?= $v['code'] ?>&start_date=<?=DATE("Y-m-d",strtotime($v['date']))?>&until_date=<?=DATE("Y-m-d",strtotime($v['date']))?>"><?= $v['code'] ?></a></td>
            <td class="text-end <?=$class?>"><?= $template->separator_only($v['qty']) ?></td>
            <td class="text-end"><?= $template->separator_only($balance) ?></td>
            <td class="text-start"><?= $v['desc'] ?></td>
        </tr>
       </tbody>
<?php $k += 1; } ?>