<div class="w-100">
    <div class="row align-items-center">
        <div class="col-lg-12 mb-3">
            <h3 class="text-primary fw-600 mb-3">STOK PRODUK</h3>
            <div class="card">
            <p class="mb-1">Name : <?= $data['name'] ?></p>
            <p class="mb-1">Stok In : <?= $data['stock_in'] ?></p>
            <p class="mb-1">Stok Out : <?= $template->separator_only($data['stock_out']) ?> (<?= $template->separator_only($data['stock_out_pos']) ?> + <?= $template->separator_only($data['stock_out'] - $data['stock_out_pos']) ?>)</p>
            <p class="mb-1">Stok Balance : <?= $template->separator_only($data['stock']) ?></p>
            <p class="mb-1">SKU : <?= $data['sku'] ?></p>
            <p class="mb-1">Brand : <?= $data['brand'] ?></p>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <?=$notif?>
        <div class="form-message"></div>
            <div class="table-responsive" id="table-item">
                <table class="table" id="tbody">
                <thead>
                    <tr class="bg-primary text-white">
                        <th class="text-start" style="max-width:0px!important">#</th>
                        <th class="text-start">TGL</th>
                        <th class="text-start">TIPE</th>
                        <th class="text-start">ID TRX</th>
                        <th class="text-end">QTY</th>
                        <th class="text-end">BALANCE</th>
                        <th class="text-start">KET</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
    <?=$pagination?>
</div>

<div class="modal fade bd-example-modal-sm" tabindex="-1" varietas="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="modal-form">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="title-form"></h5>
                <a class="close a-link" data-bs-dismiss="modal"><i class="bi bi-x-circle fs-24"></i></a>
            </div>
            <div class="modal-body">
                <div id="load-form"></div>
            </div>
        </div>
    </div>
</div>

<script>
    function create() {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Create Data');
        $("#load-form").load("<?= base_url() ?>/product/create");
    }

    function edit(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Edit Data');
        $("#load-form").load("<?= base_url() ?>/product/edit?id=" + id);
    }

    function remove(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Delete Data');
        $("#load-form").load("<?= base_url() ?>/product/remove?id=" + id);
    }
</script>

<script>
var complete = false;
var offset = 0;
var loading = false;
function loadMoreData() {
    if(!complete){
        if (!loading) {
            loading = true;
            $.ajax({
                type: 'GET',
                url: "<?= base_url() ?>/product/item-stock?start_date=<?=$start_date?>&until_date=<?=$until_date?>&brand=<?=$brand?>&product=<?=$_GET['product']?>&type=<?=$_GET['type']?>&type_sub=<?=$_GET['type_sub']?>&keyword=<?=$_GET['keyword']?>&page=<?=$_GET['page']?>&id=<?=$_GET['id']?>",
                success: function (data) {
                    $('#tbody').append(data);
                    offset += 30;
                    loading = false;
                    if (!data) {
                        complete = true;
                    }
                    select3();
                },
                error: function (xhr, status, error) {
                    loading = false;
                }
            });
        }
    }else{
        $("#msg").html("<i class='fa fa-check'></i> Proses memuat data selesai!");
    }
}
loadMoreData();
</script>
