<?php
$k = $start;
foreach ($data as $v) {
   if ($v['type_sub'] == 'Stock') {
?>
      <tbody>
         <tr>
            <td class="text-start">
               <p class="mb-1 text-blue fw-700 fs-16">#<?= $k + 1 ?></p>
            </td>
            <td class="text-start">
               <?= $this->template->date_format_indo_with_time($v['date']) ?>
            </td>
            <td class="text-start">
               <?= $v['type'] ?>
               <br>
               <?= $v['type_sub'] ?>
            </td>
            <td class="req text-start"><a target="_blank" href="<?= base_url() ?>/transaction?keyword_category=Order ID&keyword=<?= $v['code'] ?>&start_date=<?= DATE("Y-m-d", strtotime($v['date'])) ?>&until_date=<?= DATE("Y-m-d", strtotime($v['date'])) ?>"><?= $v['code'] ?></a></td>
            <td class="text-end">
               <?= $v['qty'] ?>
            </td>
            <td class="text-start">
               <?= $v['product_text'] ?>
            </td>
            <td class="text-start">
               <?= $v['desc'] ?>
            </td>
            <td class="text-end">
               <a href="#!" onclick="edit('<?= $v['id'] ?>')" class="mt-0 text-blue me-1"><i class="bi bi-pen text-icon"></i></a>
               <a href="#!" onclick="remove('<?= $v['id'] ?>')" class="mt-0 text-red"><i class="bi bi-trash text-icon"></i></a>
            </td>
         </tr>
      </tbody>
   <?php } else { ?>

      <tbody>
         <tr>
            <td class="text-start">
               <p class="mb-1 text-blue fw-700 fs-16">#<?= $k + 1 ?></p>
            </td>
            <td class="text-start">
               <?= $this->template->date_format_indo_with_time($v['date']) ?>
            </td>
            <td class="text-start">
               <?= $v['type'] ?>
               <br>
               <?= $v['type_sub'] ?>
            </td>
            <td class="req text-start"><a target="_blank" href="<?= base_url() ?>/transaction?keyword_category=Order ID&keyword=<?= $v['code'] ?>&start_date=<?= DATE("Y-m-d", strtotime($v['date'])) ?>&until_date=<?= DATE("Y-m-d", strtotime($v['date'])) ?>"><?= $v['code'] ?></a></td>
            <td class="text-end">
               <?= $v['qty'] ?>
            </td>
            <td class="text-start">
               <?= $v['product_text'] ?>
            </td>
            <td class="text-start">
               <?= $v['desc'] ?>
            </td>
            <td></td>
         </tr>
      </tbody>
   <?php } ?>
<?php $k += 1;
} ?>