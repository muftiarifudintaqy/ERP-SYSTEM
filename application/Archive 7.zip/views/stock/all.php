<div class="w-100">
    <div class="row align-items-center">
        <div class="col-lg-12 mb-3">
            <h3 class="text-primary fw-600">STOK</h3>
        </div>
        <div class="col-lg-12">
            <form action="">
                <div class="row">
                    <div class="col-md-2">
                        <label for="">Order ID</label>
                        <input type="keyword" class="form-control" name="keyword" value="<?= $_GET['keyword'] ?>">
                    </div>
                    <div class="col-md-1">
                        <label for="">Brand</label>
                        <select class="form-control" name="brand" id="brand">
                            <option value="">Semua Brand</option>
                            <?php
                            foreach ($brands as $val) :
                                $text = '';
                                if ($_GET['brand'] == $val['code']) {
                                    $text = 'selected';
                                }
                            ?>
                                <option <?= $text ?> value="<?= $val['code'] ?>"><?= $val['code'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-1">
                        <label for="">Tipe</label>
                        <select class="form-control" name="type">
                            <option value="">Semua Tipe</option>
                            <?php
                            $arr = array();
                            $arr[] = "In";
                            $arr[] = "Out";
                            foreach ($arr as $k2 => $v2) {
                                $text = '';
                                if ($_GET['type'] == $v2) {
                                    $text = 'selected';
                                }
                            ?>
                                <option <?= $text ?> value="<?= $v2 ?>"><?= $v2 ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label for="">Sub Tipe</label>
                        <select class="form-control" name="type_sub">
                            <option value="">Semua Sub Tipe</option>
                            <?php
                            $arr = array();
                            $arr[] = "Stock";
                            $arr[] = "POS";
                            foreach ($arr as $k2 => $v2) {
                                $text = '';
                                if ($_GET['type_sub'] == $v2) {
                                    $text = 'selected';
                                }
                            ?>
                                <option <?= $text ?> value="<?= $v2 ?>"><?= $v2 ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="">Tanggal</label>
                        <div class="d-flex">
                            <input type="date" name="start_date" class="form-control" value="<?= $start_date ?>" style="border-top-right-radius: 0px !important; border-bottom-right-radius: 0px !important; min-width:120px;">
                            <input type="date" name="until_date" class="form-control" value="<?= $until_date ?>" style="border-top-left-radius: 0px !important; border-bottom-left-radius: 0px !important; min-width:120px;">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label for="">Produk</label>
                        <select class="form-control select2" name="product">
                            <option value="">Semua Produk</option>
                            <?php
                            foreach ($product as $val) :
                                $text = '';
                                if ($_GET['product'] == $val['id']) {
                                    $text = 'selected';
                                }
                            ?>
                                <option <?= $text ?> value="<?= $val['id'] ?>"><?= $val['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <style>
                        .select2-container--open .select2-dropdown {
                            z-index: 10000;
                        }
                    </style>
                    <script>
                        $('.select2').select2();
                    </script>
                    <div class="col-md-6">
                        <button class="btn btn-primary" type="submit">Cari Data</button>
                    </div>

                    <div class="col-md-6 text-end">
                        <a href="#!" onclick="create()" class="btn btn-primary">Tambah Data</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <br>
    <?= $notif ?>
    <div class="col-lg-12">
        <div class="form-message"></div>
        <div class="table-responsive" id="table-item">
            <table class="table" id="tbody">
                <thead>
                    <tr class="bg-blue-2 text-white">
                        <th class="text-start">#</th>
                        <th class="text-start">TGL</th>
                        <th class="text-start">TIPE</th>
                        <th class="text-start">ORDER ID</th>
                        <th class="text-end">QTY</th>
                        <th class="text-start">PRODUK</th>
                        <th class="text-start">KET</th>
                        <th class="text-end"><i class="bi bi-gear-fill"></i></th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
    <?= $pagination ?>
</div>

<div class="modal fade bd-example-modal-sm" tabindex="-1" varietas="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="modal-form">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="title-form"></h5>
                <a class="close a-link" data-bs-dismiss="modal"><i class="bi bi-x-circle fs-24"></i></a>
            </div>
            <div class="modal-body">
                <div id="load-form"></div>
            </div>
        </div>
    </div>
</div>

<script>
    function create() {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Create Data');
        $("#load-form").load("<?= base_url() ?>/stock/create");
    }

    function edit(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Edit Data');
        $("#load-form").load("<?= base_url() ?>/stock/edit?id=" + id);
    }

    function remove(id, k) {
        product = $("#product-" + k).val();
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Hapus Data');
        $("#load-form").load("<?= base_url() ?>/stock/remove?id=" + id + "&product=" + product);
    }
</script>

<script>
    var complete = false;
    var offset = 0;
    var loading = false;

    function loadMoreData() {
        if (!complete) {
            if (!loading) {
                loading = true;
                $.ajax({
                    type: 'GET',
                    url: "<?= base_url() ?>/stock/item<?= $param ?>",
                    success: function(data) {
                        $('#tbody').append(data);
                        offset += 30;
                        loading = false;
                        if (!data) {
                            complete = true;
                        }
                        select3();
                    },
                    error: function(xhr, status, error) {
                        loading = false;
                    }
                });
            }
        } else {
            $("#msg").html("<i class='fa fa-check'></i> Proses memuat data selesai!");
        }
    }
    loadMoreData();
</script>