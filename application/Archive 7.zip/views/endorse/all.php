<?php
$chart_title = "";
$site = $_GET['site'];
$customer = $_GET['customer'];

// if ($_GET['start_date'] == "") {
//     $start_date = DATE("Y-m-01");
// } else {
//     $start_date = $_GET['start_date'];
// }
if ($_GET['until_date'] == "") {
    $until_date = DATE("Y-m-d");
} else {
    $until_date = $_GET['until_date'];
}

if ($_GET['start_year'] == "") {
    $start_year = DATE("Y");
} else {
    $start_year = $_GET['start_year'];
}

if ($_GET['until_year'] == "") {
    $until_year = DATE("Y");
} else {
    $until_year = $_GET['until_year'];
}

if ($_GET['start_month'] == "") {
    $start_month = "1";
} else {
    $start_month = $_GET['start_month'];
}

if ($_GET['until_month'] == "") {
    $until_month = DATE("m");
} else {
    $until_month = $_GET['until_month'];
}

if ($_GET['start_week'] == "") {
    $start_week = "1";
} else {
    $start_week = $_GET['start_week'];
}

if ($_GET['until_week'] == "") {
    $until_week = DATE("W", strtotime(DATE('Y-m-d')));
} else {
    $until_week = $_GET['until_week'];
}



$type = $_GET['type'];

if ($_GET['type'] == "Yearly") {
    $chart_title = $start_year . ' - ' . $until_year;
} else if ($_GET['type'] == "Monthly") {
    $chart_title = 'Month ' . $start_month . ' - ' . $until_month . ' ' . $start_year;
} else if ($_GET['type'] == "Weekly") {
    $chart_title = 'Week ' . $start_week . ' - ' . $until_week . ' ' . $start_year;
} else {
    $type = "Daily";
    $chart_title = DATE('d M Y', strtotime($start_date)) . ' - ' . DATE('d M Y', strtotime($until_date));
}
?>
<div class="w-100">
    <div class="row align-items-center">
        <div class="col-lg-12 mb-3">
            <h3 class="text-primary fw-600">DETAIL CAMPAIGN</h3>
            <h3 class="text-primary fw-600"><?= $detail['title'] ?></h3>
            <p class="mb-0"><?= $detail['desc'] ?></p>
        </div>
        <div class="col-lg-12 mb-3">
            <form action="<?= $url ?>" method="GET">
                <input type="hidden" name="ids" value="<?= $ids ?>">
                <input type="hidden" name="id_campaign" value="<?= $detail['id'] ?>">
                <div class="row">

                    <div class="col-md-12">
                        <?php
                        $arr = array();
                        $arr[] = "Semua Status";
                        $arr[] = "Review";
                        $arr[] = "Hold";
                        $arr[] = "Acc";
                        $arr[] = "DP";
                        $arr[] = "FP";
                        $arr[] = "Barang Dikirim";
                        $arr[] = "Draft Content";
                        $arr[] = "Posted Content";
                        $arr[] = "Reject";

                        foreach ($arr as $k => $val) {
                            $class = "btn-default";
                            $class_2 = "dot";

                            $value = $val;
                            if ($k == 0) {
                                $value = '';
                            }
                            $status = isset($_GET['endorse_status']) ? $_GET['endorse_status'] : '';

                            $statusArray = $status ? explode(',', $status) : [];

                            if (($key = array_search($value, $statusArray)) !== false) {
                                unset($statusArray[$key]);
                                $class = "btn-default-selected";
                                $class_2 = "dot-active";
                            } else {
                                $statusArray[] = $value;
                            }

                            $status = implode(',', $statusArray);

                            if ($k == 0) {
                                $status = '';
                            }

                            if ($k == 0 && $_GET['endorse_status'] == "") {
                                $class_2 = "dot-active";
                                $class = "btn-default-selected";
                            }

                        ?>
                            <a href="<?= $url ?>&endorse_status=<?= $status ?>" class="btn <?= $class ?> mb-2 me-2"><span class="<?= $class_2 ?>"></span> <?= $val ?></a>
                        <?php }  ?>
                        <div class="col-md-12"></div>
                        <?php
                        $arr = array();

                        $arr[] = "Semua Kategori";
                        $arr[] = "Ada Link Upload";
                        $arr[] = "Tidak Ada Link Upload";
                        $arr[] = "FYP";
                        foreach ($arr as $k => $val) {
                            $class = "btn-default";
                            $class_2 = "dot";

                            $value = $val;
                            if ($k == 0) {
                                $value = '';
                            }
                            $value = str_replace('&', '', $value);

                            if ($_GET['status'] == $value) {
                                $class = "btn-default-selected";
                                $class_2 = "dot-active";
                            }
                        ?>
                            <a href="<?= $url_2 ?>&status=<?= $value ?>" class="btn <?= $class ?> mb-2 me-2"><span class="<?= $class_2 ?>"></span> <?= $val ?></a>
                        <?php }  ?>
                    </div>
                    <input type="hidden" name="endorse_status" value="<?= $_GET['endorse_status'] ?>">
                    <!-- <input type="hidden" name="status" value="<?= $_GET['endorse_status'] ?>"> -->

                    <div class="col-lg-10">
                        <div class="d-flex">
                            <button class="btn btn-outline-secondary-category dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="border-top-right-radius: 0px !important;
                            border-bottom-right-radius: 0px !important;min-width:60px!important"><?= $keyword_category ?></button>
                            <ul class="dropdown-menu">
                                <?php
                                $arr = array();
                                $arr[] = 'Nama Creator';
                                $arr[] = 'Link Upload';
                                $arr[] = 'PIC';
                                $arr[] = 'Platform';
                                $arr[] = 'Task';
                                $arr[] = 'Keterangan';
                                foreach ($arr as $k => $val) {
                                    $class = "btn-default";
                                    if ($_GET['order_status'] == $val) {
                                        $class = "btn-default-selected";
                                    }
                                ?>
                                    <li><a class="dropdown-item" href="<?= $url ?>&keyword_category=<?= $val ?>"><?= $val ?></a></li>
                                <?php }  ?>
                            </ul>
                            <input type="hidden" name="keyword_category" value="<?= $keyword_category ?>">
                            <input type="text" name="keyword" class="form-control me-2" value="<?= $_GET['keyword'] ?>" style="border-top-left-radius: 0px !important;
                            border-bottom-left-radius: 0px !important;width:140px!important">
                            <a href="#!" onclick="sync_all('<?= $detail['id'] ?>')" class="btn btn-sync mt-0 ms-1"><i class="bi bi-bootstrap-reboot fs-16"></i> Refresh Semua</a>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-5">
                            <div class="row">
                                <div class="col-md-4">
                                    <select class="form-control " name="platform" id="platform">
                                        <option value="">Semua Platform</option>
                                        <?php
                                        $arr = array();
                                        $arr[] = "Instagram";
                                        $arr[] = "Tiktok";
                                        $arr[] = "Twitter";
                                        $arr[] = "Youtube";
                                        foreach ($arr as $val) :
                                            $text = "";
                                            if ($_GET["platform"] == $val) {
                                                $text = "selected";
                                            }
                                        ?>
                                            <option <?= $text ?> value="<?= $val ?>"><?= $val ?></option>
                                        <?php
                                        endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <?php
                                    $arr = [];
                                    $arr[] = "Daily";
                                    //   $arr[] = "Weekly";
                                    //   $arr[] = "Monthly";
                                    //   $arr[] = "Yearly";
                                    ?>
                                    <select class="form-control " name="type" id="type">
                                        <?php foreach ($arr as $k => $v) {
                                            $text = "";
                                            if ($type == $v) {
                                                $text = "selected";
                                            }
                                        ?>
                                            <option <?= $text ?> value="<?= $v ?>"><?= $v ?></option>
                                        <?php
                                        } ?>
                                    </select>
                                </div>
                                <div class="col-md-5">
                                    <?php
                                    $arr = [];
                                    $arr[] = "";
                                    $arr[] = "Tanggal Dibuat";
                                    $arr[] = "Rencana Upload";
                                    $arr[] = "Tanggal Posting";
                                    ?>
                                    <select class="form-control " name="cat">
                                        <?php foreach ($arr as $k => $v) {
                                            $text = "";
                                            if ($_GET['cat'] == $v) {
                                                $text = "selected";
                                            }
                                        ?>
                                            <option <?= $text ?> value="<?= $v ?>"><?= $v ?></option>
                                        <?php
                                        } ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="row" id="filter"></div>
                        </div>
                        <script>
                            $("#type").change(function() {
                                get_filter();
                            });

                            get_filter();

                            function get_filter() {
                                var type = $("#type").val();
                                $.ajax({
                                    dataType: "json",
                                    url: '<?= base_url() ?>/ajax/get-filter?type=' + type +
                                        '&start_date=<?= $start_date ?>&until_date=<?= $until_date ?>&start_year=<?= $start_year ?>&until_year=<?= $until_year ?>&start_month=<?= $start_month ?>&until_month=<?= $until_month ?>&start_week=<?= $start_week ?>&until_week=<?= $until_week ?>&page=endorse',
                                    success: function(html) {
                                        $("#filter").html(html.html);
                                    }
                                });
                                // $('.select2').select2();
                            }
                        </script>
                    </div>
                    <div class="col-lg-6">
                        <!-- <button class="btn btn-edit-active" type="submit"><i class="bi bi-search fs-16"></i> Cari Data</button> -->
                    </div>
                    <div class="col-lg-6 text-end">
                        <!-- <a href="#!" onclick="sync_all('<?= $detail['id'] ?>')" class="btn btn-sync mt-0 ms-1"><i class="bi bi-bootstrap-reboot fs-16"></i> Refresh Semua</a>
                    <a href="#!" onclick="create('<?= $detail['id'] ?>')" class="btn btn-primary mt-0 ms-1"><i class="bi bi-plus-circle-dotted fs-16"></i> Tambah Konten</a> -->
                    </div>

                </div>

        </div>
        </form>
    </div>
</div>
<div class="col-lg-12 mb-3">
    <div class="row">
        <?php
        $sum = array();
        $i = 0;
        $sum[$i]['code'] = 'mar-1';
        $sum[$i]['img'] = "bi bi-coin";
        $sum[$i]['color_box'] = "#60BB551A";
        $sum[$i]['color_icon'] = "#60bb55";
        $sum[$i]['title'] = "TOTAL BUDGET";
        $sum[$i]['unit'] = "BCM";
        $i++;
        $sum[$i]['code'] = 'mar-2';
        $sum[$i]['img'] = "bi bi-arrow-up-right";
        $sum[$i]['color_box'] = "#60BB551A";
        $sum[$i]['color_icon'] = "#60bb55";
        $sum[$i]['title'] = "TOTAL COST";
        $sum[$i]['unit'] = "BCM";
        $i++;
        $sum[$i]['code'] = 'mar-3';
        $sum[$i]['img'] = "bi bi-cursor";
        $sum[$i]['color_box'] = "#60BB551A";
        $sum[$i]['color_icon'] = "#60bb55";
        $sum[$i]['title'] = "CPM";
        $sum[$i]['unit'] = "BCM";
        $i++;
        $sum[$i]['code'] = 'mar-4';
        $sum[$i]['img'] = "bi bi-people";
        $sum[$i]['color_box'] = "#60BB551A";
        $sum[$i]['color_icon'] = "#60bb55";
        $sum[$i]['title'] = "TOTAL INFLUENCER";
        $sum[$i]['unit'] = "BCM";
        $i++;
        $sum[$i]['code'] = 'mar-5';
        $sum[$i]['img'] = "bi bi-person-video2";
        $sum[$i]['color_box'] = "#60BB551A";
        $sum[$i]['color_icon'] = "#60bb55";
        $sum[$i]['title'] = "TOTAL KONTEN";
        $sum[$i]['unit'] = "BCM";
        $i++;
        $sum[$i]['code'] = 'mar-6';
        $sum[$i]['img'] = "bi bi-eye";
        $sum[$i]['color_box'] = "#60BB551A";
        $sum[$i]['color_icon'] = "#60bb55";
        $sum[$i]['title'] = "VIEWS";
        $sum[$i]['unit'] = "BCM";
        $i++;
        $sum[$i]['code'] = 'mar-7';
        $sum[$i]['img'] = "bi bi-heart";
        $sum[$i]['color_box'] = "#60BB551A";
        $sum[$i]['color_icon'] = "#60bb55";
        $sum[$i]['title'] = "LIKES";
        $sum[$i]['unit'] = "BCM";
        $i++;
        $sum[$i]['code'] = 'mar-8';
        $sum[$i]['img'] = "bi bi-chat-quote";
        $sum[$i]['color_box'] = "#60BB551A";
        $sum[$i]['color_icon'] = "#60bb55";
        $sum[$i]['title'] = "COMMENTS";
        $sum[$i]['unit'] = "BCM";
        $i++;
        ?>
        <?php foreach ($sum as $k => $v) { ?>
            <div class="text-start mb-4 col-md-3">
                <?php if ($v['code'] == "mar-4") { ?>
                    <a href="<?= base_url() ?>endorse/stats<?= $param ?>" class="text-primary">
                        <div class="card">
                            <div class="row">
                                <div class="col-12" style="position:relative">
                                    <div class="row">
                                        <div class="firstDiv">
                                            <div class="firstCircle">
                                                <div class="box-icon mb-2 text-center" style="background-color:<?= $v['color_box'] ?>;">
                                                    <i class="<?= $v['img'] ?>" style="color:<?= $v['color_icon'] ?>"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="secondDiv">
                                            <p class="fw-500 mb-1 text-end"><?= $v['title'] ?></p>
                                            <h4 class="fw-500 mb-1 text-end" id="summary-<?= $v['code'] ?>"><i class="fa fa-circle-o-notch fa-spin"></i></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php } else { ?>
                    <div class="card">
                        <div class="row">
                            <div class="col-12" style="position:relative">
                                <div class="row">
                                    <div class="firstDiv">
                                        <div class="firstCircle">
                                            <div class="box-icon mb-2 text-center" style="background-color:<?= $v['color_box'] ?>;">
                                                <i class="<?= $v['img'] ?>" style="color:<?= $v['color_icon'] ?>"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="secondDiv">
                                        <p class="fw-500 mb-1 text-end"><?= $v['title'] ?></p>
                                        <h4 class="fw-500 mb-1 text-end" id="summary-<?= $v['code'] ?>"><i class="fa fa-circle-o-notch fa-spin"></i></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <script>
                $.ajax({
                    dataType: "json",
                    url: '<?= base_url() ?>/ajax/get-summary-campaign<?= $param ?>&id=<?= $v['code'] ?>&id_campaign=<?= $detail['id'] ?>&cat=<?= $_GET['cat'] ?>&endorse_status=<?= $_GET['endorse_status'] ?>&ids=<?= $ids ?>',
                    success: function(html) {
                        $("#summary-<?= $v['code'] ?>").html(html.html);
                    }
                });
            </script>
        <?php } ?>
    </div>
</div>
<div class="col-lg-12 mb-3">
    <div class="card summary">
        <h3 class="text-primary fw-600 mb-1">Grafik Campaign</h3>
        <p class="mb-2"><?= $title_2 ?></p>
        <div class="row">
            <div class="col-md-12">
                <div class="d-grid d-md-flex d-lg-flex">
                    <?php
                    $arr = array();
                    $arr[] = "Daily";
                    $arr[] = "Views";
                    $arr[] = "CPM";
                    $arr[] = "Likes";
                    $arr[] = "Comments";
                    $arr[] = "Share & Save";
                    $arr[] = "Jumlah Konten";
                    foreach ($arr as $k => $v) {
                        $text = "";
                        if ($checkbox[$k] == 'true') {
                            $text = "checked";
                        }
                        if (empty($checkbox)) {
                            $text = "checked";
                        }
                    ?>
                        <input onclick="checkbox(<?= $k ?>)" <?= $text ?> type="checkbox" id="c-<?= $k ?>" class="me-2 c-checkbox"><label for="c-<?= $k ?>" class="fw-400 me-2"><?= $v ?></label>
                    <?php } ?>
                </div>
            </div>
        </div>
        <div id="summary-chart"><i class="fa fa-circle-o-notch fa-spin"></i> Memuat data ...</div>
        <div id="summary-table"><i class="fa fa-circle-o-notch fa-spin"></i> Memuat data ...</div>
        <script>
            get_chart();

            function get_chart() {
                $.ajax({
                    dataType: "json",
                    url: '<?= base_url() ?>/ajax/get-chart-campaign<?= $param ?>',
                    success: function(html) {
                        $("#summary-chart").html(html.html);
                        $("#summary-table").html(html.table);
                        $("#summary-mar-3").html('<i class="fa fa-circle-o-notch fa-spin"></i>');
                        $("#summary-mar-3").html(html.summary.cpm);
                        $("#summary-mar-6").html('<i class="fa fa-circle-o-notch fa-spin"></i>');
                        $("#summary-mar-6").html(html.summary.view);
                        $("#summary-mar-7").html('<i class="fa fa-circle-o-notch fa-spin"></i>');
                        $("#summary-mar-7").html(html.summary.likes);
                        $("#summary-mar-8").html('<i class="fa fa-circle-o-notch fa-spin"></i>');
                        $("#summary-mar-8").html(html.summary.comment);
                    }
                });
            }

            function checkbox(index) {
                var checkboxStatus = {};
                var i = 0;
                $(".c-checkbox").each(function() {
                    var isChecked = $(this).prop("checked");
                    checkboxStatus[i] = isChecked;
                    i++;
                });

                var queryParams = $.param(checkboxStatus);
                console.log(queryParams);
                $.ajax({
                    type: "GET",
                    dataType: "json",
                    url: '<?= base_url() ?>/ajax/checkbox?' + queryParams,
                    success: function(response) {
                        get_chart();
                    }
                });
            }
        </script>
    </div>
</div>
<a href="#!" onclick="create('<?= $detail['id'] ?>')" class="btn btn-primary mt-0 mb-2"><i class="bi bi-plus-circle-dotted fs-16"></i> Tambah Konten</a>
<?= $notif ?>


<div class="col-lg-12 mb-3">
    <div class="checkbox-wrapper-13">
        <input id="c1-13" type="checkbox" value="1" class="checkAll">
        <label for="c1-13">Pilih Semua Data</label>
    </div>
</div>

<div class="col-lg-12">
    <div class="col-lg-12">
        <div id="tbody">
            <?php $this->load->view('loading', true) ?>
        </div>
    </div>

    <?= $pagination ?>
</div>



<div class="floating-div">
    <button class="btn mb-2 btn-edit-active dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
        <i class="bi bi-gear fs-16"></i> Aksi
    </button>
    <ul class="dropdown-menu text-end" style="padding:0px;background:unset;border:unset">


        <li><a class="dropdown-items" href="#!" style="padding:0px;">
                <button type="button" class="btn mb-2 btn-edit-active" onclick="refresh_data()">
                    <i class="bi bi-bootstrap-reboot fs-16"></i> Refresh Data
                </button>
            </a></li>

        <li><a class="dropdown-items" href="#!" style="padding:0px;">
                <button type="button" class="btn mb-2 btn-edit-active" onclick="tampilkan_data()">
                    <i class="bi bi-eye fs-16"></i> Tampilkan Data
                </button>
            </a></li>

        <li><a class="dropdown-items" href="#!" style="padding:0px;">
                <button type="button" class="btn mb-2 btn-edit-active" onclick="ubah_status()">
                    <i class="bi bi-cursor fs-16"></i> Ubah Status Konten
                </button>
            </a></li>

        <li><a class="dropdown-items" href="#!" style="padding:0px;">
                <button type="button" class="btn mb-2 btn-edit-active" onclick="ubah_status_data()">
                    <i class="bi bi-cursor fs-16"></i> Ubah Status Data
                </button>
            </a></li>

        <li><a class="dropdown-items" href="#!" style="padding:0px">
                <button type="button" class="btn mb-2 btn-edit-active" onclick="hapus_data()">
                    <i class="bi bi-trash fs-16"></i> Hapus Data
                </button>
            </a></li>

    </ul>

</div>


<div class="modal fade bd-example-modal-sm" tabindex="-1" varietas="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="modal-form">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="title-form"></h5>
                <a class="close a-link" data-bs-dismiss="modal"><i class="bi bi-x-circle fs-24"></i></a>
            </div>
            <div class="modal-body">
                <div id="load-form"></div>
            </div>
        </div>
    </div>
</div>

<input type="hidden" id="id_selected" name="id_selected" form="form-action">

<script>
    var list_id_v2 = '';

    function get_id() {
        list_id_v2 = '';
        var selectedValues = [];
        $('input[name="list_id"]').each(function() {
            if ($(this).is(":checked")) {
                selectedValues.push($(this).val());
                list_id_v2 += $(this).val() + ',';
            } else {
                selectedValues.push('0');
            }
        });
        if (list_id_v2.length > 0) {
            list_id_v2 = list_id_v2.slice(0, -1); // Remove the trailing comma
        }
        $('#id_selected').val(selectedValues.join(','));
    }

    function tampilkan_data(id) {
        window.location.href = "<?= base_url() ?>/endorse?id_campaign=<?= $detail['id'] ?>&ids=" + list_id_v2;
    }

    function hapus_data(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Hapus Data');
        $("#load-form").load("<?= base_url() ?>/endorse/action?code=hapus_data&id=" + id);
    }

    function ubah_status(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Ubah Status Konten');
        $("#load-form").load("<?= base_url() ?>/endorse/action?code=ubah_status&id=" + id);
    }

    function ubah_status_data(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Ubah Status Data');
        $("#load-form").load("<?= base_url() ?>/endorse/action?code=ubah_status_data&id=" + id);
    }

    function refresh_data(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Refresh Data');
        $("#load-form").load("<?= base_url() ?>/endorse/action?code=refresh_data&id_campaign=<?= $detail['id'] ?>");
    }

    function create(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Tambah Konten');
        $("#load-form").load("<?= base_url() ?>/endorse/create?id=" + id);
    }

    function remove(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Hapus Data');
        $("#load-form").load("<?= base_url() ?>/endorse/remove?id=" + id);
    }

    function edit(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Edit Konten');
        $("#load-form").load("<?= base_url() ?>/endorse/edit?id=" + id);
    }

    function sync_all(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Refresh Data');
        $("#load-form").load("<?= base_url() ?>/endorse/sync_all?id=" + id);
    }

    function sync(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Refresh Data');
        $("#load-form").load("<?= base_url() ?>/endorse/sync?id=" + id);
    }

    function clone(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Kloning Data');
        $("#load-form").load("<?= base_url() ?>/endorse/clone?id=" + id);
    }

    function show_chart(id) {
        $('#chart-' + id).html('<i class="fa fa-circle-o-notch fa-spin"></i> Memuat data ...')
        $.ajax({
            dataType: "json",
            url: '<?= base_url() ?>/ajax/get-chart-endorse<?= $param ?>&id=' + id,
            success: function(html) {
                $("#chart-'" + id).html(html.html);
                $("#table-").html(html.table);
            }
        });
    }
</script>
<script>
    function loadMoreData() {
        $.ajax({
            type: 'GET',
            url: "<?= base_url() ?>/endorse/item<?= $url_item ?>",
            success: function(data) {
                $('#tbody').html('');
                $('#tbody').append(data);
                select3();
            },
            error: function(xhr, status, error) {}
        });
    }
    loadMoreData();
</script>