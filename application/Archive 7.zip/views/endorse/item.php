<?php
$k = $start;
function separator_only($angka)
{
    $number = doubleval($angka);
    return number_format(round($number), 0, ',', '.');
}
function date_format_indo($date)
{
    $month = array(
        '',
        'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    );
    if ($date) {
        $date = DATE('d', strtotime($date)) . ' ' . $month[intval(DATE('m', strtotime($date)))] . ' ' . DATE('Y', strtotime($date));
    } else {
        $date = '-';
    }
    return $date;
}
foreach ($data as $v) {
    if ($v['platform'] == "Tiktok") {
        $v['img'] = base_url() . '/assets/img/icon/icon-tiktok.png';
    } else if ($v['platform'] == "Instagram") {
        $v['img'] = base_url() . '/assets/img/icon/icon-ig.png';
    } else if ($v['platform'] == "Youtube") {
        $v['img'] = base_url() . '/assets/img/icon/icon-youtube.png';
    } else if ($v['platform'] == "Facebook") {
        $v['img'] = base_url() . '/assets/img/icon/icon-fb.png';
    } else if ($v['platform'] == "Twitter") {
        $v['img'] = base_url() . '/assets/img/icon/icon-twitter.png';
    } else {
        $v['img'] = base_url() . '/assets/img/icon/icon-no.png';
    }
    if ($v['nama_creator'] == "") {
        $v['nama_creator'] = "-";
    }
    if ($v['posting_at']) {
        $v['posting_at'] = DATE("d/m/Y", strtotime($v['posting_at']));
    } else {
        $v['posting_at'] = '-';
    }
    if ($v['rencana_at']) {
        $v['rencana_at'] = DATE("d/m/Y", strtotime($v['rencana_at']));
    } else {
        $v['rencana_at'] = '-';
    }
    if ($v['barang_dikirim_at']) {
        $v['barang_dikirim_at'] = DATE("d/m/Y", strtotime($v['barang_dikirim_at']));
    } else {
        $v['barang_dikirim_at'] = '-';
    }
    if ($v['sync_at']) {
        $v['sync_at'] = DATE("d/m/Y", strtotime($v['sync_at']));
    } else {
        $v['sync_at'] = '-';
    }
    if ($v['created_at']) {
        $v['created_at'] = DATE("d/m/Y", strtotime($v['created_at']));
    } else {
        $v['created_at'] = '-';
    }
    if ($v['link_brief']) {
        $v['link_brief'] = '<a href="' . $v['link_brief'] . '" target="_blank">' . $v['link_brief'] . '</a>';
    } else {
        $v['link_brief'] = '-';
    }
    if ($v['link_mou']) {
        $v['link_mou'] = '<a href="' . $v['link_mou'] . '" target="_blank">' . $v['link_mou'] . '</a>';
    } else {
        $v['link_mou'] = '-';
    }
    if ($v['link_upload']) {
        $v['img'] = '<a href="' . $v['link_upload'] . '" target="_blank"><img style="width:40px;border-radius:10px;" class="mt-0" src="' . $v['img'] . '"></a>';
    } else {
        $v['img'] = '<img style="width:40px;border-radius:10px; filter: grayscale(100%)!important;" class="mt-0" src="' . $v['img'] . '">';
    }
    $bg = '#e6e6e6';
    $clr = '#000';


    if (in_array($v['status_endorse'], array('Review'))) {
        $bg = '#e6e6e6';
        // $clr = '#FFF';
    } else if (in_array($v['status_endorse'], array('Hold'))) {
        $bg = '#ffe599';
        // $clr = '#FFF';
    } else if (in_array($v['status_endorse'], array('Acc', 'DP', 'FP'))) {
        $bg = '#f6b26b';
        // $clr = '#FFF';
    } else if (in_array($v['status_endorse'], array('Barang Dikirim'))) {
        $bg = '#ffd0d0';
        // $clr = '#FFF';
    } else if (in_array($v['status_endorse'], array('Draft Content'))) {
        $bg = '#d4edbc';
        // $clr = '#FFF';
    } else if (in_array($v['status_endorse'], array('Posted Content'))) {
        $bg = '#7bd3ea';
        // $clr = '#FFF';
    } else if (in_array($v['status_endorse'], array('Reject'))) {
        $bg = '#ea7b7b';
        // $clr = '#FFF';
    }

    // $arr = array();
    // $arr[] = "Semua Status";
    // $arr[] = "1 - Planning";
    // $arr[] = "2 - Review";
    // $arr[] = "3 - Ditolak";
    // $arr[] = "4 - Di Pertimbangkan";
    // $arr[] = "5 - Acc & Payment";
    // $arr[] = "6 - Barang Endorse Dikirim";
    // $arr[] = "7 - Barang Endorse Diterima";
    // $arr[] = "8 - Draft Content";
    // $arr[] = "9 - Posted Content";
    // $arr[] = "Ada Link Upload";
    // $arr[] = "Tidak Ada Link Upload";

    if (empty($v['desc'])) {
        $v['desc'] = '-';
    }

    $creator = $this->mymodel->selectDataOne('influencer', array('id' => $v['influencer']));
    $v['type'] = $creator['type'];
    $v['tipe_kontak'] = $creator['tipe_kontak'];
    $v['url'] = $creator['url'];

    if ($v['type'] == "Tiktok") {
        $v['img_creator_1'] = base_url() . '/assets/img/icon/icon-tiktok.png';
    } else if ($v['type'] == "Instagram") {
        $v['img_creator_1'] = base_url() . '/assets/img/icon/icon-ig.png';
    } else if ($v['type'] == "Youtube") {
        $v['img_creator_1'] = base_url() . '/assets/img/icon/icon-youtube.png';
    } else if ($v['type'] == "Facebook") {
        $v['img_creator_1'] = base_url() . '/assets/img/icon/icon-fb.png';
    } else if ($v['type'] == "Twitter") {
        $v['img_creator_1'] = base_url() . '/assets/img/icon/icon-twitter.png';
    } else {
        $v['img_creator_1'] = base_url() . '/assets/img/icon/icon-no.png';
    }

    if ($v['url']) {
        $v['img_creator_1'] = '<a href="' . $v['url'] . '" target="_blank"><img style="width:40px;border-radius:10px;" class="mt-0" src="' . $v['img_creator_1'] . '"></a>';
    } else {
        $v['img_creator_1'] = '<img style="width:40px;border-radius:10px; filter: grayscale(100%)!important;" class="mt-0" src="' . $v['img_creator_1'] . '">';
    }

    if ($v['tipe_kontak'] == "WA") {
        $v['img_creator_2'] = base_url() . '/assets/img/icon/icon-wa.png';
    } else if ($v['tipe_kontak'] == "IG") {
        $v['img_creator_2'] = base_url() . '/assets/img/icon/icon-ig.png';
    } else if ($v['tipe_kontak'] == "Email") {
        $v['img_creator_2'] = base_url() . '/assets/img/icon/icon-email.png';
    } else if ($v['tipe_kontak'] == "HP") {
        $v['img_creator_2'] = base_url() . '/assets/img/icon/icon-phone.png';
    } else {
        $v['img_creator_2'] = base_url() . '/assets/img/icon/icon-no.png';
    }

    if ($v['contact']) {
        $v['img_creator_2'] = '<a href="' . $v['contact'] . '" target="_blank"><img style="width:40px;border-radius:10px;" class="mt-0" src="' . $v['img_creator_2'] . '"></a>';
    } else {
        $v['img_creator_2'] = '<img style="width:40px;border-radius:10px; filter: grayscale(100%)!important;" class="mt-0" src="' . $v['img_creator_2'] . '">';
    }



?>
    <div class="card mb-3" style="padding-bottom:0px">
        <div class="row">
            <div class="col-lg-7">
                <a class="mb-1 text-blue fw-700 fs-16 a-none" href="<?= base_url() ?>endorse/detail?id=<?= $v['id'] ?>">#<?= $k + 1 ?></a>
                <p class="mb-1 text-black fw-700 fs-16"><?= $v['nama_creator'] ?></p>

                <div class="col-lg-12 mt-0 mb-3">
                    <?= $v['img_creator_1'] ?>
                    <?= $v['img_creator_2'] ?>
                </div>

                <p class="mb-1 text-black">PIC : <?= $v['pic'] ?></p>
                <p class="mb-lg-0" style="margin-top:6px!important"><span class="br-10 fs-12 text-white" style="background-color:<?= $bg ?>!important;color:<?= $clr ?>!important"><?= strtoupper(strtolower($v['status_endorse'])) ?></span></p>
            </div>
            <div class="col-lg-5 text-lg-end text-start">
                <a href="#!" onclick="remove('<?= $v['id'] ?>')" class="btn btn-delete  mt-0 mb-2"><i class="bi bi-trash fs-16"></i> Delete Data</a>
                <a href="#!" onclick="sync('<?= $v['id'] ?>')" class="btn btn-sync ms-1 mt-0 mb-2"><i class="bi bi-bootstrap-reboot fs-16"></i> Refresh</a>
                <a href="#!" onclick="clone('<?= $v['id'] ?>')" class="btn btn-copy ms-1 mt-0 mb-2"><i class="bi bi-copy fs-16"></i> Kloning</a>
                <a href="#!" onclick="edit('<?= $v['id'] ?>')" class="btn btn-edit  mt-0 ms-1 mb-2"><i class="bi bi-pencil-square fs-16"></i> Edit Data</a>
            </div>
            <div class="col-lg-12">
                <hr>
            </div>
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-md-4">
                        <p class="mb-1 text-black">Total Cost : <?= separator_only($v['total_cost']) ?></p>
                        <p class="mb-1 text-black">Barang Dikirim : <?= $v['barang_dikirim_at'] ?></p>
                        <p class="mb-1 text-black">Rencana Upload : <?= $v['rencana_at'] ?></p>
                        <p class="mb-1 text-black">Tanggal Posting : <?= $v['posting_at'] ?></p>
                        <p class="mb-1 text-black">Status : <?= $v['status'] ?></p>
                        <p class="mb-1">Ket : <?= $v['desc'] ?></p>
                    </div>
                    <div class="col-md-4">
                        <p class="mb-1 text-black fw-600">Views : <?= separator_only($v['views']) ?></p>
                        <p class="mb-1 text-black fw-600">CPM : <?= separator_only($v['cpm']) ?></p>
                        <p class="mb-1 text-black">Likes : <?= separator_only($v['likes']) ?></p>
                        <p class="mb-1 text-black">Comments : <?= separator_only($v['comment']) ?></p>
                        <p class="mb-1 text-black">Save & Share : <?= separator_only($v['share_save']) ?></p>
                        <p class="mb-1 text-black">Tanggal Dibuat : <?= $v['created_at'] ?></p>
                        <p class="mb-1 text-black">Tanggal Diupdate : <?= $v['sync_at'] ?></p>
                    </div>
                    <div class="col-md-4">
                        <p class="mb-1 text-black">Link Brief : <br><?= $v['link_brief'] ?></p>
                        <p class="mb-1 text-black">Link MOU : <br><?= $v['link_mou'] ?></p>
                    </div>
                    <div class="col-lg-12 mt-3">


                        <div class="row">
                            <div class="col-12 mb-2" style="position:relative">
                                <div class="row">
                                    <div class="firstDivImg">
                                        <?= $v['img'] ?>
                                    </div>
                                    <div class="secondDivImg" style="margin-top: -10px;margin-left:-20px;">
                                        <a href="#!" onclick="change_fyp_<?= $k ?>()" id="fyp_<?= $k ?>" class="">
                                            <?php if ($v['is_fyp'] == 1) { ?>
                                                <i class="bi bi-star-fill" style="font-size:40px;color:#ffd250"></i>
                                            <?php } else { ?>
                                                <i class="bi bi-star" style="font-size:40px;color:#000"></i>
                                            <?php } ?>
                                            <script>
                                                function change_fyp_<?= $k ?>() {
                                                    $('#fyp_<?= $k ?>').html('<i style="margin-top: 10px;margin-bottom:10px;font-size:40px;color:#000" class="fa fa-circle-o-notch fa-spin"></i>');
                                                    $.ajax({
                                                        dataType: "json",
                                                        url: '<?= base_url() ?>ajax/change-fyp?id=<?= $v['id'] ?>',
                                                        success: function(html) {
                                                            $('#fyp_<?= $k ?>').html(html.html);
                                                            <?php $v['code'] =  'mar-5' ?>
                                                            $.ajax({
                                                                dataType: "json",
                                                                url: '<?= base_url() ?>ajax/get-summary-campaign<?= $param ?>&id=<?= $v['code'] ?>&id_campaign=<?= $v['id_campaign'] ?>',
                                                                success: function(html) {
                                                                    $("#summary-<?= $v['code'] ?>").html(html.html);
                                                                }
                                                            });

                                                        }
                                                    });
                                                }
                                            </script>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-lg-12 mb-3">
                            <div class="checkbox-wrapper-13 d-inline">
                                <input class="checkItem" style="" type="checkbox" value="<?= $v['id'] ?>" data-id="<?= $k ?>" name="list_id" form="form-action">
                            </div>

                            <input type="hidden" value="<?= $v['is_manual'] ?>" name="is_manual[<?= $k - $start ?>]" form="form-action">
                            <input type="hidden" value="<?= $v['marketplace'] ?>" name="marketplace[<?= $k - $start ?>]" form="form-action">
                            <input type="hidden" value="<?= $v['brand'] ?>" name="brand[<?= $k - $start ?>]" form="form-action">
                            <input type="hidden" value="<?= $v['order_id'] ?>" name="order_id[<?= $k - $start ?>]" form="form-action">

                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $k += 1;
} ?>

<script>
    $('input[name="list_id"]').change(function() {
        get_id();
    });
</script>