<div class="form-message"></div>
<form action="<?= base_url() ?>/endorse/update" method="POST" id="form-modal">
	<input type="hidden" name="id" value="<?= $data['id'] ?>">
	<input type="hidden" name="id_campaign" value="<?= $data['id_campaign'] ?>">
	<input type="hidden" name="status_endorse_existing" value="<?= $data['status_endorse'] ?>">
	<div class="col-md-12">
		<label for="">Status Endorse</label>
		<select type="text" class="form-control" name="dt[status_endorse]">
			<?php
			$arr = array();
			$arr[] = "Review";
			$arr[] = "Hold";
			$arr[] = "Acc";
			$arr[] = "DP";
			$arr[] = "FP";
			$arr[] = "Barang Dikirim";
			$arr[] = "Draft Content";
			$arr[] = "Posted Content";
			$arr[] = "Reject";
			foreach ($arr as $k2 => $v2) {
				$text = '';
				if ($data['status_endorse'] == $v2) {
					$text = 'selected';
				}
			?>
				<option <?= $text ?> value="<?= $v2 ?>"><?= $v2 ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-12">
		<label for="">Nama Creator</label>
		<select type="text" class="form-control select2 w-100" name="dt[influencer]">
			<?php
			foreach ($influencer as $k2 => $v2) {
				$text = '';
				if ($data['influencer'] == $v2['id']) {
					$text = 'selected';
				}
			?>
				<option <?= $text ?> value="<?= $v2['id'] ?>"><?= $v2['username'] ?> | <?= $v2['type'] ?></option>
			<?php } ?>
		</select>
	</div>
	<style>
		.select2-container--open .select2-dropdown {
			z-index: 10000;
		}
	</style>
	<script>
		$('.select2').select2();
	</script>
	<div class="col-md-12">
		<label for="">PIC</label>
		<select type="text" class="form-control select2" name="dt[pic]">
			<?php
			foreach ($pic as $k2 => $v2) {
				$text = '';
				if ($data['pic'] == $v2['full_name']) {
					$text = 'selected';
				}
			?>
				<option <?= $text ?> value="<?= $v2['full_name'] ?>"><?= $v2['full_name'] ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-12">
		<label for="">Platform</label>
		<select type="text" class="form-control" name="dt[platform]">
			<?php
			$arr = array();
			$arr[] = "Instagram";
			$arr[] = "Tiktok";
			$arr[] = "Twitter";
			$arr[] = "Youtube";
			foreach ($arr as $k2 => $v2) {
				$text = '';
				if ($data['platform'] == $v2) {
					$text = 'selected';
				}
			?>
				<option <?= $text ?> value="<?= $v2 ?>"><?= $v2 ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-12">
		<label for="">Tanggal Barang Dikirim</label>
		<input type="date" class="form-control" name="dt[barang_dikirim_at]" value="<?= $data['barang_dikirim_at'] ?>">
	</div>
	<div class="col-md-12">
		<label for="">Tanggal Rencana Upload</label>
		<input type="date" class="form-control" name="dt[rencana_at]" value="<?= $data['rencana_at'] ?>">
	</div>
	<!-- <div class="col-md-12">
		<label for="">Tanggal Posting</label>
		<input type="date" class="form-control" name="dt[posting_at]" value="<?= $data['posting_at'] ?>">
	</div> -->
	<div class="col-md-12">
		<label for="">Link Brief</label>
		<input type="text" class="form-control" name="dt[link_brief]" value="<?= $data['link_brief'] ?>">
	</div>
	<div class="col-md-12">
		<label for="">Link MOU</label>
		<input type="text" class="form-control" name="dt[link_mou]" value="<?= $data['link_mou'] ?>">
	</div>
	<div class="col-md-12">
		<label for="">Link Upload</label>
		<input type="text" class="form-control" name="dt[link_upload]" value="<?= $data['link_upload'] ?>">
	</div>
	<div class="col-md-12">
		<label for="">Total Cost</label>
		<input type="text" class="form-control" name="dt[total_cost]" value="<?= $data['total_cost'] ?>">
	</div>
	<!-- <div class="col-md-12">
		<label for="">Task</label>
		<input type="text" class="form-control" name="dt[task]" value="<?= $data['task'] ?>">
	</div> -->
	<div class="col-md-12">
		<label for="">Keterangan</label>
		<input type="text" class="form-control" name="dt[desc]" value="<?= $data['desc'] ?>">
	</div>
	<div class="col-md-12">
		<label for="">Status</label>
		<select type="text" class="form-control" name="dt[status]">
			<?php
			$arr = array();
			$arr[] = "Aktif";
			$arr[] = "Tidak Aktif";
			foreach ($arr as $k2 => $v2) {
				$text = '';
				if ($data['status'] == $v2) {
					$text = 'selected';
				}
			?>
				<option <?= $text ?> value="<?= $v2 ?>"><?= $v2 ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-12 mt-3">
		<button type="submit" class="btn btn-primary btn-send">Simpan Data</button>
	</div>
</form>
<script type="text/javascript">
	$("#form-modal").submit(function() {
		var form = $(this);
		var mydata = new FormData(this);
		$.ajax({
			type: "POST",
			url: form.attr("action"),
			data: mydata,
			cache: false,
			contentType: false,
			processData: false,
			beforeSend: function() {
				$(".btn-send").addClass("disabled").html('<div class="loading-ellipsis"><div></div><div></div><div></div><div></div></div>').attr('disabled', true);
				form.find(".form-message").slideUp().html("");
			},
			success: function(response, textStatus, xhr) {
				var str = response;
				console.log(str);
				if (str.indexOf("success") != -1) {
					$(".form-message").hide().html(response).slideDown("fast");
					setTimeout(function() {
						window.location.href = "";
						$(".btn-send").removeClass("disabled").html('Simpan Data').attr('disabled', false);
					}, 2500);
				} else {
					$(".form-message").hide().html(response).slideDown("fast");
					$(".btn-send").removeClass("disabled").html('Simpan Data').attr('disabled', false);
				}
			},
			error: function(xhr, textStatus, errorThrown) {
				$(".btn-send").removeClass("disabled").html('Simpan Data').attr('disabled', false);
				$(".form-message").hide().html(xhr).slideDown("fast");
			}
		});
		return false;
	});
</script>