<?php
$k = $start;
foreach ($data as $v) {
?>
    <tbody>
        <tr>
            <td class="text-start">
                <p class="mb-1 text-blue fw-700 fs-16">#<?= $k + 1 ?></p>
            </td>
            <td class="text-start">
                <?= $template->date_format_indo($v['date']) ?>
            </td>
            <td class="text-start">
                <?= $v['brand'] ?>
            </td>
            <td class="text-start">
                <?= $v['category'] ?>
            </td>
            <?php if ($v['category'] == 'Gift') { ?>
                <td class="text-start td-breakline">
                    <select class="form-control" id="customer-<?= $k ?>" type="text" name="dt[customer]" style="width:200px">
                        <option value="<?= $v['customer'] ?>"><?= $v['customer_text'] ?></option>
                    </select>
                    <script>
                        $(function() {
                            $('#customer-<?= $k ?>').select2({
                                minimumInputLength: 1,
                                allowClear: false,
                                placeholder: 'Pilih Pelanggan',
                                minimumResultsForSearch: Infinity, // Disable search box
                                ajax: {
                                    dataType: 'json',
                                    url: '<?= base_url() ?>/ajax/get-customer-list',
                                    delay: 100,
                                    data: function(params) {
                                        return {
                                            search: params.term
                                        }
                                    },
                                    processResults: function(data, page) {
                                        return {
                                            results: data
                                        };
                                    },
                                },
                                language: {
                                    inputTooShort: function(args) {
                                        return "Masukkan 1 karakter atau lebih";
                                    }
                                }
                            }).on('select2:select', function(evt) {
                                var id = $("#customer-<?= $k ?> option:selected").val();
                                $.ajax({
                                    dataType: "json",
                                    url: '<?= base_url() ?>/ajax/get-customer-detail?id=' + id + '&id_trx=<?= $v['id'] ?>&save=true',
                                    success: function(html) {}
                                });
                            });
                        });
                    </script>
                </td>
            <?php } else { ?>
                <td></td>
            <?php } ?>
            <td class="text-start td-breakline">
                <?= $v['title'] ?>
            </td>
            <td class="text-start td-breakline">
                <?= $v['desc'] ?>
            </td>
            <td class="text-end">
                <?= $template->separator_only(abs($v['price'])) ?>
            </td>
            <td class="text-end">
                <?= $template->separator_only(abs($v['qty'])) ?>
            </td>
            <td class="text-end">
                <?= $template->separator_only(abs($v['price_total'])) ?>
            </td>
            <td class="text-end">
                <a href="#!" onclick="edit('<?= $v['id'] ?>')" class="mt-0 text-blue me-1"><i class="bi bi-pen text-icon"></i></a>
                <a href="#!" onclick="remove('<?= $v['id'] ?>')" class="mt-0 text-red"><i class="bi bi-trash text-icon"></i></a>
            </td>

        </tr>
        </tr>
    </tbody>
<?php $k += 1;
} ?>