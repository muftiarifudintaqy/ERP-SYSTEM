<style>
    
    .select2-container .select2-selection--single {
    box-sizing: border-box;
    cursor: pointer;
    display: block;
    height: 30px;
    user-select: none;
    -webkit-user-select: none;
    border: 1px solid #ced4da;
    border-radius: 0.375rem;
}
.select2-container--default .select2-selection--single .select2-selection__rendered {
    color: #444;
    line-height: 30px;
}
.select2-container--default .select2-selection--single .select2-selection__arrow {
    height: 30px;
    position: absolute;
    top: 0px;
    right: 1px;
    width: 20px;
}
.select2 {
    height: 30px !important;
    min-width: 100% !important;
    margin-bottom: 10px;
    margin-top: -12px!important;
}
table tr td {
    padding: 20px 10px!important;
}
table tr:first-child td:first-child{
    padding: 20px 10px!important;
}

</style>
<div class="w-100">
    <div class="row align-items-center">
        <div class="col-lg-12 mb-3">
            <h3 class="text-primary fw-600">PENGELUARAN</h3>
        </div>
        <div class="col-lg-12">
            <form action="">
                <div class="row">
                    <div class="col-lg-1">
                        <select class="form-control" name="brand" >
                            <option value="">Brand</option>
                            <?php foreach ($brands as $val):
                                $text = "";
                                if ($_GET["brand"] == $val["code"]) {
                                    $text = "selected";
                                }
                                ?>
                            <option <?= $text ?> value="<?= $val[
                                "code"
                                ] ?>"><?= $val["code"] ?></option>
                            <?php
                            endforeach; ?>
                        </select>
                    </div>
                    <div class="col-lg-4">
                        <div class="input-group">
                        <button class="btn btn-outline-secondary-category dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="border-top-right-radius: 0px !important;
                            border-bottom-right-radius: 0px !important;"><?=$keyword_category?></button>
                        <ul class="dropdown-menu">
                            <?php
                                $arr = array();
                                $arr[] = 'Nama Pelanggan';
                                $arr[] = 'Judul';
                                $arr[] = 'Keterangan';
                                $arr[] = 'Kategori';
                                foreach ($arr as $k=>$val) {
                                    $class= "btn-default";
                                    if ($_GET['order_status'] == $val) {
                                        $class= "btn-default-selected";
                                    }
                                ?>
                            <li><a class="dropdown-item" href="<?=$url?>&keyword_category=<?=$val?>"><?=$val?></a></li>
                            <?php }  ?>
                        </ul>
                        <input type="hidden" name="keyword_category" value="<?=$keyword_category?>">
                        <input type="text" name="keyword" class="form-control" value="<?=$_GET['keyword']?>" style="border-top-left-radius: 0px !important;
                            border-bottom-left-radius: 0px !important;">
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="d-flex">
                        <input type="date" name="start_date" class="form-control" value="<?=$start_date?>" style="border-top-right-radius: 0px !important; border-bottom-right-radius: 0px !important; width:100%;">
                        <input type="date" name="until_date" class="form-control" value="<?=$until_date?>" style="border-top-left-radius: 0px !important; border-bottom-left-radius: 0px !important; width:100%;">
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <button class="btn btn-edit-active" type="submit"><i class="bi bi-search fs-16"></i> Cari Data</button>
                    </div>
                    <div class="col-lg-2 text-end">
                    <a href="#!" onclick="create()" class="btn btn-primary px-2 mt-0 ms-1"><i class="bi bi-plus-circle-dotted fs-16"></i> Tambah Data</a>
                    </div>
                   
                    </div>
                   
                </div>
            </form>
            <?=$notif?>
        </div>
    </div>
    <div class="col-lg-12">
    <div class="table-responsive" id="table-item">
                <table class="table" id="tbody">
                <thead>
                    <tr class="bg-blue-2 text-white">
                        <th class="text-start">#</th>
                        <th class="text-start">TGL</th>
                        <th class="text-start">BRAND</th>
                        <th class="text-start">KATEGORI</th>
                        <th class="text-start">NAMA PELANGGAN</th>
                        <th class="text-start">JUDUL</th>
                        <th class="text-start">KETERANGAN</th>
                        <th class="text-end">HARGA</th>
                        <th class="text-end">QTY</th>
                        <th class="text-end">TOTAL HARGA</th>
                        <th class="text-end"><i class="bi bi-gear-fill"></i></th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <?=$pagination?>
</div>

<div class="modal fade bd-example-modal-sm" tabindex="-1" varietas="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="modal-form">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="title-form"></h5>
                <a class="close a-link" data-bs-dismiss="modal"><i class="bi bi-x-circle fs-24"></i></a>
            </div>
            <div class="modal-body">
                <div id="load-form"></div>
            </div>
        </div>
    </div>
</div>



<script>
    function create() {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Create Data');
        $("#load-form").load("<?= base_url() ?>/expense/create");
    }

    function remove(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Hapus Data');
        $("#load-form").load("<?= base_url() ?>/expense/remove?id=" + id);
    }
    function edit(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Edit Data');
        $("#load-form").load("<?= base_url() ?>/expense/edit?id=" + id);
    }
</script>
<script>
function loadMoreData() {
    $.ajax({
        type: 'GET',
        url: "<?= base_url() ?>/expense/item<?=$param?>",
        success: function (data) {
            $('#tbody').append(data);
        },
        error: function (xhr, status, error) {
        }
    });
}
loadMoreData();
</script>
