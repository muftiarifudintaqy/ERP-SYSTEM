<style>

</style>
<div class="w-100">
    <div class="row align-items-center">
        <div class="col-lg-12 mb-3">
            <h3 class="text-primary fw-600">INFLUENCER</h3>
        </div>
        <div class="col-lg-12">
            <form action="">
                <div class="row">
                    <div class="col-md-12">
                        <?php
                        $arr = array();
                        $arr[] = "Semua Status";
                        $arr[] = "Affiliate";
                        $arr[] = "Belum Reachout";
                        $arr[] = "Sudah Reachout";
                        $arr[] = "Off Endorsement";
                        $arr[] = "Pernah Kerjasama";
                        $arr[] = "Repeat Kerjasama";
                        $arr[] = "Blacklist / Ghosting";
                        foreach ($arr as $k => $val) {
                            $class = "btn-default";
                            $class_2 = "dot";

                            $value = $val;
                            if ($k == 0) {
                                $value = '';
                            }

                            $status = isset($_GET['status']) ? $_GET['status'] : '';

                            $statusArray = $status ? explode(',', $status) : [];

                            if (($key = array_search($value, $statusArray)) !== false) {
                                unset($statusArray[$key]);
                                $class_2 = "dot-active";
                                $class = "btn-default-selected";
                            } else {
                                $statusArray[] = $value;
                            }

                            $status = implode(',', $statusArray);

                            if ($k == 0) {
                                $status = '';
                            }

                            if ($k == 0 && $_GET['status'] == "") {
                                $class_2 = "dot-active";
                                $class = "btn-default-selected";
                            }

                        ?>
                            <a href="<?= $url_1 ?>&status=<?= $status ?>" class="btn <?= $class ?> mb-3 me-2"><span class="<?= $class_2 ?>"></span> <?= $val ?></a>
                        <?php }  ?>

                        <input type="hidden" name="ids" value="<?= $ids ?>">
                        <input type="hidden" name="status" value="<?= $_GET['status'] ?>">
                    </div>
                    <div class="col-lg-4">
                        <div class="input-group">
                            <button class="btn btn-outline-secondary-category dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="border-top-right-radius: 0px !important;
                            border-bottom-right-radius: 0px !important;"><?= $keyword_category ?></button>
                            <ul class="dropdown-menu">
                                <?php
                                $arr = array();
                                // $arr[] = 'Nama Creator';
                                $arr[] = 'Username';
                                $arr[] = 'Platform';
                                $arr[] = 'URL';
                                $arr[] = 'Niche';
                                $arr[] = 'Keterangan';
                                $arr[] = 'PIC';
                                foreach ($arr as $k => $val) {
                                    $class = "btn-default";
                                    if ($_GET['order_status'] == $val) {
                                        $class = "btn-default-selected";
                                    }
                                ?>
                                    <li><a class="dropdown-item" href="<?= $url_2 ?>&keyword_category=<?= $val ?>"><?= $val ?></a></li>
                                <?php }  ?>
                            </ul>
                            <input type="hidden" name="keyword_category" value="<?= $keyword_category ?>">
                            <input type="text" name="keyword" class="form-control" value="<?= $_GET['keyword'] ?>" style="border-top-left-radius: 0px !important;
                            border-bottom-left-radius: 0px !important;">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <?php
                        $arr = [];
                        $arr[] = "";
                        // $arr[] = "Follower";
                        // $arr[] = "Views";
                        // $arr[] = "ER";
                        $arr[] = "Frequency";
                        $arr[] = "RC";
                        $arr[] = "CPM";
                        $arr[] = "ER";
                        ?>
                        <select class="form-control" name="sort">
                            <?php foreach ($arr as $k => $v) {
                                $text = "";
                                if ($_GET['sort'] == $v) {
                                    $text = "selected";
                                }
                            ?>
                                <option <?= $text ?> value="<?= $v ?>"><?= $v ?></option>
                            <?php
                            } ?>
                        </select>
                    </div>
                    <div class="col-md-1">
                        <?php
                        $arr = [];
                        $arr[] = "";
                        $arr[] = "Asc";
                        $arr[] = "Desc";
                        ?>
                        <select class="form-control" name="sort_sub">
                            <?php foreach ($arr as $k => $v) {
                                $text = "";
                                if ($_GET['sort_sub'] == $v) {
                                    $text = "selected";
                                }
                            ?>
                                <option <?= $text ?> value="<?= $v ?>"><?= $v ?></option>
                            <?php
                            } ?>
                        </select>
                    </div>
                    <div class="col-lg-6">
                        <button class="btn btn-edit-active mb-2" type="submit"><i class="bi bi-search fs-16"></i> Cari Data</button>
                        <a href="#!" onclick="sync_all()" class="btn btn-sync mt-0 ms-1 mb-2"><i class="bi bi-bootstrap-reboot fs-16"></i> Refresh Semua</a>
                        <a href="#!" onclick="create()" class="btn btn-primary px-2 mt-0 ms-1 mb-2"><i class="bi bi-plus-circle-dotted fs-16"></i> Tambah Data</a>

                    </div>

                </div>

        </div>
        </form>
        <?= $notif ?>
    </div>
</div>
<div class="col-lg-12 mb-3">
    <div class="checkbox-wrapper-13">
        <input id="c1-13" type="checkbox" value="1" class="checkAll">
        <label for="c1-13">Pilih Semua Data</label>
    </div>
</div>

<div class="col-lg-12">
    <div class="col-lg-12">
        <div id="tbody">

            <?php $this->load->view('loading', true) ?>
        </div>
    </div>

    <?= $pagination ?>
</div>



<div class="floating-div">
    <button class="btn mb-2 btn-edit-active dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
        <i class="bi bi-gear fs-16"></i> Aksi
    </button>
    <ul class="dropdown-menu text-end" style="padding:0px;background:unset;border:unset">


        <li><a class="dropdown-items" href="#!" style="padding:0px;">
                <button type="button" class="btn mb-2 btn-edit-active" onclick="refresh_data()">
                    <i class="bi bi-bootstrap-reboot fs-16"></i> Refresh Data
                </button>
            </a></li>

        <li><a class="dropdown-items" href="#!" style="padding:0px;">
                <button type="button" class="btn mb-2 btn-edit-active" onclick="tampilkan_data()">
                    <i class="bi bi-eye fs-16"></i> Tampilkan Data
                </button>
            </a></li>

        <li><a class="dropdown-items" href="#!" style="padding:0px;">
                <button type="button" class="btn mb-2 btn-edit-active" onclick="ubah_status()">
                    <i class="bi bi-cursor fs-16"></i> Ubah Status Influencer
                </button>
            </a></li>
        <li><a class="dropdown-items" href="#!" style="padding:0px;">
                <button type="button" class="btn mb-2 btn-edit-active" onclick="ubah_status_data()">
                    <i class="bi bi-cursor fs-16"></i> Ubah Status Data
                </button>
            </a></li>

        <li><a class="dropdown-items" href="#!" style="padding:0px">
                <button type="button" class="btn mb-2 btn-edit-active" onclick="hapus_data()">
                    <i class="bi bi-trash fs-16"></i> Hapus Data
                </button>
            </a></li>

    </ul>

</div>


<div class="modal fade bd-example-modal-sm" tabindex="-1" varietas="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="modal-form">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="title-form"></h5>
                <a class="close a-link" data-bs-dismiss="modal"><i class="bi bi-x-circle fs-24"></i></a>
            </div>
            <div class="modal-body">
                <div id="load-form"></div>
            </div>
        </div>
    </div>
</div>


<input type="hidden" id="id_selected" name="id_selected" form="form-action">

<script>
    var list_id_v2 = '';

    function get_id() {
        list_id_v2 = '';
        var selectedValues = [];
        $('input[name="list_id"]').each(function() {
            if ($(this).is(":checked")) {
                selectedValues.push($(this).val());
                list_id_v2 += $(this).val() + ',';
            } else {
                selectedValues.push('0');
            }
        });
        if (list_id_v2.length > 0) {
            list_id_v2 = list_id_v2.slice(0, -1); // Remove the trailing comma
        }
        $('#id_selected').val(selectedValues.join(','));
    }

    function tampilkan_data(id) {
        window.location.href = "<?= base_url() ?>/influencer?ids=" + list_id_v2;
    }

    function hapus_data(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Hapus Data');
        $("#load-form").load("<?= base_url() ?>/influencer/action?code=hapus_data&id=" + id);
    }

    function ubah_status(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Ubah Status Influencer');
        $("#load-form").load("<?= base_url() ?>/influencer/action?code=ubah_status&id=" + id);
    }

    function ubah_status_data(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Ubah Status Data');
        $("#load-form").load("<?= base_url() ?>/influencer/action?code=ubah_status_data&id=" + id);
    }

    function refresh_data(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Refresh Data');
        $("#load-form").load("<?= base_url() ?>/influencer/action?code=refresh_data&id=" + id);
    }

    function create() {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Tambah Data');
        $("#load-form").load("<?= base_url() ?>/influencer/create");
    }

    function remove(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Hapus Data');
        $("#load-form").load("<?= base_url() ?>/influencer/remove?id=" + id);
    }

    function edit(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Edit Data');
        $("#load-form").load("<?= base_url() ?>/influencer/edit?id=" + id);
    }

    function sync(id) {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Refresh Data');
        $("#load-form").load("<?= base_url() ?>/influencer/sync?id=" + id);
    }

    function sync_all() {
        $("#load-form").html('Loading...');
        $("#modal-form").modal('show');
        $("#title-form").html('Refresh Semua Data');
        $("#load-form").load("<?= base_url() ?>/influencer/sync_all<?= $param ?>");
    }
</script>
<script>
    function loadMoreData() {
        $.ajax({
            type: 'GET',
            url: "<?= base_url() ?>/influencer/item<?= $param ?>",
            success: function(data) {
                $('#tbody').html('');
                $('#tbody').append(data);
                select3();
            },
            error: function(xhr, status, error) {}
        });
    }
    loadMoreData();
</script>