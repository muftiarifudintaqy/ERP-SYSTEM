<div class="form-message"></div>
<form action="<?= base_url() ?>/influencer/store" method="POST" id="form-modal">
	<input type="hidden" name="id" value="<?= $data['id'] ?>">
	<div class="col-md-12">
		<label for="">Status Creator</label>
		<select type="text" class="form-control" name="dt[status_reach]">
			<?php
			$arr = array();
			$arr[] = "Affiliate";
			$arr[] = "Belum Reachout";
			$arr[] = "Sudah Reachout";
			$arr[] = "Off Endorsement";
			$arr[] = "Pernah Kerjasama";
			$arr[] = "Repeat Kerjasama";
			$arr[] = "Blacklist / Ghosting";
			foreach ($arr as $k2 => $v2) {
				$text = '';
				if ($data['status_reach'] == $v2) {
					$text = 'selected';
				}
			?>
				<option <?= $text ?> value="<?= $v2 ?>"><?= $v2 ?></option>
			<?php } ?>
		</select>
	</div>
	<!-- <div class="col-md-12">
		<label for="">KOL Name</label>
		<input type="text" class="form-control" name="dt[full_name]" value="<?= $data['full_name'] ?>">
	</div> -->
	<div class="col-md-12">
		<label for="">Username</label>
		<input type="text" class="form-control" name="dt[username]" value="<?= $data['username'] ?>">
	</div>
	<div class="col-md-12">
		<label for="">Brand</label>
		<select type="text" class="form-control" name="dt[brand]">
			<?php
			foreach ($brand as $k2 => $v2) {
				$text = '';
				if ($data['brand'] == $v2['code']) {
					$text = 'selected';
				}
			?>
				<option <?= $text ?> value="<?= $v2['code'] ?>"><?= $v2['code'] ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-12">
		<label for="">PIC</label>
		<select type="text" class="form-control" name="dt[pic]">
			<?php
			foreach ($pic as $k2 => $v2) {
				$text = '';
				if ($data['pic'] == $v2['full_name']) {
					$text = 'selected';
				}
			?>
				<option <?= $text ?> value="<?= $v2['full_name'] ?>"><?= $v2['full_name'] ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-12">
		<label for="">Platform</label>
		<select type="text" class="form-control" name="dt[type]">
			<?php
			$arr = array();
			$arr[] = "Tiktok";
			$arr[] = "Instagram";
			$arr[] = "Twitter";
			$arr[] = "Youtube";
			foreach ($arr as $k2 => $v2) {
				$text = '';
				if ($data['type'] == $v2) {
					$text = 'selected';
				}
			?>
				<option <?= $text ?> value="<?= $v2 ?>"><?= $v2 ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-12">
		<label for="">URL</label>
		<input type="text" class="form-control" name="dt[url]" value="<?= $data['url'] ?>">
	</div>
	<div class="col-md-12">
		<label for="">Niche</label>
		<select type="text" class="form-control" name="dt[niche]">
			<?php
			$arr = array();
			$arr[] = "Fashion";
			$arr[] = "Couple";
			$arr[] = "Bumil Busui";
			$arr[] = "Foodies";
			$arr[] = "Entertainment";
			$arr[] = "Expert";
			$arr[] = "Gym / Diet";
			$arr[] = "Beauty Reviewer";
			$arr[] = "Random";
			foreach ($arr as $k2 => $v2) {
				$text = '';
				if ($data['niche'] == $v2) {
					$text = 'selected';
				}
			?>
				<option <?= $text ?> value="<?= $v2 ?>"><?= $v2 ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-12">
		<label for="">Range Ratecard</label>
		<input type="text" class="form-control" name="dt[ratecard]" value="<?= $data['ratecard'] ?>">
	</div>
	<div class="col-md-12">
		<label for="">Tipe Kontak</label>
		<select type="text" class="form-control" name="dt[tipe_kontak]">
			<?php
			$arr = array();
			$arr[] = "WA";
			$arr[] = "IG";
			$arr[] = "Email";
			$arr[] = "HP";
			foreach ($arr as $k2 => $v2) {
				$text = '';
				if ($data['tipe_kontak'] == $v2) {
					$text = 'selected';
				}
			?>
				<option <?= $text ?> value="<?= $v2 ?>"><?= $v2 ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-12">
		<label for="">URL Kontak</label>
		<input type="text" class="form-control" name="dt[contact]" value="<?= $data['contact'] ?>">
	</div>
	<div class="col-md-12">
		<label for="">Keterangan</label>
		<input type="text" class="form-control" name="dt[desc]" value="<?= $data['desc'] ?>">
	</div>
	<div class="col-md-12">
		<label for="">Status</label>
		<select type="text" class="form-control" name="dt[status]">
			<?php
			$arr = array();
			$arr[] = "Aktif";
			$arr[] = "Tidak Aktif";
			foreach ($arr as $k2 => $v2) {
				$text = '';
				if ($data['status'] == $v2) {
					$text = 'selected';
				}
			?>
				<option <?= $text ?> value="<?= $v2 ?>"><?= $v2 ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-12 mt-3">
		<button type="submit" class="btn btn-primary btn-send">Simpan Data</button>
	</div>
</form>
<script type="text/javascript">
	$("#form-modal").submit(function() {
		var form = $(this);
		var mydata = new FormData(this);
		$.ajax({
			type: "POST",
			url: form.attr("action"),
			data: mydata,
			cache: false,
			contentType: false,
			processData: false,
			beforeSend: function() {
				$(".btn-send").addClass("disabled").html('<div class="loading-ellipsis"><div></div><div></div><div></div><div></div></div>').attr('disabled', true);
				form.find(".form-message").slideUp().html("");
			},
			success: function(response, textStatus, xhr) {
				var str = response;
				console.log(str);
				if (str.indexOf("success") != -1) {
					$(".form-message").hide().html(response).slideDown("fast");
					setTimeout(function() {
						window.location.href = "";
						$(".btn-send").removeClass("disabled").html('Simpan Data').attr('disabled', false);
					}, 2500);
				} else {
					$(".form-message").hide().html(response).slideDown("fast");
					$(".btn-send").removeClass("disabled").html('Simpan Data').attr('disabled', false);
				}
			},
			error: function(xhr, textStatus, errorThrown) {
				$(".btn-send").removeClass("disabled").html('Simpan Data').attr('disabled', false);
				$(".form-message").hide().html(xhr).slideDown("fast");
			}
		});
		return false;
	});
</script>