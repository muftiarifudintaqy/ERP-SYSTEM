<style>
    .owl-theme .owl-dots .owl-dot.active span,
    .owl-theme .owl-dots .owl-dot:hover span {
        background: #1255cc;
    }

    .owl-theme .owl-dots .owl-dot span {
        background: #1155CC1A;
        margin: 3px;
    }

    .owl-theme .owl-nav.disabled+.owl-dots {
        margin-top: 0px;
    }
</style>
<?php
$chart_title = "";
$site = $_GET['site'];
$customer = $_GET['customer'];

if ($_GET['start_date'] == "") {
    $start_date = DATE("Y-m-d");
    $start_date = DATE('Y-m-d', strtotime($today . " -31 days"));
} else {
    $start_date = $_GET['start_date'];
}
if ($_GET['until_date'] == "") {
    $until_date = DATE("Y-m-d");
} else {
    $until_date = $_GET['until_date'];
}

if ($_GET['start_year'] == "") {
    $start_year = DATE("Y");
} else {
    $start_year = $_GET['start_year'];
}

if ($_GET['until_year'] == "") {
    $until_year = DATE("Y");
} else {
    $until_year = $_GET['until_year'];
}

if ($_GET['start_month'] == "") {
    $start_month = "1";
} else {
    $start_month = $_GET['start_month'];
}

if ($_GET['until_month'] == "") {
    $until_month = DATE("m");
} else {
    $until_month = $_GET['until_month'];
}

if ($_GET['start_week'] == "") {
    $start_week = "1";
} else {
    $start_week = $_GET['start_week'];
}

if ($_GET['until_week'] == "") {
    $until_week = DATE("W", strtotime(DATE('Y-m-d')));
} else {
    $until_week = $_GET['until_week'];
}



$type = $_GET['type'];

if ($_GET['type'] == "Yearly") {
    $chart_title = $start_year . ' - ' . $until_year;
} else if ($_GET['type'] == "Monthly") {
    $chart_title = 'Month ' . $start_month . ' - ' . $until_month . ' ' . $start_year;
} else if ($_GET['type'] == "Weekly") {
    $chart_title = 'Week ' . $start_week . ' - ' . $until_week . ' ' . $start_year;
} else {
    $type = "Daily";
    $chart_title = DATE('d M Y', strtotime($start_date)) . ' - ' . DATE('d M Y', strtotime($until_date));
}
?>

<div class="w-100">
    <div class="row align-items-center">
        <div class="col-lg-12 mb-1">

            <div class="row">
                <div class="col-md-12">
                    <h3 class="text-primary fw-500">DASHBOARD KOL BHSKIN</h3>
                </div>
            </div>
            <?php $this->load->view('dashboard/menu') ?>
        </div>




        <div class="col-lg-12">



            <form action="" class="">
                <input type="hidden" name="t" value="kol">
                <div class="row">

                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-4">
                                <select class="form-control select2" name="brand" id="brand">
                                    <option value="">Brand</option>
                                    <?php foreach ($brands as $val) :
                                        $text = "";
                                        if ($_GET["brand"] == $val["code"]) {
                                            $text = "selected";
                                        }
                                    ?>
                                        <option <?= $text ?> value="<?= $val["code"] ?>"><?= $val["code"] ?></option>
                                    <?php
                                    endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <select class="form-control select2" name="channel">
                                    <option value="">Channel</option>
                                    <?php foreach ($channel_2 as $val) :
                                        $text = "";
                                        if ($_GET["channel"] == $val["name"]) {
                                            $text = "selected";
                                        }
                                    ?>
                                        <option <?= $text ?> value="<?= $val["name"] ?>"><?= $val["name"] ?></option>
                                    <?php
                                    endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <?php
                                $arr = [];
                                $arr[] = "Daily";
                                // $arr[] = "Weekly";
                                // $arr[] = "Monthly";
                                // $arr[] = "Yearly";
                                ?>
                                <select class="form-control select2" name="type" id="type">
                                    <?php foreach ($arr as $k => $v) {
                                        $text = "";
                                        if ($type == $v) {
                                            $text = "selected";
                                        }
                                    ?>
                                        <option <?= $text ?> value="<?= $v ?>"><?= $v ?></option>
                                    <?php
                                    } ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="row" id="filter"></div>
                    </div>
                    <script>
                        $("#type").change(function() {
                            get_filter();
                        });

                        get_filter();

                        function get_filter() {
                            var type = $("#type").val();
                            $.ajax({
                                dataType: "json",
                                url: '<?= base_url() ?>ajax/get-filter?type=' + type +
                                    '&start_date=<?= $start_date ?>&until_date=<?= $until_date ?>&start_year=<?= $start_year ?>&until_year=<?= $until_year ?>&start_month=<?= $start_month ?>&until_month=<?= $until_month ?>&start_week=<?= $start_week ?>&until_week=<?= $until_week ?>',
                                success: function(html) {
                                    $("#filter").html(html.html);
                                }
                            });
                            // $('.select2').select2();
                        }
                    </script>
                </div>
            </form>


        </div>



        <h4 class="text-primary fw-500 mt-4">INFLUENCER KOL MARKETING</h4>
        <div class="col-lg-12 mt-3">
            <div class="row">
                <?php
                $sum = array();
                $i = 0;
                $sum[$i]['code'] = "kol-1";
                $sum[$i]['img'] = "bi bi-people";
                $sum[$i]['color_box'] = "#F2994A1A";
                $sum[$i]['color_icon'] = "#f2994a";
                $sum[$i]['title'] = "INFLUENCER";
                $sum[$i]['unit'] = "BCM";
                $i++;
                $sum[$i]['code'] = "kol-2";
                $sum[$i]['img'] = "bi bi-person-video2";
                $sum[$i]['color_box'] = "#F2994A1A";
                $sum[$i]['color_icon'] = "#f2994a";
                $sum[$i]['title'] = "ENDORSE";
                $sum[$i]['unit'] = "BCM";
                $i++;
                $sum[$i]['code'] = "kol-3";
                $sum[$i]['img'] = "bi bi-coin";
                $sum[$i]['color_box'] = "#F2994A1A";
                $sum[$i]['color_icon'] = "#f2994a";
                $sum[$i]['title'] = "COST";
                $sum[$i]['unit'] = "BCM";
                $i++;
                $sum[$i]['code'] = "kol-4";
                $sum[$i]['img'] = "bi bi-eye";
                $sum[$i]['color_box'] = "#F2994A1A";
                $sum[$i]['color_icon'] = "#f2994a";
                $sum[$i]['title'] = "VIEW";
                $sum[$i]['unit'] = "BCM";
                $i++;
                $sum[$i]['code'] = "kol-5";
                $sum[$i]['img'] = "bi bi-heart";
                $sum[$i]['color_box'] = "#F2994A1A";
                $sum[$i]['color_icon'] = "#f2994a";
                $sum[$i]['title'] = "LIKE";
                $sum[$i]['unit'] = "BCM";
                $i++;
                $sum[$i]['code'] = "kol-6";
                $sum[$i]['img'] = "bi bi-chat-quote";
                $sum[$i]['color_box'] = "#F2994A1A";
                $sum[$i]['color_icon'] = "#f2994a";
                $sum[$i]['title'] = "COMMENT";
                $sum[$i]['unit'] = "BCM";
                $i++;
                $sum[$i]['code'] = "kol-7";
                $sum[$i]['img'] = "bi bi-bookmarks";
                $sum[$i]['color_box'] = "#F2994A1A";
                $sum[$i]['color_icon'] = "#f2994a";
                $sum[$i]['title'] = "SAVE & SHARE";
                $sum[$i]['unit'] = "BCM";
                $i++;
                $sum[$i]['code'] = "kol-8";
                $sum[$i]['img'] = "bi bi-cursor";
                $sum[$i]['color_box'] = "#F2994A1A";
                $sum[$i]['color_icon'] = "#f2994a";
                $sum[$i]['title'] = "CPM";
                $sum[$i]['unit'] = "BCM";
                $i++;

                ?>
                <?php foreach ($sum as $k => $v) { ?>
                    <div class="text-start mb-4 col-md-3 col-6">
                        <div class="card h-100">
                            <div class="row">
                                <div class="col-12" style="position:relative">
                                    <div class="row">
                                        <div class="firstDiv">
                                            <div class="firstCircle">
                                                <div class="box-icon mb-2 text-center" style="background-color:<?= $v['color_box'] ?>;">
                                                    <i class="<?= $v['img'] ?>" style="color:<?= $v['color_icon'] ?>"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="secondDiv">
                                            <p class="fw-500 mb-1 text-end"><?= $v['title'] ?></p>
                                            <h4 class="fw-500 mb-1 text-end" id="summary-<?= $v['code'] ?>"><i class="fa fa-circle-o-notch fa-spin"></i></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <script>
                        $.ajax({
                            dataType: "json",
                            url: '<?= base_url() ?>ajax/get_summary_v2?site=<?= $site ?>&id=<?= $v['code'] ?>&brand=<?= $_GET['brand'] ?>&type=<?= $type ?>&start_date=<?= $start_date ?>&until_date=<?= $until_date ?>&start_year=<?= $start_year ?>&until_year=<?= $until_year ?>&start_month=<?= $start_month ?>&until_month=<?= $until_month ?>&start_week=<?= $start_week ?>&until_week=<?= $until_week ?>',
                            success: function(html) {
                                $("#summary-<?= $v['code'] ?>").html(html.html);
                            }
                        });
                    </script>
                <?php } ?>
            </div>
        </div>


        <div class="col-lg-12 mb-3">
            <div class="card summary">
                <h4 class="text-primary fw-500 mb-1">GRAFIK CAMPAIGN</h3>
                    <p class="mb-2"><?= $title_2 ?></p>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="d-grid d-md-flex d-lg-flex">
                                <?php
                                $arr = array();
                                $arr[] = "Daily";
                                $arr[] = "Views";
                                $arr[] = "CPM";
                                $arr[] = "Likes";
                                $arr[] = "Comments";
                                $arr[] = "Share & Save";
                                $arr[] = "Jumlah Konten";
                                foreach ($arr as $k => $v) {
                                    $text = "";
                                    if ($checkbox_campaign[$k] == 'true') {
                                        $text = "checked";
                                    }
                                    if (empty($checkbox_campaign)) {
                                        $text = "checked";
                                    }
                                ?>
                                    <input onclick="checkbox2()" <?= $text ?> type="checkbox" id="cc-<?= $k ?>" class="me-2 cc-checkbox"><label for="cc-<?= $k ?>" class="fw-400 me-2"><?= $v ?></label>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <div id="summary-chart"><i class="fa fa-circle-o-notch fa-spin"></i> Memuat data ...</div>
                    <div id="summary-table"><i class="fa fa-circle-o-notch fa-spin"></i> Memuat data ...</div>
                    <script>
                        get_chart();

                        function get_chart() {
                            $.ajax({
                                dataType: "json",
                                url: '<?= base_url() ?>ajax/get-chart-campaign<?= $param ?>&is_dashboard=true',
                                success: function(html) {
                                    $("#summary-chart").html(html.html);
                                    $("#summary-table").html(html.table);

                                    $("#summary-kol-7").html('<i class="fa fa-circle-o-notch fa-spin"></i>');
                                    $("#summary-kol-7").html(html.summary.share);
                                    $("#summary-kol-8").html('<i class="fa fa-circle-o-notch fa-spin"></i>');
                                    $("#summary-kol-8").html(html.summary.cpm);
                                    $("#summary-kol-4").html('<i class="fa fa-circle-o-notch fa-spin"></i>');
                                    $("#summary-kol-4").html(html.summary.view);
                                    $("#summary-kol-5").html('<i class="fa fa-circle-o-notch fa-spin"></i>');
                                    $("#summary-kol-5").html(html.summary.likes);
                                    $("#summary-kol-6").html('<i class="fa fa-circle-o-notch fa-spin"></i>');
                                    $("#summary-kol-6").html(html.summary.comment);

                                }
                            });
                        }

                        function checkbox2() {
                            var checkboxStatus = {};
                            var i = 0;
                            $(".cc-checkbox").each(function() {
                                var isChecked = $(this).prop("checked");
                                checkboxStatus[i] = isChecked;
                                i++;
                            });

                            var queryParams = $.param(checkboxStatus);
                            console.log(queryParams);
                            $.ajax({
                                type: "GET",
                                dataType: "json",
                                url: '<?= base_url() ?>ajax/checkbox?type=dashboard_campaign&' + queryParams,
                                success: function(response) {
                                    get_chart();
                                }
                            });
                        }
                    </script>
            </div>
        </div>

        <!-- <style>
        #calendar table tr th {
        font-size: 12px !important;
        max-width:unset!important;
        min-width:unset!important;
    }
    table tr:first-child th:first-child {
        font-size: 12px !important;
        max-width:unset!important;
        min-width:unset!important;
        width:unser!important;
    }
    </style>

    <h4 class="text-primary fw-500 mt-4">ENDORSEMENT CONTENTS CALENDAR</h4>
    <div class="col-lg-12 mt-3">
        <div class="row">
                <div class="text-start mb-4 col-md-12">
                <div class="card h-100">
                <div id="summary-calendar">
                    <i class="fa fa-circle-o-notch fa-spin"></i> Memuat data ...
                    </div>
                    </div>
                </div>
                <script>
                    $.ajax({
                        dataType: "json",
                        url: '<?= base_url() ?>ajax/get_summary?site=<?= $site ?>&id=calendar&brand=<?= $_GET['brand'] ?>&channel=<?= $_GET['channel'] ?>&type=<?= $type ?>&start_date=<?= $start_date ?>&until_date=<?= $until_date ?>&start_year=<?= $start_year ?>&until_year=<?= $until_year ?>&start_month=<?= $start_month ?>&until_month=<?= $until_month ?>&start_week=<?= $start_week ?>&until_week=<?= $until_week ?>',
                        success: function(html) {
                            $("#summary-calendar").html(html.html);
                        }
                    });
                </script>
        </div>
    </div> -->



        <!-- <h4 class="text-primary fw-500 mt-4">LIST CUSTOMER ULANG TAHUN</h4>
    <div class="col-lg-12 mt-3">
        <div class="row">
            <div class="col-lg-3">
                <h5 class="text-primary fw-500 mt-0">HARI INI</h5>
                <div id="birthday-today"><i class="fa fa-spin fa-refresh"></i> Sedang memuat data!</div>
                <script>
                    $.ajax({
                        dataType: "json",
                        url: '<?= base_url() ?>ajax/get-birthday-list?type=today',
                        success: function(html) {
                            $("#birthday-today").html(html.html);
                        }
                    });
                </script>
            </div>
            <div class="col-lg-3">
                <h5 class="text-primary fw-500 mt-0">BESOK</h5>
                <div id="birthday-1"><i class="fa fa-spin fa-refresh"></i> Sedang memuat data!</div>
                <script>
                    $.ajax({
                        dataType: "json",
                        url: '<?= base_url() ?>ajax/get-birthday-list?type=+1',
                        success: function(html) {
                            $("#birthday-1").html(html.html);
                        }
                    });
                </script>
            </div>
            <div class="col-lg-3">
                <h5 class="text-primary fw-500 mt-0">LUSA</h5>
                <div id="birthday-2"><i class="fa fa-spin fa-refresh"></i> Sedang memuat data!</div>
                <script>
                    $.ajax({
                        dataType: "json",
                        url: '<?= base_url() ?>ajax/get-birthday-list?type=+2',
                        success: function(html) {
                            $("#birthday-2").html(html.html);
                        }
                    });
                </script>
            </div>
            <div class="col-lg-3">
                <h5 class="text-primary fw-500 mt-0">YANG AKAN DATANG</h5>
                <div id="birthday-3"><i class="fa fa-spin fa-refresh"></i> Sedang memuat data!</div>
                <script>
                    $.ajax({
                        dataType: "json",
                        url: '<?= base_url() ?>ajax/get-birthday-list?type=+3',
                        success: function(html) {
                            $("#birthday-3").html(html.html);
                        }
                    });
                </script>
            </div>
        </div>
    </div> -->


    </div>