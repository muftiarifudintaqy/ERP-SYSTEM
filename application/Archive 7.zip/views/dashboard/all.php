<style>
    .owl-theme .owl-dots .owl-dot.active span,
    .owl-theme .owl-dots .owl-dot:hover span {
        background: #1255cc;
    }

    .owl-theme .owl-dots .owl-dot span {
        background: #1155CC1A;
        margin: 3px;
    }

    .owl-theme .owl-nav.disabled+.owl-dots {
        margin-top: 0px;
    }
</style>
<?php
$chart_title = "";
$site = $_GET['site'];
$customer = $_GET['customer'];

if ($_GET['start_date'] == "") {
    $start_date = DATE("Y-m-d");
    $start_date = DATE('Y-m-d', strtotime($today . " -31 days"));
} else {
    $start_date = $_GET['start_date'];
}
if ($_GET['until_date'] == "") {
    $until_date = DATE("Y-m-d");
} else {
    $until_date = $_GET['until_date'];
}

if ($_GET['start_year'] == "") {
    $start_year = DATE("Y");
} else {
    $start_year = $_GET['start_year'];
}

if ($_GET['until_year'] == "") {
    $until_year = DATE("Y");
} else {
    $until_year = $_GET['until_year'];
}

if ($_GET['start_month'] == "") {
    $start_month = "1";
} else {
    $start_month = $_GET['start_month'];
}

if ($_GET['until_month'] == "") {
    $until_month = DATE("m");
} else {
    $until_month = $_GET['until_month'];
}

if ($_GET['start_week'] == "") {
    $start_week = "1";
} else {
    $start_week = $_GET['start_week'];
}

if ($_GET['until_week'] == "") {
    $until_week = DATE("W", strtotime(DATE('Y-m-d')));
} else {
    $until_week = $_GET['until_week'];
}



$type = $_GET['type'];

if ($_GET['type'] == "Yearly") {
    $chart_title = $start_year . ' - ' . $until_year;
} else if ($_GET['type'] == "Monthly") {
    $chart_title = 'Month ' . $start_month . ' - ' . $until_month . ' ' . $start_year;
} else if ($_GET['type'] == "Weekly") {
    $chart_title = 'Week ' . $start_week . ' - ' . $until_week . ' ' . $start_year;
} else {
    $type = "Daily";
    $chart_title = DATE('d M Y', strtotime($start_date)) . ' - ' . DATE('d M Y', strtotime($until_date));
}
?>

<div class="w-100">
    <div class="row align-items-center">
        <div class="col-lg-12 mb-3">

            <div class="row">
                <div class="col-md-12">
                    <h3 class="text-primary fw-500">DASHBOARD ORDER BHSKIN</h3>
                </div>
            </div>
            <?php $this->load->view('dashboard/menu') ?>
        </div>




        <div class="col-lg-12">



            <form action="" class="">
                <div class="row">

                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-4">
                                <select class="form-control select2" name="brand" id="brand">
                                    <option value="">Brand</option>
                                    <?php foreach ($brands as $val) :
                                        $text = "";
                                        if ($_GET["brand"] == $val["code"]) {
                                            $text = "selected";
                                        }
                                    ?>
                                        <option <?= $text ?> value="<?= $val["code"] ?>"><?= $val["code"] ?></option>
                                    <?php
                                    endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <select class="form-control select2" name="channel">
                                    <option value="">Channel</option>
                                    <?php foreach ($channel_2 as $val) :
                                        $text = "";
                                        if ($_GET["channel"] == $val["name"]) {
                                            $text = "selected";
                                        }
                                    ?>
                                        <option <?= $text ?> value="<?= $val["name"] ?>"><?= $val["name"] ?></option>
                                    <?php
                                    endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <?php
                                $arr = [];
                                $arr[] = "Daily";
                                $arr[] = "Weekly";
                                $arr[] = "Monthly";
                                $arr[] = "Yearly";
                                ?>
                                <select class="form-control select2" name="type" id="type">
                                    <?php foreach ($arr as $k => $v) {
                                        $text = "";
                                        if ($type == $v) {
                                            $text = "selected";
                                        }
                                    ?>
                                        <option <?= $text ?> value="<?= $v ?>"><?= $v ?></option>
                                    <?php
                                    } ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="row" id="filter"></div>
                    </div>
                    <script>
                        $("#type").change(function() {
                            get_filter();
                        });

                        get_filter();

                        function get_filter() {
                            var type = $("#type").val();
                            $.ajax({
                                dataType: "json",
                                url: '<?= base_url() ?>ajax/get-filter?type=' + type +
                                    '&start_date=<?= $start_date ?>&until_date=<?= $until_date ?>&start_year=<?= $start_year ?>&until_year=<?= $until_year ?>&start_month=<?= $start_month ?>&until_month=<?= $until_month ?>&start_week=<?= $start_week ?>&until_week=<?= $until_week ?>',
                                success: function(html) {
                                    $("#filter").html(html.html);
                                }
                            });
                            // $('.select2').select2();
                        }
                    </script>
                </div>
            </form>


        </div>

        <h4 class="text-primary fw-500 mt-4">LAPORAN ORDER</h4>

        <div class="owl-carousel owl-theme">
            <div class="item">
                <div class="col-lg-12 mt-3">
                    <div class="row">
                        <?php
                        $sum = array();
                        $i = 0;

                        if (in_array($_SESSION['user']['role'], array('1', '2'))) {
                            $sum[$i]['code'] = 'order-1';
                            $sum[$i]['img'] = "bi bi-cart-fill";
                            $sum[$i]['color_box'] = "#1155CC1A";
                            $sum[$i]['color_icon'] = "#1255cc";
                            $sum[$i]['title'] = "Jumlah Order";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-2';
                            $sum[$i]['img'] = "bi bi-cart-dash";
                            $sum[$i]['color_box'] = "#1155CC1A";
                            $sum[$i]['color_icon'] = "#1255cc";
                            $sum[$i]['title'] = "Order Belum Di Proses";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-3';
                            $sum[$i]['img'] = "bi bi-cart-dash-fill";
                            $sum[$i]['color_box'] = "#1155CC1A";
                            $sum[$i]['color_icon'] = "#1255cc";
                            $sum[$i]['title'] = "Order Belum Dibayar";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-4';
                            $sum[$i]['img'] = "bi bi-cart-x";
                            $sum[$i]['color_box'] = "#1155CC1A";
                            $sum[$i]['color_icon'] = "#1255cc";
                            $sum[$i]['title'] = "Order Return";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-5';
                            $sum[$i]['img'] = "bi bi-arrow-down-circle-fill";
                            $sum[$i]['color_box'] = "#60BB551A";
                            $sum[$i]['color_icon'] = "#60bb55";
                            $sum[$i]['title'] = "Penjualan Kotor";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-6';
                            $sum[$i]['img'] = "bi bi-percent";
                            $sum[$i]['color_box'] = "#60BB551A";
                            $sum[$i]['color_icon'] = "#60bb55";
                            $sum[$i]['title'] = "Diskon";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-7';
                            $sum[$i]['img'] = "bi bi-check-circle-fill";
                            $sum[$i]['color_box'] = "#60BB551A";
                            $sum[$i]['color_icon'] = "#60bb55";
                            $sum[$i]['title'] = "Penjualan Bersih";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-8';
                            $sum[$i]['img'] = "bi bi-calculator";
                            $sum[$i]['color_box'] = "#60BB551A";
                            $sum[$i]['color_icon'] = "#60bb55";
                            $sum[$i]['title'] = "Laba Bersih";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-9';
                            $sum[$i]['img'] = "bi bi-house-exclamation-fill";
                            $sum[$i]['color_box'] = "#fdf1f1";
                            $sum[$i]['color_icon'] = "#ed7881";
                            $sum[$i]['title'] = "Marketplace Fee";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-10';
                            $sum[$i]['img'] = "bi bi-people";
                            $sum[$i]['color_box'] = "#fdf1f1";
                            $sum[$i]['color_icon'] = "#ed7881";
                            $sum[$i]['title'] = "Affiliate Fee";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-11';
                            $sum[$i]['img'] = "bi bi-arrow-up-circle-fill";
                            $sum[$i]['color_box'] = "#fdf1f1";
                            $sum[$i]['color_icon'] = "#ed7881";
                            $sum[$i]['title'] = "Pengeluaran";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-12';
                            $sum[$i]['img'] = "bi bi-box-seam";
                            $sum[$i]['color_box'] = "#fdf1f1";
                            $sum[$i]['color_icon'] = "#ed7881";
                            $sum[$i]['title'] = "HPP Produk";
                            $sum[$i]['unit'] = "BCM";
                        } else {
                            $sum[$i]['code'] = 'order-1';
                            $sum[$i]['img'] = "bi bi-cart-fill";
                            $sum[$i]['color_box'] = "#1155CC1A";
                            $sum[$i]['color_icon'] = "#1255cc";
                            $sum[$i]['title'] = "Jumlah Order";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-2';
                            $sum[$i]['img'] = "bi bi-cart-dash";
                            $sum[$i]['color_box'] = "#1155CC1A";
                            $sum[$i]['color_icon'] = "#1255cc";
                            $sum[$i]['title'] = "Order Belum Di Proses";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-3';
                            $sum[$i]['img'] = "bi bi-cart-dash-fill";
                            $sum[$i]['color_box'] = "#1155CC1A";
                            $sum[$i]['color_icon'] = "#1255cc";
                            $sum[$i]['title'] = "Order Belum Dibayar";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-4';
                            $sum[$i]['img'] = "bi bi-cart-x";
                            $sum[$i]['color_box'] = "#1155CC1A";
                            $sum[$i]['color_icon'] = "#1255cc";
                            $sum[$i]['title'] = "Order Return";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-5';
                            $sum[$i]['img'] = "bi bi-arrow-down-circle-fill";
                            $sum[$i]['color_box'] = "#60BB551A";
                            $sum[$i]['color_icon'] = "#60bb55";
                            $sum[$i]['title'] = "Penjualan Kotor";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-6';
                            $sum[$i]['img'] = "bi bi-percent";
                            $sum[$i]['color_box'] = "#60BB551A";
                            $sum[$i]['color_icon'] = "#60bb55";
                            $sum[$i]['title'] = "Diskon";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-7';
                            $sum[$i]['img'] = "bi bi-check-circle-fill";
                            $sum[$i]['color_box'] = "#60BB551A";
                            $sum[$i]['color_icon'] = "#60bb55";
                            $sum[$i]['title'] = "Penjualan Bersih";
                            $sum[$i]['unit'] = "BCM";
                            $i++;

                            $sum[$i]['code'] = 'order-9';
                            $sum[$i]['img'] = "bi bi-house-exclamation-fill";
                            $sum[$i]['color_box'] = "#fdf1f1";
                            $sum[$i]['color_icon'] = "#ed7881";
                            $sum[$i]['title'] = "Marketplace Fee";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-10';
                            $sum[$i]['img'] = "bi bi-people";
                            $sum[$i]['color_box'] = "#fdf1f1";
                            $sum[$i]['color_icon'] = "#ed7881";
                            $sum[$i]['title'] = "Affiliate Fee";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                        }
                        ?>
                        <?php foreach ($sum as $k => $v) {
                            $v['title'] = strtoupper($v['title']);
                        ?>
                            <div class="text-start mb-4 col-md-3 col-6">
                                <a href="#!" class="a-none text-black">
                                    <div class="card h-100 card-hover">
                                        <div class="row">
                                            <div class="col-12" style="position:relative">
                                                <div class="row">
                                                    <div class="firstDiv">
                                                        <div class="firstCircle">
                                                            <div class="box-icon mb-2 text-center" style="background-color:<?= $v['color_box'] ?>;">
                                                                <i class="<?= $v['img'] ?>" style="color:<?= $v['color_icon'] ?>"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="secondDiv">
                                                        <p class="fw-500 mb-1 text-end"><?= $v['title'] ?></p>
                                                        <h4 class="fw-500 mb-1 text-end" id="summary-<?= $v['code'] ?>"><i class="fa fa-circle-o-notch fa-spin"></i></h4>
                                                        <h6 class="fw-400 mb-0 text-end" id="progress-<?= $v['code'] ?>"><i class="fa fa-circle-o-notch fa-spin"></i></h6>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <script>
                                $.ajax({
                                    dataType: "json",
                                    url: '<?= base_url() ?>ajax/get_summary?site=<?= $site ?>&id=<?= $v['code'] ?>&brand=<?= $_GET['brand'] ?>&channel=<?= $_GET['channel'] ?>&type=<?= $type ?>&start_date=<?= $start_date ?>&until_date=<?= $until_date ?>&start_year=<?= $start_year ?>&until_year=<?= $until_year ?>&start_month=<?= $start_month ?>&until_month=<?= $until_month ?>&start_week=<?= $start_week ?>&until_week=<?= $until_week ?>',
                                    success: function(html) {
                                        $("#summary-<?= $v['code'] ?>").html(html.html);
                                        $("#progress-<?= $v['code'] ?>").html(html.progress);
                                    }
                                });
                            </script>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <div class="item">

                <div class="col-lg-12 mt-3">
                    <div class="row">
                        <?php
                        $sum = array();
                        $i = 0;
                        if (in_array($_SESSION['user']['role'], array('1', '2'))) {
                            $sum[$i]['code'] = 'order-13';
                            $sum[$i]['img'] = "bi bi-box-seam-fill";
                            $sum[$i]['color_box'] = "#1155CC1A";
                            $sum[$i]['color_icon'] = "#1255cc";
                            $sum[$i]['title'] = "Nilai Produk";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-14';
                            $sum[$i]['img'] = "bi bi-truck";
                            $sum[$i]['color_box'] = "#fdf1f1";
                            $sum[$i]['color_icon'] = "#ed7881";
                            $sum[$i]['title'] = "Ongkir";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-15';
                            $sum[$i]['img'] = "bi bi-cart-dash-fill";
                            $sum[$i]['color_box'] = "#fdf1f1";
                            $sum[$i]['color_icon'] = "#ed7881";
                            $sum[$i]['title'] = "Belum Dibayar";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-16';
                            $sum[$i]['img'] = "bi bi-cart-x";
                            $sum[$i]['color_box'] = "#fdf1f1";
                            $sum[$i]['color_icon'] = "#ed7881";
                            $sum[$i]['title'] = "Penjualan Return";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                        } else {
                            $sum[$i]['code'] = 'order-14';
                            $sum[$i]['img'] = "bi bi-truck";
                            $sum[$i]['color_box'] = "#fdf1f1";
                            $sum[$i]['color_icon'] = "#ed7881";
                            $sum[$i]['title'] = "Ongkir";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-15';
                            $sum[$i]['img'] = "bi bi-cart-dash-fill";
                            $sum[$i]['color_box'] = "#fdf1f1";
                            $sum[$i]['color_icon'] = "#ed7881";
                            $sum[$i]['title'] = "Belum Dibayar";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                            $sum[$i]['code'] = 'order-16';
                            $sum[$i]['img'] = "bi bi-cart-x";
                            $sum[$i]['color_box'] = "#fdf1f1";
                            $sum[$i]['color_icon'] = "#ed7881";
                            $sum[$i]['title'] = "Penjualan Return";
                            $sum[$i]['unit'] = "BCM";
                            $i++;
                        }

                        ?>
                        <?php foreach ($sum as $k => $v) {
                            $v['title'] = strtoupper($v['title']);
                        ?>
                            <div class="text-start mb-4 col-md-3 col-6">
                                <a href="#!" class="a-none text-black" onclick="refresh_chart('<?= $v['code'] ?>','<?= $v['title'] ?>')">
                                    <div class="card h-100 card-hover">
                                        <div class="row">
                                            <div class="col-12" style="position:relative">
                                                <div class="row">
                                                    <div class="firstDiv">
                                                        <div class="firstCircle">
                                                            <div class="box-icon mb-2 text-center" style="background-color:<?= $v['color_box'] ?>;">
                                                                <i class="<?= $v['img'] ?>" style="color:<?= $v['color_icon'] ?>"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="secondDiv">
                                                        <p class="fw-500 mb-1 text-end"><?= $v['title'] ?></p>
                                                        <h4 class="fw-500 mb-1 text-end" id="summary-<?= $v['code'] ?>"><i class="fa fa-circle-o-notch fa-spin"></i></h4>
                                                        <h6 class="fw-400 mb-0 text-end" id="progress-<?= $v['code'] ?>"><i class="fa fa-circle-o-notch fa-spin"></i></h6>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <script>
                                $.ajax({
                                    dataType: "json",
                                    url: '<?= base_url() ?>ajax/get_summary?site=<?= $site ?>&id=<?= $v['code'] ?>&brand=<?= $_GET['brand'] ?>&channel=<?= $_GET['channel'] ?>&type=<?= $type ?>&start_date=<?= $start_date ?>&until_date=<?= $until_date ?>&start_year=<?= $start_year ?>&until_year=<?= $until_year ?>&start_month=<?= $start_month ?>&until_month=<?= $until_month ?>&start_week=<?= $start_week ?>&until_week=<?= $until_week ?>',
                                    success: function(html) {
                                        $("#summary-<?= $v['code'] ?>").html(html.html);
                                        $("#progress-<?= $v['code'] ?>").html(html.progress);
                                    }
                                });
                            </script>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('.owl-carousel').owlCarousel({
                loop: false,
                margin: 10,
                responsiveClass: true,
                responsive: {
                    0: {
                        items: 1,
                        nav: false
                    },
                    600: {
                        items: 1,
                        nav: false
                    },
                    1000: {
                        items: 1,
                        loop: false,
                    }
                }
            })
        })
    </script>

    <div class="col-lg-12 mt-3 mb-3">
        <div class="card h-100  summary mb-2">

            <h4 class="text-primary fw-500 mb-1">GRAFIK ORDER</h4>
            <p class="mb-2"><?= $title_2 ?></p>
            <div class="col-md-12">
                <div class="d-grid d-md-flex d-lg-flex">
                    <?php
                    $arr = array();
                    $arr[] = "Jumlah Order";
                    $arr[] = "Penjualan Kotor";
                    $arr[] = "Penjualan Bersih";
                    $arr[] = "Laba Bersih";
                    $arr[] = "Pengeluaran";
                    foreach ($arr as $k => $v) {
                        $text = "";
                        if ($checkbox[$k] == 'true') {
                            $text = "checked";
                        }
                        if (empty($checkbox)) {
                            $text = "checked";
                        }
                    ?>
                        <input onclick="checkbox()" <?= $text ?> type="checkbox" id="c-<?= $k ?>" class="me-2 c-checkbox"><label for="c-<?= $k ?>" class="fw-400 me-2"><?= $v ?></label>
                    <?php } ?>
                </div>
            </div>
            <div id="get-chart">
                <i class="fa fa-circle-o-notch fa-spin"></i> Memuat data ...
            </div>
            <div id="get-table">
            </div>
            <script>
                function refresh_chart(code, title) {
                    $.ajax({
                        dataType: "json",
                        url: '<?= base_url() ?>ajax/get-chart?type=<?= $type ?>&brand=<?= $_GET['brand'] ?>&channel=<?= $_GET['channel'] ?>&start_date=<?= $start_date ?>&until_date=<?= $until_date ?>&start_year=<?= $start_year ?>&until_year=<?= $until_year ?>&start_month=<?= $start_month ?>&until_month=<?= $until_month ?>&start_week=<?= $start_week ?>&until_week=<?= $until_week ?>&code=' + code + '&title=' + title,
                        success: function(html) {
                            $("#get-chart").html(html.html);
                            $("#get-table").html(html.table);
                        }
                    });
                }

                function checkbox() {
                    var checkboxStatus = {};
                    var i = 0;
                    $(".c-checkbox").each(function() {
                        var isChecked = $(this).prop("checked");
                        checkboxStatus[i] = isChecked;
                        i++;
                    });

                    var queryParams = $.param(checkboxStatus);
                    console.log(queryParams);
                    $.ajax({
                        type: "GET",
                        dataType: "json",
                        url: '<?= base_url() ?>ajax/checkbox?type=dashboard&' + queryParams,
                        success: function(response) {
                            refresh_chart('<?= $sum[0]['code'] ?>', '<?= $sum[0]['title'] ?>');
                        }
                    });
                }
                refresh_chart('<?= $sum[0]['code'] ?>', '<?= $sum[0]['title'] ?>');
            </script>
        </div>
    </div>

    <?php foreach ($channel as $kk => $vv) {
        if ($vv['img']) {
            $vv['img'] = base_url() . '/assets/img/marketplace/' . $vv['img'];
        } else {
            $vv['img'] = base_url() . '/assets/img/marketplace/default.png';
        }

    ?>

        <div class="col-lg-12 mt-3 mb-3 card">
            <div class="row">
                <div class="col-lg-12 mb-2">
                    <p class="mb-1 fw-500"><img src="<?= $vv['img'] ?>" alt="" style="width:50px;height:50px;border-radius:20%"></p>
                </div>
            </div>
            <div class="row ">
                <?php
                $sum = array();
                $i = 0;
                $sum[$i]['code'] = 'order-17';
                $sum[$i]['img'] = "bi bi-cart-fill";
                $sum[$i]['color_box'] = "#1155CC1A";
                $sum[$i]['color_icon'] = "#1255cc";
                $sum[$i]['title'] = "Omset Bersih";
                $sum[$i]['unit'] = "BCM";
                $i++;
                $sum[$i]['code'] = 'order-18';
                $sum[$i]['img'] = "bi bi-cart-dash";
                $sum[$i]['color_box'] = "#1155CC1A";
                $sum[$i]['color_icon'] = "#1255cc";
                $sum[$i]['title'] = "Variabel Beban";
                $sum[$i]['unit'] = "BCM";
                $i++;
                $sum[$i]['code'] = 'order-19';
                $sum[$i]['img'] = "bi bi-credit-card-fill";
                $sum[$i]['color_box'] = "#1155CC1A";
                $sum[$i]['color_icon'] = "#1255cc";
                $sum[$i]['title'] = "Penghasilan Yg Diterima";
                $sum[$i]['unit'] = "BCM";
                $i++;
                // $sum[$i]['code'] = 'order-20';
                // $sum[$i]['img'] = "bi bi-boxes";
                // $sum[$i]['color_box'] = "#1155CC1A";
                // $sum[$i]['color_icon'] = "#1255cc";
                // $sum[$i]['title'] = "Jumlah Order";
                // $sum[$i]['unit'] = "BCM";
                ?>
                <?php foreach ($sum as $k => $v) {
                    $v['title'] = strtoupper($v['title']);
                ?>
                    <div class="text-start mb-4 col-md-4">
                        <p class="fw-500 mb-1 text-start"><?= $v['title'] ?></p>
                        <h4 class="fw-500 mb-1 text-start" id="summary-<?= $v['code'] ?>-<?= $kk ?>"><i class="fa fa-circle-o-notch fa-spin"></i></h4>
                        <h6 class="fw-400 mb-0 text-start" id="progress-<?= $v['code'] ?>-<?= $kk ?>"><i class="fa fa-circle-o-notch fa-spin"></i></h6>
                        <script>
                            $.ajax({
                                dataType: "json",
                                url: '<?= base_url() ?>ajax/get_summary?channel=<?= $vv['name'] ?>&id=<?= $v['code'] ?>&brand=<?= $_GET['brand'] ?>&type=<?= $type ?>&start_date=<?= $start_date ?>&until_date=<?= $until_date ?>&start_year=<?= $start_year ?>&until_year=<?= $until_year ?>&start_month=<?= $start_month ?>&until_month=<?= $until_month ?>&start_week=<?= $start_week ?>&until_week=<?= $until_week ?>',
                                success: function(html) {
                                    $("#summary-<?= $v['code'] ?>-<?= $kk ?>").html(html.html);
                                    $("#progress-<?= $v['code'] ?>-<?= $kk ?>").html(html.progress);
                                }
                            });
                        </script>
                        <?php if ($k == 0) {
                            $v['title'] = "JUMLAH ORDER";
                            $v['code'] = "order-20";
                        ?>
                            <p class="fw-500 mb-1 mt-2 text-start"><?= $v['title'] ?></p>
                            <h4 class="fw-500 mb-1 text-start" id="summary-<?= $v['code'] ?>-<?= $kk ?>"><i class="fa fa-circle-o-notch fa-spin"></i></h4>
                            <h6 class="fw-400 mb-0 text-start" id="progress-<?= $v['code'] ?>-<?= $kk ?>"><i class="fa fa-circle-o-notch fa-spin"></i></h6>
                            <script>
                                $.ajax({
                                    dataType: "json",
                                    url: '<?= base_url() ?>ajax/get_summary?channel=<?= $vv['name'] ?>&id=<?= $v['code'] ?>&brand=<?= $_GET['brand'] ?>&type=<?= $type ?>&start_date=<?= $start_date ?>&until_date=<?= $until_date ?>&start_year=<?= $start_year ?>&until_year=<?= $until_year ?>&start_month=<?= $start_month ?>&until_month=<?= $until_month ?>&start_week=<?= $start_week ?>&until_week=<?= $until_week ?>',
                                    success: function(html) {
                                        $("#summary-<?= $v['code'] ?>-<?= $kk ?>").html(html.html);
                                        $("#progress-<?= $v['code'] ?>-<?= $kk ?>").html(html.progress);
                                    }
                                });
                            </script>
                        <?php } ?>
                        <?php if ($k == 2) {
                            $v['title'] = "ORDER DICAIRKAN";
                            $v['code'] = "order-21";
                        ?>
                            <p class="fw-500 mb-1 mt-2 text-start"><?= $v['title'] ?></p>
                            <h4 class="fw-500 mb-1 text-start" id="summary-<?= $v['code'] ?>-<?= $kk ?>"><i class="fa fa-circle-o-notch fa-spin"></i></h4>
                            <h6 class="fw-400 mb-0 text-start" id="progress-<?= $v['code'] ?>-<?= $kk ?>"><i class="fa fa-circle-o-notch fa-spin"></i></h6>
                            <script>
                                $.ajax({
                                    dataType: "json",
                                    url: '<?= base_url() ?>ajax/get_summary?channel=<?= $vv['name'] ?>&id=<?= $v['code'] ?>&brand=<?= $_GET['brand'] ?>&type=<?= $type ?>&start_date=<?= $start_date ?>&until_date=<?= $until_date ?>&start_year=<?= $start_year ?>&until_year=<?= $until_year ?>&start_month=<?= $start_month ?>&until_month=<?= $until_month ?>&start_week=<?= $start_week ?>&until_week=<?= $until_week ?>',
                                    success: function(html) {
                                        $("#summary-<?= $v['code'] ?>-<?= $kk ?>").html(html.html);
                                        $("#progress-<?= $v['code'] ?>-<?= $kk ?>").html(html.progress);
                                    }
                                });
                            </script>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>
        </div>

    <?php } ?>






    <!-- <style>
        #calendar table tr th {
        font-size: 12px !important;
        max-width:unset!important;
        min-width:unset!important;
    }
    table tr:first-child th:first-child {
        font-size: 12px !important;
        max-width:unset!important;
        min-width:unset!important;
        width:unser!important;
    }
    </style>

    <h4 class="text-primary fw-500 mt-4">ENDORSEMENT CONTENTS CALENDAR</h4>
    <div class="col-lg-12 mt-3">
        <div class="row">
                <div class="text-start mb-4 col-md-12">
                <div class="card h-100">
                <div id="summary-calendar">
                    <i class="fa fa-circle-o-notch fa-spin"></i> Memuat data ...
                    </div>
                    </div>
                </div>
                <script>
                    $.ajax({
                        dataType: "json",
                        url: '<?= base_url() ?>ajax/get_summary?site=<?= $site ?>&id=calendar&brand=<?= $_GET['brand'] ?>&channel=<?= $_GET['channel'] ?>&type=<?= $type ?>&start_date=<?= $start_date ?>&until_date=<?= $until_date ?>&start_year=<?= $start_year ?>&until_year=<?= $until_year ?>&start_month=<?= $start_month ?>&until_month=<?= $until_month ?>&start_week=<?= $start_week ?>&until_week=<?= $until_week ?>',
                        success: function(html) {
                            $("#summary-calendar").html(html.html);
                        }
                    });
                </script>
        </div>
    </div> -->



    <!-- <h4 class="text-primary fw-500 mt-4">LIST CUSTOMER ULANG TAHUN</h4>
    <div class="col-lg-12 mt-3">
        <div class="row">
            <div class="col-lg-3">
                <h5 class="text-primary fw-500 mt-0">HARI INI</h5>
                <div id="birthday-today"><i class="fa fa-spin fa-refresh"></i> Sedang memuat data!</div>
                <script>
                    $.ajax({
                        dataType: "json",
                        url: '<?= base_url() ?>ajax/get-birthday-list?type=today',
                        success: function(html) {
                            $("#birthday-today").html(html.html);
                        }
                    });
                </script>
            </div>
            <div class="col-lg-3">
                <h5 class="text-primary fw-500 mt-0">BESOK</h5>
                <div id="birthday-1"><i class="fa fa-spin fa-refresh"></i> Sedang memuat data!</div>
                <script>
                    $.ajax({
                        dataType: "json",
                        url: '<?= base_url() ?>ajax/get-birthday-list?type=+1',
                        success: function(html) {
                            $("#birthday-1").html(html.html);
                        }
                    });
                </script>
            </div>
            <div class="col-lg-3">
                <h5 class="text-primary fw-500 mt-0">LUSA</h5>
                <div id="birthday-2"><i class="fa fa-spin fa-refresh"></i> Sedang memuat data!</div>
                <script>
                    $.ajax({
                        dataType: "json",
                        url: '<?= base_url() ?>ajax/get-birthday-list?type=+2',
                        success: function(html) {
                            $("#birthday-2").html(html.html);
                        }
                    });
                </script>
            </div>
            <div class="col-lg-3">
                <h5 class="text-primary fw-500 mt-0">YANG AKAN DATANG</h5>
                <div id="birthday-3"><i class="fa fa-spin fa-refresh"></i> Sedang memuat data!</div>
                <script>
                    $.ajax({
                        dataType: "json",
                        url: '<?= base_url() ?>ajax/get-birthday-list?type=+3',
                        success: function(html) {
                            $("#birthday-3").html(html.html);
                        }
                    });
                </script>
            </div>
        </div>
    </div> -->


</div>