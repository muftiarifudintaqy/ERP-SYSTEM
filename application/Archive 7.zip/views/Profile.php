<div class="w-100">
    <div class="row align-items-center">
        <div class="col-lg-12 mb-3">

            <div class="row">
                <div class="col-10">
                    <h3 class="text-primary fw-500">AKUN SAYA</h3>
                </div>

            </div>
        </div>


        <div class="">
            <div class="col-md-12 card p-4">
                <div class="row">
                    <div class="form-message"></div>
                    <form action="<?= base_url() ?>/profile/update-process" method="POST" id="form-modal" enctype="multipart/form-data">
                        <div class="col-md-12">
                            <label for="">Nama Lengkap</label>
                            <input type="text" class="form-control" name="dt[full_name]" value="<?= $data['full_name'] ?>">
                        </div>
                        <div class="col-md-12">
                            <label for="">Username</label>
                            <input type="text" class="form-control" name="dt[username]" value="<?= $data['username'] ?>">
                        </div>
                        <div class="col-md-12">
                            <label for="">Email</label>
                            <input type="text" class="form-control" name="dt[email]" value="<?= $data['email'] ?>">
                        </div>
                        <div class="col-md-12">
                            <label for="">Password</label> <i> * Kosongkan jika tidak diubah</i>
                            <input type="text" class="form-control" name="dt[password]" value="">
                        </div>
                        <div class="col-md-12">
                            <label for="">Role</label>
                            <input disabled type="text" class="form-control" name="dt[role]" value="<?= $data['role_text'] ?>">
                        </div>
                        <div class="col-md-12">
                            <label for="">Tanggal Lahir</label>
                            <input type="date" class="form-control" name="dt[birth_date]" value="<?= $data['birth_date'] ?>">
                        </div>
                        <div class="col-md-12">
                            <label for="">Keterangan</label>
                            <input type="text" class="form-control" name="dt[desc]" value="<?= $data['desc'] ?>">
                        </div>
                        <div class="col-md-12">
                            <label for="">Gambar</label>
                            <?php if ($data['img']) { ?>
                                <a href="<?= base_url() ?>/assets/img/user/<?= $data['img'] . '?token=' . DATE("Ymdhis", strtotime($data['updated_at'])) ?>" target="_blank"><i>Open Image</i></a>
                            <?php } ?>
                            <input type="file" class="form-control" name="file" accept="image/png, image/jpeg, image/jpg">
                        </div>
                        <div class="col-md-12 mt-3">
                            <button type="submit" class="btn btn-primary btn-send">Simpan Perubahan</button>
                        </div>
                    </form>
                </div>
            </div>


        </div>
    </div>

    <div class="col-lg-12 mt-4">
        <div class="row">



            <div class="modal fade bd-example-modal-sm" tabindex="-1" varietas="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="modal-form">
                <div class="modal-dialog modal-md">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="title-form"></h5>
                            <a class="close a-link" data-bs-dismiss="modal"><i class="bi bi-x-circle fs-24"></i></a>
                        </div>
                        <div class="modal-body">
                            <div id="load-form"></div>
                        </div>
                    </div>
                </div>
            </div>

            <script type="text/javascript">
                $("#form-modal").submit(function() {
                    var form = $(this);
                    var mydata = new FormData(this);
                    $.ajax({
                        type: "POST",
                        url: form.attr("action"),
                        data: mydata,
                        cache: false,
                        contentType: false,
                        processData: false,
                        beforeSend: function() {
                            $(".btn-send").addClass("disabled").html('<div class="loading-ellipsis"><div></div><div></div><div></div><div></div></div>').attr('disabled', true);
                            form.find(".form-message").slideUp().html("");
                        },
                        success: function(response, textStatus, xhr) {
                            var str = response;
                            console.log(str);
                            if (str.indexOf("success") != -1) {
                                $(".form-message").hide().html(response).slideDown("fast");
                                setTimeout(function() {
                                    window.location.href = "";
                                    $(".btn-send").removeClass("disabled").html('Simpan Perubahan').attr('disabled', false);
                                }, 2500);
                            } else {
                                $(".form-message").hide().html(response).slideDown("fast");
                                $(".btn-send").removeClass("disabled").html('Simpan Perubahan').attr('disabled', false);
                            }
                        },
                        error: function(xhr, textStatus, errorThrown) {
                            $(".btn-send").removeClass("disabled").html('Simpan Perubahan').attr('disabled', false);
                            $(".form-message").hide().html(xhr).slideDown("fast");
                        }
                    });
                    return false;
                });
            </script>