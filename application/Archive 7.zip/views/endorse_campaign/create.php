<div class="form-message"></div>
<form action="<?= base_url() ?>/endorse-campaign/store" method="POST" id="form-modal">
	<input type="hidden" name="id" value="<?= $data['id'] ?>">
	<div class="col-md-12">
		<label for="">Judul Campaign</label>
		<input type="text" class="form-control" name="dt[title]" value="<?= $data['title'] ?>">
	</div>
	<div class="col-md-12">
		<label for="">Brand</label>
		<select type="text" class="form-control" name="dt[brand]">
			<?php
			foreach ($brand as $k2 => $v2) {
				$text = '';
				if ($data['brand'] == $v2['code']) {
					$text = 'selected';
				}
			?>
				<option <?= $text ?> value="<?= $v2['code'] ?>"><?= $v2['code'] ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-12">
		<label for="">PIC</label>
		<select type="text" class="form-control" name="dt[pic]">
			<?php
			foreach ($pic as $k2 => $v2) {
				$text = '';
				if ($data['pic'] == $v2['full_name']) {
					$text = 'selected';
				}
			?>
				<option <?= $text ?> value="<?= $v2['full_name'] ?>"><?= $v2['full_name'] ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-12">
		<label for="">Tanggal Mulai</label>
		<input type="date" class="form-control" name="dt[start_at]" value="<?= DATE("Y-m-d") ?>">
	</div>
	<div class="col-md-12">
		<label for="">Tanggal Selesai</label>
		<input type="date" class="form-control" name="dt[until_at]" value="<?= DATE("Y-m-d") ?>">
	</div>
	<div class="col-md-12">
		<label for="">Budget</label>
		<input type="text" class="form-control" name="dt[budget]" value="<?= $data['budget'] ?>">
	</div>

	<div class="col-md-12">
		<label for="">Deskripsi</label>
		<textarea type="text" class="form-control" name="dt[desc]" style="min-height:160px!important"><?= $data['desc'] ?></textarea>
	</div>
	<!-- <div class="col-md-12">
		<label for="">Image</label>
		<?php if ($data['img']) { ?>
			<a href="<?= base_url() ?>/assets/img/stock/<?= $data['img'] . '?token=' . DATE("Ymdhis", strtotime($data['updated_at'])) ?>" target="_blank"><i>Open Image</i></a>
		<?php } ?>
		<input type="file" class="form-control" name="file" accept="image/png, image/jpeg, image/jpg">
	</div> -->
	<div class="col-md-12">
		<label for="">Status</label>
		<select type="text" class="form-control" name="dt[status]">
			<?php
			$arr = array();
			$arr[] = "Aktif";
			$arr[] = "Tidak Aktif";
			foreach ($arr as $k2 => $v2) {
				$text = '';
				if ($data['status'] == $v2) {
					$text = 'selected';
				}
			?>
				<option <?= $text ?> value="<?= $v2 ?>"><?= $v2 ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-12 mt-3">
		<button type="submit" class="btn btn-primary btn-send">Simpan Data</button>
	</div>
</form>
<script type="text/javascript">
	$("#form-modal").submit(function() {
		var form = $(this);
		var mydata = new FormData(this);
		$.ajax({
			type: "POST",
			url: form.attr("action"),
			data: mydata,
			cache: false,
			contentType: false,
			processData: false,
			beforeSend: function() {
				$(".btn-send").addClass("disabled").html('<div class="loading-ellipsis"><div></div><div></div><div></div><div></div></div>').attr('disabled', true);
				form.find(".form-message").slideUp().html("");
			},
			success: function(response, textStatus, xhr) {
				var str = response;
				console.log(str);
				if (str.indexOf("success") != -1) {
					$(".form-message").hide().html(response).slideDown("fast");
					setTimeout(function() {
						window.location.href = "";
						$(".btn-send").removeClass("disabled").html('Simpan Data').attr('disabled', false);
					}, 2500);
				} else {
					$(".form-message").hide().html(response).slideDown("fast");
					$(".btn-send").removeClass("disabled").html('Simpan Data').attr('disabled', false);
				}
			},
			error: function(xhr, textStatus, errorThrown) {
				$(".btn-send").removeClass("disabled").html('Simpan Data').attr('disabled', false);
				$(".form-message").hide().html(xhr).slideDown("fast");
			}
		});
		return false;
	});
</script>