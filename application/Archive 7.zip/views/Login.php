<div class="row" style="--bs-gutter-x:0rem!important">
  <div class="container-fluid">
    <div class="row align-items-center vh-100">
      <div class="col-lg-7 p-0">
        <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
          <div class="carousel-indicators">
            <?php foreach ($data as $k => $v) {
              $active = "active";
              if ($k > 0) {
                $active = "";
              }
            ?>
              <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="<?= $k ?>" class="<?= $active ?>" aria-current="true" aria-label="Slide <?= $k + 1 ?>"></button>
            <?php } ?>
          </div>
          <div class="carousel-inner">
            <?php foreach ($data as $k => $v) {
              $active = "active";
              if ($k > 0) {
                $active = "";
              }
            ?>
              <div class="carousel-item <?= $active ?>">
                <div class="xbanner" style="background-image: url('<?= base_url() ?>/assets/webfile/home/<?= $v['img'] ?>');"></div>
              </div>
            <?php } ?>
          </div>
        </div>
      </div>
      <div class="col-lg-5 p-5">
        <div class="container-fluid">
          <form action="<?= base_url() ?>/auth/login-process" id="form" method="POST">
            <div class="form-message"></div>
            <div class="col-lg-12">
              <img src="<?= base_url() ?>/assets/img/logo.png" style="height:100px;" alt="" class="">
            </div>
            <div class=" col-lg-12 pt-3">
              <h4 class="text-primary fw-600">Sistem CRM & Marketing BHSKIN</h4>
            </div>
            <div class="col-lg-12 pt-4">
              <label for="">Username</label>
              <input name="email" type="text" class="form-control" placeholder="Masukkan username kamu di sini">
            </div>
            <div class="col-lg-12">
              <label for="">Password</label>
              <div class="div-icon">
                <div class="icon-right" onclick="func_pass_1()">
                  <i class="bi bi-eye-slash" id="show_eye_1" style="display: block;"></i>
                  <i class="bi bi-eye" id="hide_eye_1" style="display: none;"></i>
                </div>
                <input name="password" type="password" class="form-control" placeholder="Masukkan password kamu di sini" id="password_1">
              </div>
            </div>
            <div class="col-lg-12 mt-4">
              <div class="row align-items-center">
                <div class="col-12">
                  <button class="btn btn-primary w-100 btn-send">Masuk Sekarang</button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>

  </div>
</div>


<script type="text/javascript">
  $("#form").submit(function() {
    var form = $(this);
    var mydata = new FormData(this);
    $.ajax({
      type: "POST",
      url: form.attr("action"),
      data: mydata,
      cache: false,
      contentType: false,
      processData: false,
      beforeSend: function() {
        $(".btn-send").addClass("disabled").html('<div class="loading-ellipsis"><div></div><div></div><div></div><div></div></div>').attr('disabled', true);
        form.find(".form-message").slideUp().html("");
      },
      success: function(response, textStatus, xhr) {
        var str = response;
        console.log(str);
        if (str.indexOf("success") != -1) {
          $(".form-message").hide().html(response).slideDown("fast");
          setTimeout(function() {
            window.location.href = "";
            $(".btn-send").removeClass("disabled").html('Masuk Sekarang').attr('disabled', false);
          }, 2500);
        } else {
          $(".form-message").hide().html(response).slideDown("fast");
          $(".btn-send").removeClass("disabled").html('Masuk Sekarang').attr('disabled', false);
        }
      },
      error: function(xhr, textStatus, errorThrown) {
        $(".btn-send").removeClass("disabled").html('Masuk Sekarang').attr('disabled', false);
        $(".form-message").hide().html(xhr).slideDown("fast");
      }
    });
    return false;
  });
</script>
</section>
<script>
  function func_pass_1() {
    var x = document.getElementById("password_1");
    var show_eye_1 = document.getElementById("show_eye_1");
    var hide_eye_1 = document.getElementById("hide_eye_1");
    hide_eye_1.classList.remove("d-none");
    if (x.type === "password") {
      x.type = "text";
      show_eye_1.style.display = "none";
      hide_eye_1.style.display = "block";
    } else {
      x.type = "password";
      show_eye_1.style.display = "block";
      hide_eye_1.style.display = "none";
    }
  }

  function func_pass_2() {
    var y = document.getElementById("password_2");
    var show_eye_2 = document.getElementById("show_eye_2");
    var hide_eye_2 = document.getElementById("hide_eye_2");
    hide_eye_2.classList.remove("d-none");
    if (y.type === "password") {
      y.type = "text";
      show_eye_2.style.display = "none";
      hide_eye_2.style.display = "block";
    } else {
      y.type = "password";
      show_eye_2.style.display = "block";
      hide_eye_2.style.display = "none";
    }
  }

  function func_pass_3() {
    var z = document.getElementById("password_3");
    var show_eye_3 = document.getElementById("show_eye_3");
    var hide_eye_3 = document.getElementById("hide_eye_3");
    hide_eye_3.classList.remove("d-none");
    if (z.type === "password") {
      z.type = "text";
      show_eye_3.style.display = "none";
      hide_eye_3.style.display = "block";
    } else {
      z.type = "password";
      show_eye_3.style.display = "block";
      hide_eye_3.style.display = "none";
    }
  }
</script>
</body>

</html>